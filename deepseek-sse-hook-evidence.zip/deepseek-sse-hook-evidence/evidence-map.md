# DeepSeek 2.7.3 / 2.7.5 targeted SSE and Hook evidence

## Verified semantic mapping

| Role | 2.7.3 | 2.7.5 | Evidence boundary |
|---|---|---|---|
| Request route / serializer | `hx2.g(u01, Long) -> z40` | `nw3.e(yu1, Long) -> b70` | Same five chat routes and serializer-backed request objects |
| HTTP response handler | `e0.A`, synthetic branch `e=1` | `g0.z`, synthetic branch `e=1` | Handles response status, heartbeat marker, stream parser or structured error result |
| SSE line parser | `jz0.A`, branch `e=0` | `vs1.z`, branch `e=0` | Ktor ByteReadChannel, timeout-based line reads, `event: ` / `data: ` parsing |
| SSE line reader helper | `fl0` | `qp0` | Coroutine wrapper around Ktor channel line read |
| Stream adapter | `g5.a`, branch `e=5` | `t5.a`, branch `e=7` | Wraps parsed event pair into downstream event type |
| Event dispatcher | `k11.a(k11, gw8, Continuation)` | `r3.c(fv1, Continuation)` | Handles DeltaCommand and named SSE events |
| Auto-resume orchestration | `qu1.h` | `rr2.h` | Both contain the `executeAutoResumeStreamFlow` Kotlin metadata signature |
| SSE lifecycle telemetry | `e11.f(lr8)` | `iv1.c(fda)` | Records request/created/ready/first-delta/finish/disconnect/auto-resume milestones |
| PoW algorithm selection | `ap9.c(n88, Continuation)` | `of2.k(ts9, Continuation)` | Both dispatch `DeepSeekHashV1` to the same Java native API |
| Challenge response header | No DEX string match | `oq1.c` sets `X-DS-Challenge-Response` and `X-DS-PoW-Response` | New/changed challenge header path in 2.7.5 |

## SSE parser behavior established from smali

1. Response header `x-ds-sse-heartbeat-timeout-secs` is parsed as base-10 seconds; default is 10 seconds.
2. The timeout is converted to milliseconds and applied to each asynchronous line read.
3. The parser obtains the response body as Ktor `ByteReadChannel`.
4. It recognizes lines beginning exactly with `event: ` and `data: `.
5. An `event: ` line stores the event name. A `data: ` line immediately emits an event/data pair (`gw8` in 2.7.3; `bia` in 2.7.5).
6. The event name is cleared after the emitted pair. Non-matching lines are ignored; no `id:` or `retry:` handling or multi-line `data:` concatenation was found in these parser bodies.
7. The read loop checks coroutine activity and channel closure, and closes the channel on normal completion or exception.
8. The event dispatcher treats a null event name as the DeltaCommand stream path; named events include `ready`, `finish`, `toast`, `hint`, `title`, `update_session`, `update_file`, `update_parent_message`, `close`, `check_client_update`, and `auto_tts_capability`.

## Version isolation examples

Do not align classes by obfuscated name alone:
- 2.7.3 `vs1` is a serializer for `ChatSessionUpdateTitleResponseBizData`; 2.7.5 `vs1` is the SSE ByteReadChannel parser.
- 2.7.3 `nw3` is not the request router; 2.7.5 `nw3.e` is the request route/serializer builder.
- 2.7.3 `rr2` is a generic lock-free queue; 2.7.5 `rr2.h` is the chat stream auto-resume method.

## PoW native binary

- Both APKs contain `lib/arm64-v8a/librscrypto.so` (336,568 bytes).
- SHA-256 in both versions: `4571b9bcf08d5f070a47a495bdcd4c77f4a088feee560ed11701ca93c7b56053`.
- JNI export: `Java_com_deepseek_crypto_PowCalculator_nativeCalculateDeepSeekHashV1Pow`.
- JNI symbol offset: `0x18e40`; size: 484 bytes.
- Static disassembly shows a 25-lane 64-bit Keccak-family state, 136-byte block/rate processing, candidate counter formatting, and a 32-byte comparison path. Exact preimage concatenation and acceptance predicate remain unproven; do not call it a confirmed standardized SHA3 variant.

## APK identity

- 2.7.3 SHA-256: `a6d025c14c98118a5a67849e04aaef6f3c9c13aaf0fa62caaee0e47091374ea3`
- 2.7.5 SHA-256: `ddc52ef868b991fd33e634de834a3e2c022b0cd7ff9e854f4f141996aaeadb70`

All included smali is static evidence. It does not establish runtime Hook compatibility or successful execution on a device.
