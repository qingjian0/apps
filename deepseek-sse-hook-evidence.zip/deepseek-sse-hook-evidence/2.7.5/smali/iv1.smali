.class public final Liv1;
.super Ljava/lang/Object;
.source "r8-map-id-2e17ac06b3663e3b6803a43c074ce5b2710eae1d5a807a22099ba6599b707f30"


# instance fields
.field public final a:Lzs;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:J

.field public final e:Ljava/lang/String;

.field public final f:Lzca;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:J

.field public final j:Lzca;

.field public k:Lcv1;

.field public l:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Lzs;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Lzca;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Liv1;->a:Lzs;

    .line 5
    .line 6
    iput-object p2, p0, Liv1;->b:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Liv1;->c:Ljava/lang/String;

    .line 9
    .line 10
    iput-wide p4, p0, Liv1;->d:J

    .line 11
    .line 12
    iput-object p6, p0, Liv1;->e:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p7, p0, Liv1;->f:Lzca;

    .line 15
    .line 16
    iput-object p8, p0, Liv1;->g:Ljava/lang/String;

    .line 17
    .line 18
    iget-object p1, p1, Lzs;->a:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 21
    .line 22
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 23
    .line 24
    .line 25
    move-result-wide p1

    .line 26
    iput-wide p1, p0, Liv1;->i:J

    .line 27
    .line 28
    new-instance p1, Lzca;

    .line 29
    .line 30
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 31
    .line 32
    .line 33
    const/4 p2, 0x0

    .line 34
    iput-object p2, p1, Lzca;->a:Ljava/lang/Long;

    .line 35
    .line 36
    iput-object p2, p1, Lzca;->b:Ljava/lang/Long;

    .line 37
    .line 38
    iput-object p1, p0, Liv1;->j:Lzca;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 2

    .line 1
    const-string v0, "AUTO_RESUME"

    .line 2
    .line 3
    iget-object v1, p0, Liv1;->e:Ljava/lang/String;

    .line 4
    .line 5
    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object p0, p0, Liv1;->g:Ljava/lang/String;

    .line 12
    .line 13
    if-eqz p0, :cond_0

    .line 14
    .line 15
    invoke-static {p0}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    :cond_0
    invoke-static {v1}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

.method public final b()I
    .locals 2

    .line 1
    iget-object v0, p0, Liv1;->e:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "AUTO_RESUME"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, Liv1;->f:Lzca;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {v0}, Lzca;->a()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0

    .line 20
    :cond_0
    iget-object p0, p0, Liv1;->j:Lzca;

    .line 21
    .line 22
    invoke-virtual {p0}, Lzca;->a()I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    return p0
.end method

.method public final c(Lfda;)V
    .locals 8

    .line 1
    instance-of v0, p1, Leda;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iget-object p1, p0, Liv1;->e:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {p1}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iget-object v2, p0, Liv1;->c:Ljava/lang/String;

    .line 16
    .line 17
    iget-wide v3, p0, Liv1;->d:J

    .line 18
    .line 19
    sub-long/2addr v0, v3

    .line 20
    long-to-int p0, v0

    .line 21
    const-string v0, "sse_request"

    .line 22
    .line 23
    const-string v1, "stream_scenario"

    .line 24
    .line 25
    const-string v3, "sse_transaction_uuid"

    .line 26
    .line 27
    invoke-static {v1, p1, v3, v2}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const-string/jumbo v1, "time_elapsed"

    .line 32
    .line 33
    .line 34
    invoke-virtual {p1, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 35
    .line 36
    .line 37
    sget-object p0, Lbc1;->a:Ljava/lang/Object;

    .line 38
    .line 39
    monitor-enter p0

    .line 40
    :try_start_0
    sget-object v1, Lbc1;->b:Lmb;

    .line 41
    .line 42
    if-eqz v1, :cond_0

    .line 43
    .line 44
    invoke-virtual {v1, v0, p1}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :catchall_0
    move-exception p1

    .line 49
    goto :goto_1

    .line 50
    :cond_0
    invoke-static {v0, p1}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    .line 52
    .line 53
    :goto_0
    monitor-exit p0

    .line 54
    return-void

    .line 55
    :goto_1
    monitor-exit p0

    .line 56
    throw p1

    .line 57
    :cond_1
    instance-of v0, p1, Lbda;

    .line 58
    .line 59
    if-eqz v0, :cond_4

    .line 60
    .line 61
    check-cast p1, Lbda;

    .line 62
    .line 63
    iget-object p1, p1, Lbda;->a:Lcv1;

    .line 64
    .line 65
    iget-boolean v0, p1, Lcv1;->b:Z

    .line 66
    .line 67
    if-eqz v0, :cond_e

    .line 68
    .line 69
    iget-object v0, p0, Liv1;->j:Lzca;

    .line 70
    .line 71
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 72
    .line 73
    .line 74
    move-result-wide v1

    .line 75
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    iput-object v1, v0, Lzca;->a:Ljava/lang/Long;

    .line 80
    .line 81
    iput-object p1, p0, Liv1;->k:Lcv1;

    .line 82
    .line 83
    iget-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 84
    .line 85
    iget-object v0, p0, Liv1;->c:Ljava/lang/String;

    .line 86
    .line 87
    iget-object v1, p0, Liv1;->e:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v1}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    iget-object v2, p0, Liv1;->j:Lzca;

    .line 94
    .line 95
    iget-object v2, v2, Lzca;->a:Ljava/lang/Long;

    .line 96
    .line 97
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 98
    .line 99
    .line 100
    move-result-wide v2

    .line 101
    iget-wide v4, p0, Liv1;->i:J

    .line 102
    .line 103
    sub-long/2addr v2, v4

    .line 104
    long-to-int v2, v2

    .line 105
    iget-object v3, p0, Liv1;->k:Lcv1;

    .line 106
    .line 107
    if-eqz v3, :cond_2

    .line 108
    .line 109
    iget-object v3, v3, Lcv1;->a:Ljava/lang/String;

    .line 110
    .line 111
    if-nez v3, :cond_3

    .line 112
    .line 113
    :cond_2
    const-string v3, ""

    .line 114
    .line 115
    :cond_3
    const-string v4, "sse_created"

    .line 116
    .line 117
    const-string v5, "chat_session_id"

    .line 118
    .line 119
    const-string v6, "sse_transaction_uuid"

    .line 120
    .line 121
    invoke-static {v5, p1, v6, v0}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 122
    .line 123
    .line 124
    move-result-object p1

    .line 125
    const-string v0, "stream_scenario"

    .line 126
    .line 127
    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 128
    .line 129
    .line 130
    const-string/jumbo v0, "time_elapsed"

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 134
    .line 135
    .line 136
    const-string v0, "http_trace_id"

    .line 137
    .line 138
    invoke-virtual {p1, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 139
    .line 140
    .line 141
    invoke-static {v4, p1}, Lfu0;->s(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 142
    .line 143
    .line 144
    iget-object p1, p0, Liv1;->e:Ljava/lang/String;

    .line 145
    .line 146
    const-string v0, "AUTO_RESUME"

    .line 147
    .line 148
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    if-eqz p1, :cond_e

    .line 153
    .line 154
    iget-object p1, p0, Liv1;->f:Lzca;

    .line 155
    .line 156
    if-eqz p1, :cond_e

    .line 157
    .line 158
    iget-object v0, p0, Liv1;->h:Ljava/lang/String;

    .line 159
    .line 160
    iget-object v1, p0, Liv1;->c:Ljava/lang/String;

    .line 161
    .line 162
    invoke-virtual {p1}, Lzca;->a()I

    .line 163
    .line 164
    .line 165
    move-result p1

    .line 166
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 167
    .line 168
    .line 169
    move-result-wide v2

    .line 170
    iget-wide v4, p0, Liv1;->d:J

    .line 171
    .line 172
    sub-long/2addr v2, v4

    .line 173
    long-to-int p0, v2

    .line 174
    const-string v2, "sse_auto_resume"

    .line 175
    .line 176
    const-string v3, "chat_session_id"

    .line 177
    .line 178
    const-string v4, "sse_transaction_uuid"

    .line 179
    .line 180
    invoke-static {v3, v0, v4, v1}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    const-string v1, "sse_time_elapsed"

    .line 185
    .line 186
    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 187
    .line 188
    .line 189
    const-string/jumbo p1, "time_elapsed"

    .line 190
    .line 191
    .line 192
    invoke-virtual {v0, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 193
    .line 194
    .line 195
    const-string p0, "is_success"

    .line 196
    .line 197
    const/4 p1, 0x1

    .line 198
    invoke-virtual {v0, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 199
    .line 200
    .line 201
    invoke-static {v2, v0}, Lfu0;->s(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 202
    .line 203
    .line 204
    return-void

    .line 205
    :cond_4
    instance-of v0, p1, Ldda;

    .line 206
    .line 207
    if-eqz v0, :cond_6

    .line 208
    .line 209
    iget-object v0, p0, Liv1;->j:Lzca;

    .line 210
    .line 211
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 212
    .line 213
    .line 214
    move-result-wide v1

    .line 215
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    iput-object v1, v0, Lzca;->b:Ljava/lang/Long;

    .line 220
    .line 221
    check-cast p1, Ldda;

    .line 222
    .line 223
    iget-object p1, p1, Ldda;->a:Lwu1;

    .line 224
    .line 225
    iget-object v0, p1, Lwu1;->a:Ljava/lang/Integer;

    .line 226
    .line 227
    iget-object p1, p1, Lwu1;->b:Ljava/lang/Integer;

    .line 228
    .line 229
    iput-object p1, p0, Liv1;->l:Ljava/lang/Integer;

    .line 230
    .line 231
    iget-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 232
    .line 233
    iget-object v1, p0, Liv1;->c:Ljava/lang/String;

    .line 234
    .line 235
    iget-object v2, p0, Liv1;->j:Lzca;

    .line 236
    .line 237
    invoke-virtual {v2}, Lzca;->a()I

    .line 238
    .line 239
    .line 240
    move-result v2

    .line 241
    iget-object v3, p0, Liv1;->e:Ljava/lang/String;

    .line 242
    .line 243
    invoke-static {v3}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object v3

    .line 247
    iget-object v4, p0, Liv1;->l:Ljava/lang/Integer;

    .line 248
    .line 249
    iget-object p0, p0, Liv1;->a:Lzs;

    .line 250
    .line 251
    invoke-virtual {p0}, Lzs;->k()Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object p0

    .line 255
    const-string v5, "sse_ready"

    .line 256
    .line 257
    const-string v6, "chat_session_id"

    .line 258
    .line 259
    const-string v7, "sse_transaction_uuid"

    .line 260
    .line 261
    invoke-static {v6, p1, v7, v1}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 262
    .line 263
    .line 264
    move-result-object v1

    .line 265
    const-string v6, "stream_scenario"

    .line 266
    .line 267
    invoke-virtual {v1, v6, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 268
    .line 269
    .line 270
    const-string v3, "sse_time_elapsed"

    .line 271
    .line 272
    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 273
    .line 274
    .line 275
    const-string v2, "parent_message_id"

    .line 276
    .line 277
    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 278
    .line 279
    .line 280
    const-string v2, "chat_message_id"

    .line 281
    .line 282
    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 283
    .line 284
    .line 285
    const-string v2, "model_type"

    .line 286
    .line 287
    invoke-virtual {v1, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 288
    .line 289
    .line 290
    const-string p0, "full_chat_message_id"

    .line 291
    .line 292
    new-instance v2, Ljava/lang/StringBuilder;

    .line 293
    .line 294
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 298
    .line 299
    .line 300
    const-string v3, ":"

    .line 301
    .line 302
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 303
    .line 304
    .line 305
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 306
    .line 307
    .line 308
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    invoke-virtual {v1, p0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 313
    .line 314
    .line 315
    const-string p0, "full_parent_message_id"

    .line 316
    .line 317
    new-instance v2, Ljava/lang/StringBuilder;

    .line 318
    .line 319
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 320
    .line 321
    .line 322
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 323
    .line 324
    .line 325
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 326
    .line 327
    .line 328
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 329
    .line 330
    .line 331
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object p1

    .line 335
    invoke-virtual {v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 336
    .line 337
    .line 338
    sget-object p0, Lbc1;->a:Ljava/lang/Object;

    .line 339
    .line 340
    monitor-enter p0

    .line 341
    :try_start_1
    sget-object p1, Lbc1;->b:Lmb;

    .line 342
    .line 343
    if-eqz p1, :cond_5

    .line 344
    .line 345
    invoke-virtual {p1, v5, v1}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 346
    .line 347
    .line 348
    goto :goto_2

    .line 349
    :catchall_1
    move-exception p1

    .line 350
    goto :goto_3

    .line 351
    :cond_5
    invoke-static {v5, v1}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 352
    .line 353
    .line 354
    :goto_2
    monitor-exit p0

    .line 355
    return-void

    .line 356
    :goto_3
    monitor-exit p0

    .line 357
    throw p1

    .line 358
    :cond_6
    instance-of v0, p1, Lcda;

    .line 359
    .line 360
    if-eqz v0, :cond_a

    .line 361
    .line 362
    iget-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 363
    .line 364
    iget-object v0, p0, Liv1;->l:Ljava/lang/Integer;

    .line 365
    .line 366
    if-eqz v0, :cond_7

    .line 367
    .line 368
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 369
    .line 370
    .line 371
    move-result v0

    .line 372
    goto :goto_4

    .line 373
    :cond_7
    const/4 v0, 0x0

    .line 374
    :goto_4
    iget-object v1, p0, Liv1;->c:Ljava/lang/String;

    .line 375
    .line 376
    iget-object v2, p0, Liv1;->j:Lzca;

    .line 377
    .line 378
    invoke-virtual {v2}, Lzca;->a()I

    .line 379
    .line 380
    .line 381
    move-result v2

    .line 382
    iget-object v3, p0, Liv1;->e:Ljava/lang/String;

    .line 383
    .line 384
    invoke-static {v3}, Leia;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v3

    .line 388
    iget-object v4, p0, Liv1;->j:Lzca;

    .line 389
    .line 390
    iget-object v4, v4, Lzca;->b:Ljava/lang/Long;

    .line 391
    .line 392
    if-eqz v4, :cond_8

    .line 393
    .line 394
    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    .line 395
    .line 396
    .line 397
    move-result-wide v4

    .line 398
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 399
    .line 400
    .line 401
    move-result-wide v6

    .line 402
    sub-long/2addr v6, v4

    .line 403
    long-to-int v4, v6

    .line 404
    goto :goto_5

    .line 405
    :cond_8
    const/4 v4, -0x1

    .line 406
    :goto_5
    iget-object p0, p0, Liv1;->a:Lzs;

    .line 407
    .line 408
    invoke-virtual {p0}, Lzs;->k()Ljava/lang/String;

    .line 409
    .line 410
    .line 411
    move-result-object p0

    .line 412
    const-string v5, "sse_first_delta"

    .line 413
    .line 414
    const-string v6, "chat_session_id"

    .line 415
    .line 416
    const-string v7, "chat_message_id"

    .line 417
    .line 418
    invoke-static {v0, v6, p1, v7}, Lbd1;->p(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 419
    .line 420
    .line 421
    move-result-object v6

    .line 422
    const-string v7, "sse_transaction_uuid"

    .line 423
    .line 424
    invoke-virtual {v6, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 425
    .line 426
    .line 427
    const-string v1, "stream_scenario"

    .line 428
    .line 429
    invoke-virtual {v6, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 430
    .line 431
    .line 432
    const-string v1, "sse_time_elapsed"

    .line 433
    .line 434
    invoke-virtual {v6, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 435
    .line 436
    .line 437
    const-string/jumbo v1, "time_elapsed"

    .line 438
    .line 439
    .line 440
    invoke-virtual {v6, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 441
    .line 442
    .line 443
    const-string v1, "model_type"

    .line 444
    .line 445
    invoke-virtual {v6, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 446
    .line 447
    .line 448
    const-string p0, "full_chat_message_id"

    .line 449
    .line 450
    new-instance v1, Ljava/lang/StringBuilder;

    .line 451
    .line 452
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 453
    .line 454
    .line 455
    const-string v2, ":"

    .line 456
    .line 457
    invoke-static {v1, p1, v2, v0}, Lwla;->l(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 458
    .line 459
    .line 460
    move-result-object p1

    .line 461
    invoke-virtual {v6, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 462
    .line 463
    .line 464
    sget-object p0, Lbc1;->a:Ljava/lang/Object;

    .line 465
    .line 466
    monitor-enter p0

    .line 467
    :try_start_2
    sget-object p1, Lbc1;->b:Lmb;

    .line 468
    .line 469
    if-eqz p1, :cond_9

    .line 470
    .line 471
    invoke-virtual {p1, v5, v6}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 472
    .line 473
    .line 474
    goto :goto_6

    .line 475
    :catchall_2
    move-exception p1

    .line 476
    goto :goto_7

    .line 477
    :cond_9
    invoke-static {v5, v6}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 478
    .line 479
    .line 480
    :goto_6
    monitor-exit p0

    .line 481
    return-void

    .line 482
    :goto_7
    monitor-exit p0

    .line 483
    throw p1

    .line 484
    :cond_a
    instance-of v0, p1, Lada;

    .line 485
    .line 486
    if-eqz v0, :cond_f

    .line 487
    .line 488
    check-cast p1, Lada;

    .line 489
    .line 490
    iget-object p1, p1, Lada;->a:Lf62;

    .line 491
    .line 492
    if-eqz p1, :cond_c

    .line 493
    .line 494
    invoke-virtual {p1}, Lf62;->b()Z

    .line 495
    .line 496
    .line 497
    move-result v0

    .line 498
    if-eqz v0, :cond_c

    .line 499
    .line 500
    iget-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 501
    .line 502
    iget-object v0, p0, Liv1;->c:Ljava/lang/String;

    .line 503
    .line 504
    invoke-virtual {p0}, Liv1;->b()I

    .line 505
    .line 506
    .line 507
    move-result v1

    .line 508
    invoke-virtual {p0}, Liv1;->a()Ljava/lang/String;

    .line 509
    .line 510
    .line 511
    move-result-object p0

    .line 512
    const-string v2, "sse_finished"

    .line 513
    .line 514
    const-string v3, "chat_session_id"

    .line 515
    .line 516
    const-string v4, "sse_transaction_uuid"

    .line 517
    .line 518
    invoke-static {v3, p1, v4, v0}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 519
    .line 520
    .line 521
    move-result-object p1

    .line 522
    const-string v0, "sse_time_elapsed"

    .line 523
    .line 524
    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 525
    .line 526
    .line 527
    const-string v0, "stream_scenario"

    .line 528
    .line 529
    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 530
    .line 531
    .line 532
    sget-object p0, Lbc1;->a:Ljava/lang/Object;

    .line 533
    .line 534
    monitor-enter p0

    .line 535
    :try_start_3
    sget-object v0, Lbc1;->b:Lmb;

    .line 536
    .line 537
    if-eqz v0, :cond_b

    .line 538
    .line 539
    invoke-virtual {v0, v2, p1}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 540
    .line 541
    .line 542
    goto :goto_8

    .line 543
    :catchall_3
    move-exception p1

    .line 544
    goto :goto_9

    .line 545
    :cond_b
    invoke-static {v2, p1}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 546
    .line 547
    .line 548
    :goto_8
    monitor-exit p0

    .line 549
    return-void

    .line 550
    :goto_9
    monitor-exit p0

    .line 551
    throw p1

    .line 552
    :cond_c
    if-eqz p1, :cond_e

    .line 553
    .line 554
    invoke-virtual {p1}, Lf62;->b()Z

    .line 555
    .line 556
    .line 557
    move-result p1

    .line 558
    if-nez p1, :cond_e

    .line 559
    .line 560
    iget-object p1, p0, Liv1;->h:Ljava/lang/String;

    .line 561
    .line 562
    iget-object v0, p0, Liv1;->c:Ljava/lang/String;

    .line 563
    .line 564
    invoke-virtual {p0}, Liv1;->b()I

    .line 565
    .line 566
    .line 567
    move-result v1

    .line 568
    invoke-virtual {p0}, Liv1;->a()Ljava/lang/String;

    .line 569
    .line 570
    .line 571
    move-result-object p0

    .line 572
    const-string v2, "sse_disconnected"

    .line 573
    .line 574
    const-string v3, "chat_session_id"

    .line 575
    .line 576
    const-string v4, "sse_transaction_uuid"

    .line 577
    .line 578
    invoke-static {v3, p1, v4, v0}, Lwla;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 579
    .line 580
    .line 581
    move-result-object p1

    .line 582
    const-string v0, "sse_time_elapsed"

    .line 583
    .line 584
    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 585
    .line 586
    .line 587
    const-string v0, "stream_scenario"

    .line 588
    .line 589
    invoke-virtual {p1, v0, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 590
    .line 591
    .line 592
    sget-object p0, Lbc1;->a:Ljava/lang/Object;

    .line 593
    .line 594
    monitor-enter p0

    .line 595
    :try_start_4
    sget-object v0, Lbc1;->b:Lmb;

    .line 596
    .line 597
    if-eqz v0, :cond_d

    .line 598
    .line 599
    invoke-virtual {v0, v2, p1}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 600
    .line 601
    .line 602
    goto :goto_a

    .line 603
    :catchall_4
    move-exception p1

    .line 604
    goto :goto_b

    .line 605
    :cond_d
    invoke-static {v2, p1}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 606
    .line 607
    .line 608
    :goto_a
    monitor-exit p0

    .line 609
    return-void

    .line 610
    :goto_b
    monitor-exit p0

    .line 611
    throw p1

    .line 612
    :cond_e
    return-void

    .line 613
    :cond_f
    invoke-static {}, Lgf3;->d()V

    .line 614
    .line 615
    .line 616
    return-void
.end method
