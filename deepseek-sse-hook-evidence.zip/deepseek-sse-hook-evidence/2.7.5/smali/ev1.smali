.class public final Lev1;
.super Ljava/lang/Object;
.source "r8-map-id-2e17ac06b3663e3b6803a43c074ce5b2710eae1d5a807a22099ba6599b707f30"

# interfaces
.implements Lfv1;


# instance fields
.field public final a:Lbia;


# direct methods
.method public constructor <init>(Lbia;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lev1;->a:Lbia;

    .line 5
    .line 6
    return-void
.end method
