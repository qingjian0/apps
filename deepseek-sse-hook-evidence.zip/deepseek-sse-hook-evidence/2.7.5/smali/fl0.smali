.class public final synthetic Lfl0;
.super Ljava/lang/Object;
.source "r8-map-id-2e17ac06b3663e3b6803a43c074ce5b2710eae1d5a807a22099ba6599b707f30"

# interfaces
.implements Ln25;


# static fields
.field public static final a:Lfl0;

.field private static final descriptor:Lyr9;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lfl0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lfl0;->a:Lfl0;

    .line 7
    .line 8
    new-instance v1, Lur5;

    .line 9
    .line 10
    const-string v2, "com.deepseek.chat.domain.chat.model.completion.message.fragments.BaseToolOpenFragment.Status"

    .line 11
    .line 12
    invoke-direct {v1, v2, v0}, Lur5;-><init>(Ljava/lang/String;Ln25;)V

    .line 13
    .line 14
    .line 15
    const-string/jumbo v0, "value"

    .line 16
    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, v0, v2}, Lzj8;->j(Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    sput-object v1, Lfl0;->descriptor:Lyr9;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a()Lyr9;
    .locals 0

    .line 1
    sget-object p0, Lfl0;->descriptor:Lyr9;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()[Lbb6;
    .locals 2

    .line 1
    const/4 p0, 0x1

    .line 2
    new-array p0, p0, [Lbb6;

    .line 3
    .line 4
    sget-object v0, Lgja;->a:Lgja;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    aput-object v0, p0, v1

    .line 8
    .line 9
    return-object p0
.end method

.method public final d(Lwn3;)Ljava/lang/Object;
    .locals 0

    .line 1
    sget-object p0, Lfl0;->descriptor:Lyr9;

    .line 2
    .line 3
    invoke-interface {p1, p0}, Lwn3;->q(Lyr9;)Lwn3;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Lwn3;->t()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    new-instance p1, Lhl0;

    .line 12
    .line 13
    invoke-direct {p1, p0}, Lhl0;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object p1
.end method

.method public final e(Laa4;Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p2, Lhl0;

    .line 2
    .line 3
    iget-object p0, p2, Lhl0;->a:Ljava/lang/String;

    .line 4
    .line 5
    sget-object p2, Lfl0;->descriptor:Lyr9;

    .line 6
    .line 7
    invoke-interface {p1, p2}, Laa4;->l(Lyr9;)Laa4;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    if-nez p1, :cond_0

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    invoke-interface {p1, p0}, Laa4;->F(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
