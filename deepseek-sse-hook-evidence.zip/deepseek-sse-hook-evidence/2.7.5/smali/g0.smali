.class public final Lg0;
.super Lgna;
.source "r8-map-id-2e17ac06b3663e3b6803a43c074ce5b2710eae1d5a807a22099ba6599b707f30"

# interfaces
.implements Lzy4;


# instance fields
.field public final synthetic e:I

.field public f:J

.field public g:I

.field public h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IJLdc3;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 17
    iput p1, p0, Lg0;->e:I

    iput-object p5, p0, Lg0;->i:Ljava/lang/Object;

    iput-wide p2, p0, Lg0;->f:J

    iput-object p6, p0, Lg0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lgna;-><init>(ILdc3;)V

    return-void
.end method

.method public constructor <init>(JLrbb;Ljava/lang/String;Ljava/lang/String;Ldc3;)V
    .locals 1

    .line 1
    const/4 v0, 0x7

    .line 2
    iput v0, p0, Lg0;->e:I

    .line 3
    .line 4
    iput-wide p1, p0, Lg0;->f:J

    .line 5
    .line 6
    iput-object p3, p0, Lg0;->h:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p4, p0, Lg0;->i:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p5, p0, Lg0;->j:Ljava/lang/Object;

    .line 11
    .line 12
    const/4 p1, 0x2

    .line 13
    invoke-direct {p0, p1, p6}, Lgna;-><init>(ILdc3;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Ljj8;Ljava/lang/CharSequence;JLfwa;Ldc3;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, Lg0;->e:I

    .line 20
    iput-object p1, p0, Lg0;->h:Ljava/lang/Object;

    iput-object p2, p0, Lg0;->i:Ljava/lang/Object;

    iput-wide p3, p0, Lg0;->f:J

    iput-object p5, p0, Lg0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lgna;-><init>(ILdc3;)V

    return-void
.end method

.method public constructor <init>(Ljl4;Ljava/lang/String;Ldc3;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lg0;->e:I

    .line 18
    iput-object p1, p0, Lg0;->i:Ljava/lang/Object;

    iput-object p2, p0, Lg0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lgna;-><init>(ILdc3;)V

    return-void
.end method

.method public constructor <init>(Lkj6;Lyi4;JLdc3;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lg0;->e:I

    .line 19
    iput-object p1, p0, Lg0;->i:Ljava/lang/Object;

    iput-object p2, p0, Lg0;->j:Ljava/lang/Object;

    iput-wide p3, p0, Lg0;->f:J

    invoke-direct {p0, v0, p5}, Lgna;-><init>(ILdc3;)V

    return-void
.end method

.method public constructor <init>(Lyta;JLcua;Lxta;Ldc3;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, Lg0;->e:I

    .line 21
    iput-object p1, p0, Lg0;->h:Ljava/lang/Object;

    iput-wide p2, p0, Lg0;->f:J

    iput-object p4, p0, Lg0;->i:Ljava/lang/Object;

    iput-object p5, p0, Lg0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Lgna;-><init>(ILdc3;)V

    return-void
.end method


# virtual methods
.method public final q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Lg0;->e:I

    .line 2
    .line 3
    sget-object v1, Lghb;->a:Lghb;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lgd3;

    .line 9
    .line 10
    check-cast p2, Ldc3;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lg0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lgd3;

    .line 24
    .line 25
    check-cast p2, Ldc3;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lg0;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_1
    check-cast p1, Lgd3;

    .line 39
    .line 40
    check-cast p2, Ldc3;

    .line 41
    .line 42
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Lg0;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_2
    check-cast p1, Lgd3;

    .line 54
    .line 55
    check-cast p2, Ldc3;

    .line 56
    .line 57
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    check-cast p0, Lg0;

    .line 62
    .line 63
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_3
    check-cast p1, Lrk9;

    .line 69
    .line 70
    check-cast p2, Ldc3;

    .line 71
    .line 72
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    check-cast p0, Lg0;

    .line 77
    .line 78
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    return-object p0

    .line 83
    :pswitch_4
    check-cast p1, Lgd3;

    .line 84
    .line 85
    check-cast p2, Ldc3;

    .line 86
    .line 87
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    check-cast p0, Lg0;

    .line 92
    .line 93
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0

    .line 98
    :pswitch_5
    check-cast p1, Leh5;

    .line 99
    .line 100
    check-cast p2, Ldc3;

    .line 101
    .line 102
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    check-cast p0, Lg0;

    .line 107
    .line 108
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    return-object p0

    .line 113
    :pswitch_6
    check-cast p1, Lgd3;

    .line 114
    .line 115
    check-cast p2, Ldc3;

    .line 116
    .line 117
    invoke-virtual {p0, p2, p1}, Lg0;->x(Ldc3;Ljava/lang/Object;)Ldc3;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    check-cast p0, Lg0;

    .line 122
    .line 123
    invoke-virtual {p0, v1}, Lg0;->z(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    return-object p0

    .line 128
    nop

    .line 129
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final x(Ldc3;Ljava/lang/Object;)Ldc3;
    .locals 11

    .line 1
    iget v0, p0, Lg0;->e:I

    .line 2
    .line 3
    iget-object v1, p0, Lg0;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lg0;->i:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    new-instance v3, Lg0;

    .line 11
    .line 12
    iget-wide v4, p0, Lg0;->f:J

    .line 13
    .line 14
    iget-object p0, p0, Lg0;->h:Ljava/lang/Object;

    .line 15
    .line 16
    move-object v6, p0

    .line 17
    check-cast v6, Lrbb;

    .line 18
    .line 19
    move-object v7, v2

    .line 20
    check-cast v7, Ljava/lang/String;

    .line 21
    .line 22
    move-object v8, v1

    .line 23
    check-cast v8, Ljava/lang/String;

    .line 24
    .line 25
    move-object v9, p1

    .line 26
    invoke-direct/range {v3 .. v9}, Lg0;-><init>(JLrbb;Ljava/lang/String;Ljava/lang/String;Ldc3;)V

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :pswitch_0
    move-object v8, p1

    .line 31
    new-instance v4, Lg0;

    .line 32
    .line 33
    move-object v9, v2

    .line 34
    check-cast v9, Lfwa;

    .line 35
    .line 36
    iget-wide v6, p0, Lg0;->f:J

    .line 37
    .line 38
    move-object v10, v1

    .line 39
    check-cast v10, Lkn7;

    .line 40
    .line 41
    const/4 v5, 0x6

    .line 42
    invoke-direct/range {v4 .. v10}, Lg0;-><init>(IJLdc3;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-object v4

    .line 46
    :pswitch_1
    move-object v8, p1

    .line 47
    new-instance v4, Lg0;

    .line 48
    .line 49
    iget-object p1, p0, Lg0;->h:Ljava/lang/Object;

    .line 50
    .line 51
    move-object v5, p1

    .line 52
    check-cast v5, Ljj8;

    .line 53
    .line 54
    move-object v6, v2

    .line 55
    check-cast v6, Ljava/lang/CharSequence;

    .line 56
    .line 57
    move-object v9, v8

    .line 58
    iget-wide v7, p0, Lg0;->f:J

    .line 59
    .line 60
    check-cast v1, Lfwa;

    .line 61
    .line 62
    move-object v10, v9

    .line 63
    move-object v9, v1

    .line 64
    invoke-direct/range {v4 .. v10}, Lg0;-><init>(Ljj8;Ljava/lang/CharSequence;JLfwa;Ldc3;)V

    .line 65
    .line 66
    .line 67
    return-object v4

    .line 68
    :pswitch_2
    move-object v8, p1

    .line 69
    new-instance v4, Lg0;

    .line 70
    .line 71
    iget-object p1, p0, Lg0;->h:Ljava/lang/Object;

    .line 72
    .line 73
    move-object v5, p1

    .line 74
    check-cast v5, Lyta;

    .line 75
    .line 76
    iget-wide v6, p0, Lg0;->f:J

    .line 77
    .line 78
    check-cast v2, Lcua;

    .line 79
    .line 80
    move-object v9, v1

    .line 81
    check-cast v9, Lxta;

    .line 82
    .line 83
    move-object v10, v8

    .line 84
    move-object v8, v2

    .line 85
    invoke-direct/range {v4 .. v10}, Lg0;-><init>(Lyta;JLcua;Lxta;Ldc3;)V

    .line 86
    .line 87
    .line 88
    return-object v4

    .line 89
    :pswitch_3
    move-object v8, p1

    .line 90
    new-instance v4, Lg0;

    .line 91
    .line 92
    move-object v9, v2

    .line 93
    check-cast v9, Ltk9;

    .line 94
    .line 95
    iget-wide v6, p0, Lg0;->f:J

    .line 96
    .line 97
    move-object v10, v1

    .line 98
    check-cast v10, La29;

    .line 99
    .line 100
    const/4 v5, 0x3

    .line 101
    invoke-direct/range {v4 .. v10}, Lg0;-><init>(IJLdc3;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    iput-object p2, v4, Lg0;->h:Ljava/lang/Object;

    .line 105
    .line 106
    return-object v4

    .line 107
    :pswitch_4
    move-object v8, p1

    .line 108
    new-instance v4, Lg0;

    .line 109
    .line 110
    move-object v5, v2

    .line 111
    check-cast v5, Lkj6;

    .line 112
    .line 113
    move-object v6, v1

    .line 114
    check-cast v6, Lyi4;

    .line 115
    .line 116
    move-object v9, v8

    .line 117
    iget-wide v7, p0, Lg0;->f:J

    .line 118
    .line 119
    invoke-direct/range {v4 .. v9}, Lg0;-><init>(Lkj6;Lyi4;JLdc3;)V

    .line 120
    .line 121
    .line 122
    return-object v4

    .line 123
    :pswitch_5
    move-object v8, p1

    .line 124
    new-instance p0, Lg0;

    .line 125
    .line 126
    check-cast v2, Ljl4;

    .line 127
    .line 128
    check-cast v1, Ljava/lang/String;

    .line 129
    .line 130
    invoke-direct {p0, v2, v1, v8}, Lg0;-><init>(Ljl4;Ljava/lang/String;Ldc3;)V

    .line 131
    .line 132
    .line 133
    iput-object p2, p0, Lg0;->h:Ljava/lang/Object;

    .line 134
    .line 135
    return-object p0

    .line 136
    :pswitch_6
    move-object v8, p1

    .line 137
    new-instance v4, Lg0;

    .line 138
    .line 139
    move-object v9, v2

    .line 140
    check-cast v9, Li06;

    .line 141
    .line 142
    iget-wide v6, p0, Lg0;->f:J

    .line 143
    .line 144
    move-object v10, v1

    .line 145
    check-cast v10, Lkn7;

    .line 146
    .line 147
    const/4 v5, 0x0

    .line 148
    invoke-direct/range {v4 .. v10}, Lg0;-><init>(IJLdc3;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    return-object v4

    .line 152
    nop

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final z(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 31

    .line 1
    move-object/from16 v4, p0

    .line 2
    .line 3
    iget v0, v4, Lg0;->e:I

    .line 4
    .line 5
    const/4 v1, 0x3

    .line 6
    const/4 v7, 0x0

    .line 7
    const/4 v2, 0x4

    .line 8
    const/4 v3, 0x2

    .line 9
    iget-object v5, v4, Lg0;->j:Ljava/lang/Object;

    .line 10
    .line 11
    const-string v6, "call to \'resume\' before \'invoke\' with coroutine"

    .line 12
    .line 13
    sget-object v8, Lhd3;->a:Lhd3;

    .line 14
    .line 15
    const/4 v9, 0x1

    .line 16
    sget-object v10, Lghb;->a:Lghb;

    .line 17
    .line 18
    iget-object v11, v4, Lg0;->i:Ljava/lang/Object;

    .line 19
    .line 20
    const/4 v12, 0x0

    .line 21
    packed-switch v0, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    check-cast v11, Ljava/lang/String;

    .line 25
    .line 26
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 27
    .line 28
    move-object v1, v0

    .line 29
    check-cast v1, Lrbb;

    .line 30
    .line 31
    iget-object v7, v1, Lrbb;->d:Lps6;

    .line 32
    .line 33
    iget v0, v4, Lg0;->g:I

    .line 34
    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    if-ne v0, v9, :cond_0

    .line 38
    .line 39
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    move-object/from16 v0, p1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    move-object v8, v12

    .line 49
    goto/16 :goto_3

    .line 50
    .line 51
    :cond_1
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    sget-object v0, Lq44;->b:Ld00;

    .line 55
    .line 56
    const-wide/16 v13, 0x7d0

    .line 57
    .line 58
    sget-object v0, Lu44;->d:Lu44;

    .line 59
    .line 60
    invoke-static {v13, v14, v0}, Li6b;->g0(JLu44;)J

    .line 61
    .line 62
    .line 63
    move-result-wide v13

    .line 64
    new-instance v0, Lv8b;

    .line 65
    .line 66
    check-cast v5, Ljava/lang/String;

    .line 67
    .line 68
    invoke-direct {v0, v1, v5, v12, v2}, Lv8b;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ldc3;I)V

    .line 69
    .line 70
    .line 71
    iput v9, v4, Lg0;->g:I

    .line 72
    .line 73
    invoke-static {v13, v14, v0, v4}, Lm07;->T(JLzy4;Ldc3;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    if-ne v0, v8, :cond_2

    .line 78
    .line 79
    goto/16 :goto_3

    .line 80
    .line 81
    :cond_2
    :goto_0
    check-cast v0, Ljava/io/File;

    .line 82
    .line 83
    iget-wide v4, v4, Lg0;->f:J

    .line 84
    .line 85
    iget-wide v12, v1, Lrbb;->h:J

    .line 86
    .line 87
    cmp-long v2, v4, v12

    .line 88
    .line 89
    if-eqz v2, :cond_3

    .line 90
    .line 91
    :goto_1
    move-object v8, v10

    .line 92
    goto/16 :goto_3

    .line 93
    .line 94
    :cond_3
    if-nez v0, :cond_4

    .line 95
    .line 96
    new-instance v0, Ljava/lang/StringBuilder;

    .line 97
    .line 98
    const-string v2, "play: obtain audio timed out or failed, voice="

    .line 99
    .line 100
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-virtual {v7, v0}, Lps6;->e(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    new-instance v0, Llbb;

    .line 114
    .line 115
    invoke-direct {v0, v11}, Llbb;-><init>(Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v1, v0}, Lrbb;->e(Lpbb;)V

    .line 119
    .line 120
    .line 121
    goto :goto_1

    .line 122
    :cond_4
    :try_start_0
    new-instance v2, Landroid/media/MediaPlayer;

    .line 123
    .line 124
    invoke-direct {v2}, Landroid/media/MediaPlayer;-><init>()V

    .line 125
    .line 126
    .line 127
    iput-object v2, v1, Lrbb;->i:Landroid/media/MediaPlayer;

    .line 128
    .line 129
    new-instance v6, Landroid/media/AudioAttributes$Builder;

    .line 130
    .line 131
    invoke-direct {v6}, Landroid/media/AudioAttributes$Builder;-><init>()V

    .line 132
    .line 133
    .line 134
    iget-boolean v8, v1, Lrbb;->c:Z

    .line 135
    .line 136
    if-eqz v8, :cond_5

    .line 137
    .line 138
    goto :goto_2

    .line 139
    :cond_5
    move v3, v9

    .line 140
    :goto_2
    invoke-virtual {v6, v3}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    invoke-virtual {v3, v9}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    invoke-virtual {v3}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    invoke-virtual {v2, v3}, Landroid/media/MediaPlayer;->setAudioAttributes(Landroid/media/AudioAttributes;)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v0

    .line 159
    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    new-instance v0, Libb;

    .line 163
    .line 164
    invoke-direct {v0, v4, v5, v1, v11}, Libb;-><init>(JLrbb;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 168
    .line 169
    .line 170
    new-instance v0, Ljbb;

    .line 171
    .line 172
    invoke-direct {v0, v4, v5, v1}, Ljbb;-><init>(JLrbb;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 176
    .line 177
    .line 178
    new-instance v0, Lkbb;

    .line 179
    .line 180
    invoke-direct {v0, v4, v5, v1, v11}, Lkbb;-><init>(JLrbb;Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v2, v0}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v2}, Landroid/media/MediaPlayer;->prepareAsync()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 187
    .line 188
    .line 189
    goto :goto_1

    .line 190
    :catch_0
    move-exception v0

    .line 191
    new-instance v2, Ljava/lang/StringBuilder;

    .line 192
    .line 193
    const-string v3, "play: prepare failed, voice="

    .line 194
    .line 195
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 199
    .line 200
    .line 201
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v2

    .line 205
    invoke-virtual {v7, v2, v0}, Lps6;->f(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 206
    .line 207
    .line 208
    new-instance v0, Llbb;

    .line 209
    .line 210
    invoke-direct {v0, v11}, Llbb;-><init>(Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v1, v0}, Lrbb;->e(Lpbb;)V

    .line 214
    .line 215
    .line 216
    goto :goto_1

    .line 217
    :goto_3
    return-object v8

    .line 218
    :pswitch_0
    check-cast v5, Lkn7;

    .line 219
    .line 220
    check-cast v11, Lfwa;

    .line 221
    .line 222
    iget v0, v4, Lg0;->g:I

    .line 223
    .line 224
    if-eqz v0, :cond_8

    .line 225
    .line 226
    if-eq v0, v9, :cond_7

    .line 227
    .line 228
    if-ne v0, v3, :cond_6

    .line 229
    .line 230
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v0, Lun8;

    .line 233
    .line 234
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    goto :goto_5

    .line 238
    :cond_6
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    move-object v8, v12

    .line 242
    goto :goto_6

    .line 243
    :cond_7
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 244
    .line 245
    check-cast v0, Lfwa;

    .line 246
    .line 247
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    goto :goto_4

    .line 251
    :cond_8
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    iget-object v0, v11, Lfwa;->w:Lun8;

    .line 255
    .line 256
    if-eqz v0, :cond_a

    .line 257
    .line 258
    new-instance v1, Ltn8;

    .line 259
    .line 260
    invoke-direct {v1, v0}, Ltn8;-><init>(Lun8;)V

    .line 261
    .line 262
    .line 263
    iput-object v11, v4, Lg0;->h:Ljava/lang/Object;

    .line 264
    .line 265
    iput v9, v4, Lg0;->g:I

    .line 266
    .line 267
    invoke-interface {v5, v1, v4}, Lkn7;->b(Ltv5;Ldc3;)Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    if-ne v0, v8, :cond_9

    .line 272
    .line 273
    goto :goto_6

    .line 274
    :cond_9
    move-object v0, v11

    .line 275
    :goto_4
    iput-object v12, v0, Lfwa;->w:Lun8;

    .line 276
    .line 277
    :cond_a
    new-instance v0, Lun8;

    .line 278
    .line 279
    iget-wide v1, v4, Lg0;->f:J

    .line 280
    .line 281
    invoke-direct {v0, v1, v2}, Lun8;-><init>(J)V

    .line 282
    .line 283
    .line 284
    iput-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 285
    .line 286
    iput v3, v4, Lg0;->g:I

    .line 287
    .line 288
    invoke-interface {v5, v0, v4}, Lkn7;->b(Ltv5;Ldc3;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v1

    .line 292
    if-ne v1, v8, :cond_b

    .line 293
    .line 294
    goto :goto_6

    .line 295
    :cond_b
    :goto_5
    iput-object v0, v11, Lfwa;->w:Lun8;

    .line 296
    .line 297
    move-object v8, v10

    .line 298
    :goto_6
    return-object v8

    .line 299
    :pswitch_1
    iget-wide v14, v4, Lg0;->f:J

    .line 300
    .line 301
    move-object/from16 v18, v11

    .line 302
    .line 303
    check-cast v18, Ljava/lang/CharSequence;

    .line 304
    .line 305
    check-cast v5, Lfwa;

    .line 306
    .line 307
    iget-object v0, v5, Lfwa;->a:Lh4b;

    .line 308
    .line 309
    iget v1, v4, Lg0;->g:I

    .line 310
    .line 311
    if-eqz v1, :cond_d

    .line 312
    .line 313
    if-ne v1, v9, :cond_c

    .line 314
    .line 315
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 316
    .line 317
    .line 318
    move-object/from16 v1, p1

    .line 319
    .line 320
    move-object/from16 v11, v18

    .line 321
    .line 322
    goto :goto_9

    .line 323
    :cond_c
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    move-object v8, v12

    .line 327
    goto :goto_a

    .line 328
    :cond_d
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 329
    .line 330
    .line 331
    iget-object v1, v4, Lg0;->h:Ljava/lang/Object;

    .line 332
    .line 333
    check-cast v1, Ljj8;

    .line 334
    .line 335
    iput v9, v4, Lg0;->g:I

    .line 336
    .line 337
    move-object/from16 v17, v1

    .line 338
    .line 339
    check-cast v17, Loj8;

    .line 340
    .line 341
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 342
    .line 343
    .line 344
    invoke-interface/range {v18 .. v18}, Ljava/lang/CharSequence;->length()I

    .line 345
    .line 346
    .line 347
    move-result v1

    .line 348
    if-nez v1, :cond_e

    .line 349
    .line 350
    goto :goto_7

    .line 351
    :cond_e
    invoke-static {v14, v15}, Lrxa;->b(J)Z

    .line 352
    .line 353
    .line 354
    move-result v1

    .line 355
    if-eqz v1, :cond_f

    .line 356
    .line 357
    :goto_7
    move-object v1, v12

    .line 358
    move-object/from16 v11, v18

    .line 359
    .line 360
    goto :goto_8

    .line 361
    :cond_f
    new-instance v13, Lnj8;

    .line 362
    .line 363
    const/16 v16, 0x0

    .line 364
    .line 365
    invoke-direct/range {v13 .. v18}, Lnj8;-><init>(JLdc3;Loj8;Ljava/lang/CharSequence;)V

    .line 366
    .line 367
    .line 368
    move-object/from16 v1, v17

    .line 369
    .line 370
    move-object/from16 v11, v18

    .line 371
    .line 372
    iget-object v2, v1, Loj8;->a:Lyc3;

    .line 373
    .line 374
    new-instance v3, Lmj8;

    .line 375
    .line 376
    invoke-direct {v3, v1, v13, v12}, Lmj8;-><init>(Loj8;Lzy4;Ldc3;)V

    .line 377
    .line 378
    .line 379
    invoke-static {v2, v3, v4}, Lyu7;->T(Lyc3;Lzy4;Ldc3;)Ljava/lang/Object;

    .line 380
    .line 381
    .line 382
    move-result-object v1

    .line 383
    :goto_8
    if-ne v1, v8, :cond_10

    .line 384
    .line 385
    goto :goto_a

    .line 386
    :cond_10
    :goto_9
    check-cast v1, Lrxa;

    .line 387
    .line 388
    if-eqz v1, :cond_11

    .line 389
    .line 390
    iget-wide v1, v1, Lrxa;->a:J

    .line 391
    .line 392
    invoke-virtual {v0}, Lh4b;->d()Lpua;

    .line 393
    .line 394
    .line 395
    move-result-object v3

    .line 396
    iget-object v3, v3, Lpua;->c:Ljava/lang/CharSequence;

    .line 397
    .line 398
    invoke-static {v3, v11}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 399
    .line 400
    .line 401
    move-result v3

    .line 402
    if-eqz v3, :cond_11

    .line 403
    .line 404
    invoke-virtual {v0}, Lh4b;->d()Lpua;

    .line 405
    .line 406
    .line 407
    move-result-object v3

    .line 408
    iget-wide v3, v3, Lpua;->d:J

    .line 409
    .line 410
    invoke-static {v3, v4, v14, v15}, Lrxa;->a(JJ)Z

    .line 411
    .line 412
    .line 413
    move-result v3

    .line 414
    if-eqz v3, :cond_11

    .line 415
    .line 416
    invoke-virtual {v0}, Lh4b;->d()Lpua;

    .line 417
    .line 418
    .line 419
    move-result-object v3

    .line 420
    iget-wide v3, v3, Lpua;->d:J

    .line 421
    .line 422
    invoke-static {v1, v2, v3, v4}, Lrxa;->a(JJ)Z

    .line 423
    .line 424
    .line 425
    move-result v3

    .line 426
    if-nez v3, :cond_11

    .line 427
    .line 428
    invoke-virtual {v0, v1, v2}, Lh4b;->j(J)V

    .line 429
    .line 430
    .line 431
    :cond_11
    move-object v8, v10

    .line 432
    :goto_a
    return-object v8

    .line 433
    :pswitch_2
    iget v0, v4, Lg0;->g:I

    .line 434
    .line 435
    if-eqz v0, :cond_14

    .line 436
    .line 437
    if-eq v0, v9, :cond_13

    .line 438
    .line 439
    if-ne v0, v3, :cond_12

    .line 440
    .line 441
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 442
    .line 443
    .line 444
    goto :goto_c

    .line 445
    :cond_12
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 446
    .line 447
    .line 448
    move-object v8, v12

    .line 449
    goto :goto_d

    .line 450
    :cond_13
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 451
    .line 452
    .line 453
    goto :goto_b

    .line 454
    :cond_14
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 455
    .line 456
    .line 457
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v0, Lyta;

    .line 460
    .line 461
    iget-object v0, v0, Lyta;->q:Lzy4;

    .line 462
    .line 463
    if-eqz v0, :cond_15

    .line 464
    .line 465
    iget-wide v1, v4, Lg0;->f:J

    .line 466
    .line 467
    new-instance v6, Lsz7;

    .line 468
    .line 469
    invoke-direct {v6, v1, v2}, Lsz7;-><init>(J)V

    .line 470
    .line 471
    .line 472
    iput v9, v4, Lg0;->g:I

    .line 473
    .line 474
    invoke-interface {v0, v6, v4}, Lzy4;->q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    if-ne v0, v8, :cond_15

    .line 479
    .line 480
    goto :goto_d

    .line 481
    :cond_15
    :goto_b
    check-cast v11, Lcua;

    .line 482
    .line 483
    check-cast v5, Lxta;

    .line 484
    .line 485
    iput v3, v4, Lg0;->g:I

    .line 486
    .line 487
    invoke-interface {v11, v5, v4}, Lcua;->a(Luta;Lgna;)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    if-ne v0, v8, :cond_16

    .line 492
    .line 493
    goto :goto_d

    .line 494
    :cond_16
    :goto_c
    move-object v8, v10

    .line 495
    :goto_d
    return-object v8

    .line 496
    :pswitch_3
    check-cast v11, Ltk9;

    .line 497
    .line 498
    iget v0, v4, Lg0;->g:I

    .line 499
    .line 500
    if-eqz v0, :cond_18

    .line 501
    .line 502
    if-ne v0, v9, :cond_17

    .line 503
    .line 504
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 505
    .line 506
    .line 507
    goto :goto_e

    .line 508
    :cond_17
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 509
    .line 510
    .line 511
    move-object v8, v12

    .line 512
    goto :goto_f

    .line 513
    :cond_18
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 514
    .line 515
    .line 516
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 517
    .line 518
    check-cast v0, Lrk9;

    .line 519
    .line 520
    iget-wide v1, v4, Lg0;->f:J

    .line 521
    .line 522
    invoke-virtual {v11, v1, v2}, Ltk9;->h(J)F

    .line 523
    .line 524
    .line 525
    move-result v1

    .line 526
    check-cast v5, La29;

    .line 527
    .line 528
    new-instance v3, Ls63;

    .line 529
    .line 530
    const/16 v2, 0x13

    .line 531
    .line 532
    invoke-direct {v3, v5, v11, v0, v2}, Ls63;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 533
    .line 534
    .line 535
    iput v9, v4, Lg0;->g:I

    .line 536
    .line 537
    const/4 v0, 0x0

    .line 538
    const/4 v2, 0x0

    .line 539
    const/16 v5, 0xc

    .line 540
    .line 541
    invoke-static/range {v0 .. v5}, Lsz6;->m(FFLum;Lzy4;Lgna;I)Ljava/lang/Object;

    .line 542
    .line 543
    .line 544
    move-result-object v0

    .line 545
    if-ne v0, v8, :cond_19

    .line 546
    .line 547
    goto :goto_f

    .line 548
    :cond_19
    :goto_e
    move-object v8, v10

    .line 549
    :goto_f
    return-object v8

    .line 550
    :pswitch_4
    iget-wide v0, v4, Lg0;->f:J

    .line 551
    .line 552
    check-cast v11, Lkj6;

    .line 553
    .line 554
    iget-object v2, v11, Lkj6;->p:Lbk;

    .line 555
    .line 556
    iget v13, v4, Lg0;->g:I

    .line 557
    .line 558
    if-eqz v13, :cond_1c

    .line 559
    .line 560
    if-eq v13, v9, :cond_1b

    .line 561
    .line 562
    if-ne v13, v3, :cond_1a

    .line 563
    .line 564
    :try_start_1
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1

    .line 565
    .line 566
    .line 567
    goto/16 :goto_12

    .line 568
    .line 569
    :cond_1a
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 570
    .line 571
    .line 572
    move-object v8, v12

    .line 573
    goto/16 :goto_13

    .line 574
    .line 575
    :cond_1b
    iget-object v5, v4, Lg0;->h:Ljava/lang/Object;

    .line 576
    .line 577
    check-cast v5, Lyi4;

    .line 578
    .line 579
    :try_start_2
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1

    .line 580
    .line 581
    .line 582
    goto :goto_11

    .line 583
    :cond_1c
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 584
    .line 585
    .line 586
    :try_start_3
    invoke-virtual {v2}, Lbk;->e()Z

    .line 587
    .line 588
    .line 589
    move-result v6
    :try_end_3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3 .. :try_end_3} :catch_1

    .line 590
    check-cast v5, Lyi4;

    .line 591
    .line 592
    if-eqz v6, :cond_1e

    .line 593
    .line 594
    :try_start_4
    instance-of v6, v5, Lwca;

    .line 595
    .line 596
    if-eqz v6, :cond_1d

    .line 597
    .line 598
    check-cast v5, Lwca;

    .line 599
    .line 600
    goto :goto_10

    .line 601
    :cond_1d
    sget-object v5, Llj6;->a:Lwca;

    .line 602
    .line 603
    :cond_1e
    :goto_10
    invoke-virtual {v2}, Lbk;->e()Z

    .line 604
    .line 605
    .line 606
    move-result v6

    .line 607
    if-nez v6, :cond_20

    .line 608
    .line 609
    new-instance v6, Lbv5;

    .line 610
    .line 611
    invoke-direct {v6, v0, v1}, Lbv5;-><init>(J)V

    .line 612
    .line 613
    .line 614
    iput-object v5, v4, Lg0;->h:Ljava/lang/Object;

    .line 615
    .line 616
    iput v9, v4, Lg0;->g:I

    .line 617
    .line 618
    invoke-virtual {v2, v4, v6}, Lbk;->f(Ldc3;Ljava/lang/Object;)Ljava/lang/Object;

    .line 619
    .line 620
    .line 621
    move-result-object v6

    .line 622
    if-ne v6, v8, :cond_1f

    .line 623
    .line 624
    goto :goto_13

    .line 625
    :cond_1f
    :goto_11
    iget-object v6, v11, Lkj6;->c:Lc75;

    .line 626
    .line 627
    invoke-virtual {v6}, Lc75;->w()Ljava/lang/Object;

    .line 628
    .line 629
    .line 630
    :cond_20
    invoke-virtual {v2}, Lbk;->d()Ljava/lang/Object;

    .line 631
    .line 632
    .line 633
    move-result-object v2

    .line 634
    check-cast v2, Lbv5;

    .line 635
    .line 636
    iget-wide v13, v2, Lbv5;->a:J

    .line 637
    .line 638
    invoke-static {v13, v14, v0, v1}, Lbv5;->c(JJ)J

    .line 639
    .line 640
    .line 641
    move-result-wide v0

    .line 642
    iget-object v2, v11, Lkj6;->p:Lbk;

    .line 643
    .line 644
    new-instance v6, Lbv5;

    .line 645
    .line 646
    invoke-direct {v6, v0, v1}, Lbv5;-><init>(J)V

    .line 647
    .line 648
    .line 649
    new-instance v9, Lq60;

    .line 650
    .line 651
    invoke-direct {v9, v3, v0, v1, v11}, Lq60;-><init>(IJLjava/lang/Object;)V

    .line 652
    .line 653
    .line 654
    iput-object v12, v4, Lg0;->h:Ljava/lang/Object;

    .line 655
    .line 656
    iput v3, v4, Lg0;->g:I

    .line 657
    .line 658
    const/4 v3, 0x0

    .line 659
    move-object v1, v6

    .line 660
    const/4 v6, 0x4

    .line 661
    move-object v0, v2

    .line 662
    move-object v2, v5

    .line 663
    move-object v5, v4

    .line 664
    move-object v4, v9

    .line 665
    invoke-static/range {v0 .. v6}, Lbk;->b(Lbk;Ljava/lang/Object;Lum;Ljava/lang/Float;Lly4;Ldc3;I)Ljava/lang/Object;

    .line 666
    .line 667
    .line 668
    move-result-object v0

    .line 669
    if-ne v0, v8, :cond_21

    .line 670
    .line 671
    goto :goto_13

    .line 672
    :cond_21
    :goto_12
    invoke-virtual {v11, v7}, Lkj6;->f(Z)V

    .line 673
    .line 674
    .line 675
    iput-boolean v7, v11, Lkj6;->g:Z
    :try_end_4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4 .. :try_end_4} :catch_1

    .line 676
    .line 677
    :catch_1
    move-object v8, v10

    .line 678
    :goto_13
    return-object v8

    .line 679
    :pswitch_5
    check-cast v11, Ljl4;

    .line 680
    .line 681
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 682
    .line 683
    move-object v14, v0

    .line 684
    check-cast v14, Leh5;

    .line 685
    .line 686
    iget v0, v4, Lg0;->g:I

    .line 687
    .line 688
    const/4 v13, 0x5

    .line 689
    const/16 v17, 0x0

    .line 690
    .line 691
    if-eqz v0, :cond_27

    .line 692
    .line 693
    if-eq v0, v9, :cond_26

    .line 694
    .line 695
    if-eq v0, v3, :cond_25

    .line 696
    .line 697
    if-eq v0, v1, :cond_24

    .line 698
    .line 699
    if-eq v0, v2, :cond_23

    .line 700
    .line 701
    if-ne v0, v13, :cond_22

    .line 702
    .line 703
    goto :goto_14

    .line 704
    :cond_22
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 705
    .line 706
    .line 707
    move-object v8, v12

    .line 708
    goto/16 :goto_21

    .line 709
    .line 710
    :cond_23
    iget-wide v0, v4, Lg0;->f:J

    .line 711
    .line 712
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 713
    .line 714
    .line 715
    move-object/from16 v2, p1

    .line 716
    .line 717
    move v12, v13

    .line 718
    move-object/from16 v13, v17

    .line 719
    .line 720
    goto/16 :goto_1b

    .line 721
    .line 722
    :cond_24
    iget-wide v0, v4, Lg0;->f:J

    .line 723
    .line 724
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 725
    .line 726
    .line 727
    move v12, v13

    .line 728
    move-object/from16 v13, v17

    .line 729
    .line 730
    goto/16 :goto_1a

    .line 731
    .line 732
    :cond_25
    :goto_14
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 733
    .line 734
    .line 735
    goto/16 :goto_20

    .line 736
    .line 737
    :cond_26
    iget-wide v0, v4, Lg0;->f:J

    .line 738
    .line 739
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 740
    .line 741
    .line 742
    move-wide v15, v0

    .line 743
    :goto_15
    move v0, v13

    .line 744
    goto :goto_19

    .line 745
    :cond_27
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 746
    .line 747
    .line 748
    invoke-static {v14}, Lo5c;->A(Lag5;)Lcb3;

    .line 749
    .line 750
    .line 751
    move-result-object v0

    .line 752
    invoke-static {v14}, Lucc;->O(Leh5;)Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object v6

    .line 756
    invoke-static {v14}, Lucc;->G(Leh5;)Ljava/lang/String;

    .line 757
    .line 758
    .line 759
    invoke-static {v14}, Lucc;->I(Leh5;)Ljava/lang/String;

    .line 760
    .line 761
    .line 762
    invoke-interface {v14}, Lag5;->a()Lx95;

    .line 763
    .line 764
    .line 765
    move-result-object v12

    .line 766
    const-string/jumbo v15, "x-ds-sse-heartbeat-timeout-secs"

    .line 767
    .line 768
    .line 769
    invoke-interface {v12, v15}, Lmja;->s(Ljava/lang/String;)Ljava/lang/String;

    .line 770
    .line 771
    .line 772
    move-result-object v12

    .line 773
    if-eqz v12, :cond_28

    .line 774
    .line 775
    const/16 v15, 0xa

    .line 776
    .line 777
    invoke-static {v15, v12}, Lwja;->H(ILjava/lang/String;)Ljava/lang/Long;

    .line 778
    .line 779
    .line 780
    move-result-object v12

    .line 781
    if-eqz v12, :cond_28

    .line 782
    .line 783
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 784
    .line 785
    .line 786
    move-result-wide v15

    .line 787
    :goto_16
    move-wide v1, v15

    .line 788
    goto :goto_17

    .line 789
    :cond_28
    const-wide/16 v15, 0xa

    .line 790
    .line 791
    goto :goto_16

    .line 792
    :goto_17
    if-eqz v0, :cond_29

    .line 793
    .line 794
    invoke-virtual {v0}, Lcb3;->D()Lcb3;

    .line 795
    .line 796
    .line 797
    move-result-object v0

    .line 798
    goto :goto_18

    .line 799
    :cond_29
    move-object/from16 v0, v17

    .line 800
    .line 801
    :goto_18
    sget-object v12, Lbb3;->b:Lcb3;

    .line 802
    .line 803
    invoke-static {v0, v12}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 804
    .line 805
    .line 806
    move-result v12

    .line 807
    if-eqz v12, :cond_2b

    .line 808
    .line 809
    new-instance v0, Lcv1;

    .line 810
    .line 811
    invoke-direct {v0, v1, v2, v6, v9}, Lcv1;-><init>(JLjava/lang/String;Z)V

    .line 812
    .line 813
    .line 814
    iput-object v14, v4, Lg0;->h:Ljava/lang/Object;

    .line 815
    .line 816
    iput-wide v1, v4, Lg0;->f:J

    .line 817
    .line 818
    iput v9, v4, Lg0;->g:I

    .line 819
    .line 820
    invoke-interface {v11, v0, v4}, Ljl4;->a(Ljava/lang/Object;Ldc3;)Ljava/lang/Object;

    .line 821
    .line 822
    .line 823
    move-result-object v0

    .line 824
    if-ne v0, v8, :cond_2a

    .line 825
    .line 826
    goto/16 :goto_21

    .line 827
    .line 828
    :cond_2a
    move-wide v15, v1

    .line 829
    goto :goto_15

    .line 830
    :goto_19
    new-instance v13, Lvs1;

    .line 831
    .line 832
    const/16 v18, 0x0

    .line 833
    .line 834
    move v12, v0

    .line 835
    invoke-direct/range {v13 .. v18}, Lvs1;-><init>(Leh5;JLdc3;I)V

    .line 836
    .line 837
    .line 838
    move-object v2, v13

    .line 839
    move-wide v0, v15

    .line 840
    move-object/from16 v13, v17

    .line 841
    .line 842
    new-instance v5, Lb70;

    .line 843
    .line 844
    invoke-direct {v5, v12, v2}, Lb70;-><init>(ILjava/lang/Object;)V

    .line 845
    .line 846
    .line 847
    new-instance v2, Lt5;

    .line 848
    .line 849
    const/4 v6, 0x7

    .line 850
    invoke-direct {v2, v11, v6}, Lt5;-><init>(Ljl4;I)V

    .line 851
    .line 852
    .line 853
    iput-object v13, v4, Lg0;->h:Ljava/lang/Object;

    .line 854
    .line 855
    iput-wide v0, v4, Lg0;->f:J

    .line 856
    .line 857
    iput v3, v4, Lg0;->g:I

    .line 858
    .line 859
    invoke-virtual {v5, v2, v4}, Lb70;->b(Ljl4;Ldc3;)Ljava/lang/Object;

    .line 860
    .line 861
    .line 862
    move-result-object v0

    .line 863
    if-ne v0, v8, :cond_32

    .line 864
    .line 865
    goto/16 :goto_21

    .line 866
    .line 867
    :cond_2b
    move v12, v13

    .line 868
    move-object/from16 v13, v17

    .line 869
    .line 870
    sget-object v3, Lya3;->a:Lcb3;

    .line 871
    .line 872
    invoke-static {v0, v3}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 873
    .line 874
    .line 875
    move-result v0

    .line 876
    if-eqz v0, :cond_32

    .line 877
    .line 878
    new-instance v0, Lcv1;

    .line 879
    .line 880
    invoke-direct {v0, v1, v2, v6, v7}, Lcv1;-><init>(JLjava/lang/String;Z)V

    .line 881
    .line 882
    .line 883
    iput-object v14, v4, Lg0;->h:Ljava/lang/Object;

    .line 884
    .line 885
    iput-wide v1, v4, Lg0;->f:J

    .line 886
    .line 887
    const/4 v3, 0x3

    .line 888
    iput v3, v4, Lg0;->g:I

    .line 889
    .line 890
    invoke-interface {v11, v0, v4}, Ljl4;->a(Ljava/lang/Object;Ldc3;)Ljava/lang/Object;

    .line 891
    .line 892
    .line 893
    move-result-object v0

    .line 894
    if-ne v0, v8, :cond_2c

    .line 895
    .line 896
    goto/16 :goto_21

    .line 897
    .line 898
    :cond_2c
    move-wide v0, v1

    .line 899
    :goto_1a
    iput-object v14, v4, Lg0;->h:Ljava/lang/Object;

    .line 900
    .line 901
    iput-wide v0, v4, Lg0;->f:J

    .line 902
    .line 903
    const/4 v2, 0x4

    .line 904
    iput v2, v4, Lg0;->g:I

    .line 905
    .line 906
    sget-object v2, Lss1;->a:Ljava/nio/charset/Charset;

    .line 907
    .line 908
    invoke-static {v14, v2, v4}, Ldec;->r(Leh5;Ljava/nio/charset/Charset;Lec3;)Ljava/lang/Object;

    .line 909
    .line 910
    .line 911
    move-result-object v2

    .line 912
    if-ne v2, v8, :cond_2d

    .line 913
    .line 914
    goto/16 :goto_21

    .line 915
    .line 916
    :cond_2d
    :goto_1b
    check-cast v2, Ljava/lang/String;

    .line 917
    .line 918
    sget-object v3, Ls36;->a:Li36;

    .line 919
    .line 920
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 921
    .line 922
    .line 923
    sget-object v6, Lqs9;->Companion:Lps9;

    .line 924
    .line 925
    sget-object v15, Lf46;->Companion:Le46;

    .line 926
    .line 927
    invoke-virtual {v15}, Le46;->serializer()Lbb6;

    .line 928
    .line 929
    .line 930
    move-result-object v15

    .line 931
    invoke-virtual {v6, v15}, Lps9;->serializer(Lbb6;)Lbb6;

    .line 932
    .line 933
    .line 934
    move-result-object v15

    .line 935
    check-cast v15, Lbb6;

    .line 936
    .line 937
    invoke-virtual {v3, v15, v2}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 938
    .line 939
    .line 940
    move-result-object v15

    .line 941
    check-cast v15, Lqs9;

    .line 942
    .line 943
    iget v7, v15, Lqs9;->a:I

    .line 944
    .line 945
    const v9, 0x9d6f

    .line 946
    .line 947
    .line 948
    if-eq v7, v9, :cond_2f

    .line 949
    .line 950
    const v9, 0x9d70

    .line 951
    .line 952
    .line 953
    if-ne v7, v9, :cond_2e

    .line 954
    .line 955
    goto :goto_1c

    .line 956
    :cond_2e
    const/4 v7, 0x0

    .line 957
    goto :goto_1d

    .line 958
    :cond_2f
    :goto_1c
    const/4 v7, 0x1

    .line 959
    :goto_1d
    if-eqz v7, :cond_30

    .line 960
    .line 961
    move-object/from16 v27, v13

    .line 962
    .line 963
    goto :goto_1e

    .line 964
    :cond_30
    sget-object v9, Lmt9;->Companion:Llt9;

    .line 965
    .line 966
    sget-object v16, Lpu1;->Companion:Lou1;

    .line 967
    .line 968
    invoke-virtual/range {v16 .. v16}, Lou1;->serializer()Lbb6;

    .line 969
    .line 970
    .line 971
    move-result-object v12

    .line 972
    invoke-virtual {v9, v12}, Llt9;->serializer(Lbb6;)Lbb6;

    .line 973
    .line 974
    .line 975
    move-result-object v9

    .line 976
    invoke-virtual {v6, v9}, Lps9;->serializer(Lbb6;)Lbb6;

    .line 977
    .line 978
    .line 979
    move-result-object v6

    .line 980
    check-cast v6, Lbb6;

    .line 981
    .line 982
    invoke-virtual {v3, v6, v2}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 983
    .line 984
    .line 985
    move-result-object v3

    .line 986
    move-object/from16 v17, v3

    .line 987
    .line 988
    check-cast v17, Lqs9;

    .line 989
    .line 990
    move-object/from16 v27, v17

    .line 991
    .line 992
    :goto_1e
    move-object/from16 v20, v5

    .line 993
    .line 994
    check-cast v20, Ljava/lang/String;

    .line 995
    .line 996
    invoke-virtual {v14}, Leh5;->P()Lif5;

    .line 997
    .line 998
    .line 999
    move-result-object v3

    .line 1000
    invoke-virtual {v3}, Lif5;->c()Lrg5;

    .line 1001
    .line 1002
    .line 1003
    move-result-object v3

    .line 1004
    invoke-static {v3}, Lug5;->a(Lrg5;)Ljava/lang/String;

    .line 1005
    .line 1006
    .line 1007
    move-result-object v21

    .line 1008
    invoke-static {v14}, Lucc;->O(Leh5;)Ljava/lang/String;

    .line 1009
    .line 1010
    .line 1011
    move-result-object v22

    .line 1012
    invoke-static {v14}, Lucc;->G(Leh5;)Ljava/lang/String;

    .line 1013
    .line 1014
    .line 1015
    move-result-object v23

    .line 1016
    invoke-static {v14}, Lucc;->I(Leh5;)Ljava/lang/String;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v24

    .line 1020
    invoke-static {v14}, Lucc;->M(Leh5;)Ljava/lang/String;

    .line 1021
    .line 1022
    .line 1023
    move-result-object v25

    .line 1024
    invoke-static {v14}, Lucc;->N(Leh5;)Ljava/lang/Long;

    .line 1025
    .line 1026
    .line 1027
    move-result-object v26

    .line 1028
    if-eqz v7, :cond_31

    .line 1029
    .line 1030
    move-object/from16 v28, v15

    .line 1031
    .line 1032
    goto :goto_1f

    .line 1033
    :cond_31
    move-object/from16 v28, v13

    .line 1034
    .line 1035
    :goto_1f
    const/16 v3, 0x200

    .line 1036
    .line 1037
    invoke-static {v3, v2}, Lpja;->t0(ILjava/lang/String;)Ljava/lang/String;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v29

    .line 1041
    invoke-interface {v14}, Lag5;->a()Lx95;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v30

    .line 1045
    new-instance v19, Lgt9;

    .line 1046
    .line 1047
    invoke-direct/range {v19 .. v30}, Lgt9;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Lqs9;Lqs9;Ljava/lang/String;Lx95;)V

    .line 1048
    .line 1049
    .line 1050
    move-object/from16 v2, v19

    .line 1051
    .line 1052
    new-instance v3, Ldv1;

    .line 1053
    .line 1054
    invoke-direct {v3, v2}, Ldv1;-><init>(Lgt9;)V

    .line 1055
    .line 1056
    .line 1057
    iput-object v13, v4, Lg0;->h:Ljava/lang/Object;

    .line 1058
    .line 1059
    iput-wide v0, v4, Lg0;->f:J

    .line 1060
    .line 1061
    const/4 v0, 0x5

    .line 1062
    iput v0, v4, Lg0;->g:I

    .line 1063
    .line 1064
    invoke-interface {v11, v3, v4}, Ljl4;->a(Ljava/lang/Object;Ldc3;)Ljava/lang/Object;

    .line 1065
    .line 1066
    .line 1067
    move-result-object v0

    .line 1068
    if-ne v0, v8, :cond_32

    .line 1069
    .line 1070
    goto :goto_21

    .line 1071
    :cond_32
    :goto_20
    move-object v8, v10

    .line 1072
    :goto_21
    return-object v8

    .line 1073
    :pswitch_6
    check-cast v5, Lkn7;

    .line 1074
    .line 1075
    iget v0, v4, Lg0;->g:I

    .line 1076
    .line 1077
    if-eqz v0, :cond_36

    .line 1078
    .line 1079
    const/4 v1, 0x1

    .line 1080
    if-eq v0, v1, :cond_35

    .line 1081
    .line 1082
    if-eq v0, v3, :cond_34

    .line 1083
    .line 1084
    const/4 v3, 0x3

    .line 1085
    if-ne v0, v3, :cond_33

    .line 1086
    .line 1087
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 1088
    .line 1089
    .line 1090
    goto :goto_24

    .line 1091
    :cond_33
    invoke-static {v6}, Lrs0;->g(Ljava/lang/String;)V

    .line 1092
    .line 1093
    .line 1094
    move-object v8, v12

    .line 1095
    goto :goto_25

    .line 1096
    :cond_34
    iget-object v0, v4, Lg0;->h:Ljava/lang/Object;

    .line 1097
    .line 1098
    check-cast v0, Lvn8;

    .line 1099
    .line 1100
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 1101
    .line 1102
    .line 1103
    goto :goto_23

    .line 1104
    :cond_35
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 1105
    .line 1106
    .line 1107
    goto :goto_22

    .line 1108
    :cond_36
    invoke-static/range {p1 .. p1}, Lu07;->z(Ljava/lang/Object;)V

    .line 1109
    .line 1110
    .line 1111
    check-cast v11, Li06;

    .line 1112
    .line 1113
    const/4 v1, 0x1

    .line 1114
    iput v1, v4, Lg0;->g:I

    .line 1115
    .line 1116
    invoke-interface {v11, v4}, Li06;->i0(Ldc3;)Ljava/lang/Object;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v0

    .line 1120
    if-ne v0, v8, :cond_37

    .line 1121
    .line 1122
    goto :goto_25

    .line 1123
    :cond_37
    :goto_22
    new-instance v0, Lun8;

    .line 1124
    .line 1125
    iget-wide v1, v4, Lg0;->f:J

    .line 1126
    .line 1127
    invoke-direct {v0, v1, v2}, Lun8;-><init>(J)V

    .line 1128
    .line 1129
    .line 1130
    new-instance v1, Lvn8;

    .line 1131
    .line 1132
    invoke-direct {v1, v0}, Lvn8;-><init>(Lun8;)V

    .line 1133
    .line 1134
    .line 1135
    iput-object v1, v4, Lg0;->h:Ljava/lang/Object;

    .line 1136
    .line 1137
    iput v3, v4, Lg0;->g:I

    .line 1138
    .line 1139
    invoke-interface {v5, v0, v4}, Lkn7;->b(Ltv5;Ldc3;)Ljava/lang/Object;

    .line 1140
    .line 1141
    .line 1142
    move-result-object v0

    .line 1143
    if-ne v0, v8, :cond_38

    .line 1144
    .line 1145
    goto :goto_25

    .line 1146
    :cond_38
    move-object v0, v1

    .line 1147
    :goto_23
    iput-object v12, v4, Lg0;->h:Ljava/lang/Object;

    .line 1148
    .line 1149
    const/4 v3, 0x3

    .line 1150
    iput v3, v4, Lg0;->g:I

    .line 1151
    .line 1152
    invoke-interface {v5, v0, v4}, Lkn7;->b(Ltv5;Ldc3;)Ljava/lang/Object;

    .line 1153
    .line 1154
    .line 1155
    move-result-object v0

    .line 1156
    if-ne v0, v8, :cond_39

    .line 1157
    .line 1158
    goto :goto_25

    .line 1159
    :cond_39
    :goto_24
    move-object v8, v10

    .line 1160
    :goto_25
    return-object v8

    .line 1161
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
