.class public final Lr3;
.super Ljava/lang/Object;
.source "r8-map-id-2e17ac06b3663e3b6803a43c074ce5b2710eae1d5a807a22099ba6599b707f30"

# interfaces
.implements Ljl4;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lr3;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lr3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ldc3;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    iget v2, v0, Lr3;->a:I

    .line 6
    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v2, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    move-object/from16 v1, p1

    .line 12
    .line 13
    check-cast v1, Ljava/lang/String;

    .line 14
    .line 15
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Ldva;

    .line 18
    .line 19
    iget-object v0, v0, Ldva;->J:Lv98;

    .line 20
    .line 21
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lv98;->setValue(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    sget-object v0, Lghb;->a:Lghb;

    .line 27
    .line 28
    return-object v0

    .line 29
    :pswitch_0
    move-object/from16 v2, p1

    .line 30
    .line 31
    check-cast v2, Lsa0;

    .line 32
    .line 33
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, Lgqa;

    .line 36
    .line 37
    iget-object v0, v0, Lgqa;->i:Llt0;

    .line 38
    .line 39
    new-instance v3, Lmpa;

    .line 40
    .line 41
    invoke-direct {v3, v2}, Lmpa;-><init>(Lsa0;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {v0, v1, v3}, Lhr9;->m(Ldc3;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    sget-object v1, Lhd3;->a:Lhd3;

    .line 49
    .line 50
    if-ne v0, v1, :cond_0

    .line 51
    .line 52
    goto :goto_0

    .line 53
    :cond_0
    sget-object v0, Lghb;->a:Lghb;

    .line 54
    .line 55
    :goto_0
    return-object v0

    .line 56
    :pswitch_1
    move-object/from16 v1, p1

    .line 57
    .line 58
    check-cast v1, Ljf8;

    .line 59
    .line 60
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v0, Lxy8;

    .line 63
    .line 64
    iget-object v0, v0, Lxy8;->i:Lv98;

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Lv98;->setValue(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    sget-object v0, Lghb;->a:Lghb;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_2
    move-object/from16 v1, p1

    .line 73
    .line 74
    check-cast v1, Lpo5;

    .line 75
    .line 76
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Lmk5;

    .line 79
    .line 80
    new-instance v2, Ljava/util/ArrayList;

    .line 81
    .line 82
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 83
    .line 84
    .line 85
    move-result v5

    .line 86
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 87
    .line 88
    .line 89
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 90
    .line 91
    .line 92
    move-result v5

    .line 93
    const/4 v3, 0x0

    .line 94
    :goto_1
    if-ge v3, v5, :cond_3

    .line 95
    .line 96
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    check-cast v6, Lktb;

    .line 101
    .line 102
    iget-boolean v7, v6, Lktb;->c:Z

    .line 103
    .line 104
    if-eqz v7, :cond_1

    .line 105
    .line 106
    iget-object v6, v6, Lktb;->a:Lqm5;

    .line 107
    .line 108
    goto :goto_2

    .line 109
    :cond_1
    move-object v6, v4

    .line 110
    :goto_2
    if-eqz v6, :cond_2

    .line 111
    .line 112
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    :cond_2
    add-int/lit8 v3, v3, 0x1

    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_3
    iget-object v0, v0, Lmk5;->c:Llt0;

    .line 119
    .line 120
    invoke-interface {v0, v2}, Lhr9;->q(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    sget-object v0, Lghb;->a:Lghb;

    .line 124
    .line 125
    return-object v0

    .line 126
    :pswitch_3
    move-object/from16 v1, p1

    .line 127
    .line 128
    check-cast v1, Lvf3;

    .line 129
    .line 130
    if-eqz v1, :cond_4

    .line 131
    .line 132
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Lly4;

    .line 135
    .line 136
    invoke-interface {v0, v1}, Lly4;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    :cond_4
    sget-object v0, Lghb;->a:Lghb;

    .line 140
    .line 141
    return-object v0

    .line 142
    :pswitch_4
    move-object/from16 v1, p1

    .line 143
    .line 144
    check-cast v1, Ljava/lang/Number;

    .line 145
    .line 146
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 147
    .line 148
    .line 149
    move-result v1

    .line 150
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v0, Lhl7;

    .line 153
    .line 154
    iget-object v0, v0, Lhl7;->c:Lr98;

    .line 155
    .line 156
    invoke-virtual {v0, v1}, Lr98;->g(F)V

    .line 157
    .line 158
    .line 159
    sget-object v0, Lghb;->a:Lghb;

    .line 160
    .line 161
    return-object v0

    .line 162
    :pswitch_5
    move-object/from16 v1, p1

    .line 163
    .line 164
    check-cast v1, Ljava/util/Set;

    .line 165
    .line 166
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v0, Lhb7;

    .line 169
    .line 170
    iget-object v0, v0, Lhb7;->a:Leba;

    .line 171
    .line 172
    check-cast v1, Ljava/util/Collection;

    .line 173
    .line 174
    invoke-virtual {v0, v1}, Leba;->removeAll(Ljava/util/Collection;)Z

    .line 175
    .line 176
    .line 177
    sget-object v0, Lghb;->a:Lghb;

    .line 178
    .line 179
    return-object v0

    .line 180
    :pswitch_6
    move-object/from16 v1, p1

    .line 181
    .line 182
    check-cast v1, Ltv5;

    .line 183
    .line 184
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v0, Lv98;

    .line 187
    .line 188
    instance-of v2, v1, Lg24;

    .line 189
    .line 190
    if-eqz v2, :cond_5

    .line 191
    .line 192
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 193
    .line 194
    invoke-virtual {v0, v1}, Lv98;->setValue(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    goto :goto_3

    .line 198
    :cond_5
    instance-of v2, v1, Lh24;

    .line 199
    .line 200
    if-nez v2, :cond_6

    .line 201
    .line 202
    instance-of v1, v1, Lf24;

    .line 203
    .line 204
    if-eqz v1, :cond_7

    .line 205
    .line 206
    :cond_6
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 207
    .line 208
    invoke-virtual {v0, v1}, Lv98;->setValue(Ljava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    :cond_7
    :goto_3
    sget-object v0, Lghb;->a:Lghb;

    .line 212
    .line 213
    return-object v0

    .line 214
    :pswitch_7
    move-object/from16 v1, p1

    .line 215
    .line 216
    check-cast v1, Lck9;

    .line 217
    .line 218
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v0, Lfl6;

    .line 221
    .line 222
    iget-object v0, v0, Lfl6;->z:Lv98;

    .line 223
    .line 224
    invoke-virtual {v0, v1}, Lv98;->setValue(Ljava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    sget-object v0, Lghb;->a:Lghb;

    .line 228
    .line 229
    return-object v0

    .line 230
    :pswitch_8
    move-object/from16 v1, p1

    .line 231
    .line 232
    check-cast v1, Lus5;

    .line 233
    .line 234
    iget v2, v1, Lus5;->a:I

    .line 235
    .line 236
    iget-boolean v1, v1, Lus5;->b:Z

    .line 237
    .line 238
    if-nez v1, :cond_9

    .line 239
    .line 240
    invoke-static {v2}, Lucc;->P(I)Z

    .line 241
    .line 242
    .line 243
    move-result v1

    .line 244
    if-eqz v1, :cond_9

    .line 245
    .line 246
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast v0, Lzs5;

    .line 249
    .line 250
    const/4 v1, 0x1

    .line 251
    invoke-virtual {v0, v1}, Lzs5;->d(I)V

    .line 252
    .line 253
    .line 254
    const-string v0, ""

    .line 255
    .line 256
    const-string/jumbo v1, "voice_unavailable"

    .line 257
    .line 258
    .line 259
    const-string v2, "input_switch_to_text"

    .line 260
    .line 261
    new-instance v3, Lorg/json/JSONObject;

    .line 262
    .line 263
    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 264
    .line 265
    .line 266
    const-string v4, "chat_session_id"

    .line 267
    .line 268
    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 269
    .line 270
    .line 271
    const-string/jumbo v0, "text_switch_reason"

    .line 272
    .line 273
    .line 274
    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 275
    .line 276
    .line 277
    sget-object v1, Lbc1;->a:Ljava/lang/Object;

    .line 278
    .line 279
    monitor-enter v1

    .line 280
    :try_start_0
    sget-object v0, Lbc1;->b:Lmb;

    .line 281
    .line 282
    if-eqz v0, :cond_8

    .line 283
    .line 284
    invoke-virtual {v0, v2, v3}, Lmb;->a(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 285
    .line 286
    .line 287
    goto :goto_4

    .line 288
    :catchall_0
    move-exception v0

    .line 289
    goto :goto_5

    .line 290
    :cond_8
    invoke-static {v2, v3}, Lyu7;->O(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 291
    .line 292
    .line 293
    :goto_4
    monitor-exit v1

    .line 294
    goto :goto_6

    .line 295
    :goto_5
    monitor-exit v1

    .line 296
    throw v0

    .line 297
    :cond_9
    :goto_6
    sget-object v0, Lghb;->a:Lghb;

    .line 298
    .line 299
    return-object v0

    .line 300
    :pswitch_9
    move-object/from16 v1, p1

    .line 301
    .line 302
    check-cast v1, Ljava/lang/Boolean;

    .line 303
    .line 304
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 305
    .line 306
    .line 307
    move-result v1

    .line 308
    if-nez v1, :cond_a

    .line 309
    .line 310
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 311
    .line 312
    check-cast v0, Lps5;

    .line 313
    .line 314
    invoke-virtual {v0}, Lps5;->a()V

    .line 315
    .line 316
    .line 317
    :cond_a
    sget-object v0, Lghb;->a:Lghb;

    .line 318
    .line 319
    return-object v0

    .line 320
    :pswitch_a
    move-object/from16 v2, p1

    .line 321
    .line 322
    check-cast v2, Lfq5;

    .line 323
    .line 324
    invoke-virtual {v0, v2, v1}, Lr3;->d(Lfq5;Ldc3;)Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    return-object v0

    .line 329
    :pswitch_b
    move-object/from16 v1, p1

    .line 330
    .line 331
    check-cast v1, Ljava/lang/Boolean;

    .line 332
    .line 333
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 334
    .line 335
    .line 336
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 337
    .line 338
    check-cast v0, Lgp4;

    .line 339
    .line 340
    iget-object v1, v0, Lgp4;->a:Lv98;

    .line 341
    .line 342
    invoke-virtual {v1}, Lv98;->getValue()Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v1

    .line 346
    check-cast v1, Ljava/lang/Boolean;

    .line 347
    .line 348
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 349
    .line 350
    .line 351
    move-result v1

    .line 352
    if-eqz v1, :cond_b

    .line 353
    .line 354
    iget-object v0, v0, Lgp4;->c:Ldq4;

    .line 355
    .line 356
    invoke-static {v0}, Ldq4;->b(Ldq4;)Z

    .line 357
    .line 358
    .line 359
    :cond_b
    sget-object v0, Lghb;->a:Lghb;

    .line 360
    .line 361
    return-object v0

    .line 362
    :pswitch_c
    move-object/from16 v1, p1

    .line 363
    .line 364
    check-cast v1, Ljava/lang/String;

    .line 365
    .line 366
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 367
    .line 368
    check-cast v0, Lvo3;

    .line 369
    .line 370
    iget-object v1, v0, Lvo3;->b:Ljava/lang/Object;

    .line 371
    .line 372
    monitor-enter v1

    .line 373
    :try_start_1
    iget-boolean v2, v0, Lvo3;->f:Z

    .line 374
    .line 375
    if-nez v2, :cond_e

    .line 376
    .line 377
    iget-object v2, v0, Lvo3;->c:Ljava/util/ArrayList;

    .line 378
    .line 379
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 380
    .line 381
    .line 382
    move-result v2

    .line 383
    if-nez v2, :cond_e

    .line 384
    .line 385
    iget-object v2, v0, Lvo3;->c:Ljava/util/ArrayList;

    .line 386
    .line 387
    invoke-static {v2}, Lj03;->o0(Ljava/util/List;)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v2

    .line 391
    check-cast v2, Lbb;

    .line 392
    .line 393
    iget-object v2, v2, Lbb;->c:Ljava/lang/String;

    .line 394
    .line 395
    iget-object v3, v0, Lvo3;->a:Lhb;

    .line 396
    .line 397
    iget-object v3, v3, Lhb;->a:Lx5;

    .line 398
    .line 399
    iget-object v3, v3, Lx5;->b:Lzx8;

    .line 400
    .line 401
    iget-object v3, v3, Lzx8;->a:Ljea;

    .line 402
    .line 403
    invoke-interface {v3}, Ljea;->getValue()Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v3

    .line 407
    check-cast v3, Lcz;

    .line 408
    .line 409
    if-eqz v3, :cond_c

    .line 410
    .line 411
    iget-object v4, v3, Lcz;->b:Ljava/lang/String;

    .line 412
    .line 413
    :cond_c
    if-nez v4, :cond_d

    .line 414
    .line 415
    const-string v4, ""

    .line 416
    .line 417
    :cond_d
    invoke-static {v2, v4}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    if-nez v2, :cond_e

    .line 422
    .line 423
    invoke-virtual {v0}, Lvo3;->a()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 424
    .line 425
    .line 426
    goto :goto_7

    .line 427
    :catchall_1
    move-exception v0

    .line 428
    goto :goto_8

    .line 429
    :cond_e
    :goto_7
    monitor-exit v1

    .line 430
    sget-object v0, Lghb;->a:Lghb;

    .line 431
    .line 432
    return-object v0

    .line 433
    :goto_8
    monitor-exit v1

    .line 434
    throw v0

    .line 435
    :pswitch_d
    move-object/from16 v1, p1

    .line 436
    .line 437
    check-cast v1, Landroid/view/inputmethod/CursorAnchorInfo;

    .line 438
    .line 439
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 440
    .line 441
    check-cast v0, Lvh3;

    .line 442
    .line 443
    iget-object v0, v0, Lvh3;->c:Lrtc;

    .line 444
    .line 445
    invoke-virtual {v0}, Lrtc;->C()Landroid/view/inputmethod/InputMethodManager;

    .line 446
    .line 447
    .line 448
    move-result-object v2

    .line 449
    iget-object v0, v0, Lrtc;->b:Ljava/lang/Object;

    .line 450
    .line 451
    check-cast v0, Landroid/view/View;

    .line 452
    .line 453
    invoke-virtual {v2, v0, v1}, Landroid/view/inputmethod/InputMethodManager;->updateCursorAnchorInfo(Landroid/view/View;Landroid/view/inputmethod/CursorAnchorInfo;)V

    .line 454
    .line 455
    .line 456
    sget-object v0, Lghb;->a:Lghb;

    .line 457
    .line 458
    return-object v0

    .line 459
    :pswitch_e
    move-object/from16 v1, p1

    .line 460
    .line 461
    check-cast v1, Lg92;

    .line 462
    .line 463
    instance-of v2, v1, Lf92;

    .line 464
    .line 465
    if-eqz v2, :cond_14

    .line 466
    .line 467
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 468
    .line 469
    move-object v6, v0

    .line 470
    check-cast v6, Lqq2;

    .line 471
    .line 472
    check-cast v1, Lf92;

    .line 473
    .line 474
    iget-object v8, v1, Lf92;->b:Ljava/lang/String;

    .line 475
    .line 476
    iget-object v9, v1, Lf92;->c:Ljava/lang/String;

    .line 477
    .line 478
    const-class v0, Lu9a;

    .line 479
    .line 480
    const-class v1, Landroid/content/Context;

    .line 481
    .line 482
    iget-object v2, v6, Lqq2;->l:Lzx8;

    .line 483
    .line 484
    const-string v5, "send"

    .line 485
    .line 486
    iget-object v7, v6, Lqq2;->b:Lsb2;

    .line 487
    .line 488
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 489
    .line 490
    .line 491
    new-instance v10, Lab2;

    .line 492
    .line 493
    invoke-direct {v10, v5}, Lab2;-><init>(Ljava/lang/String;)V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v7, v10}, Lsb2;->i(Leb2;)V

    .line 497
    .line 498
    .line 499
    iget-object v5, v6, Lqq2;->n:Lh82;

    .line 500
    .line 501
    iget-object v7, v5, Lh82;->j:Llea;

    .line 502
    .line 503
    invoke-virtual {v7}, Llea;->getValue()Ljava/lang/Object;

    .line 504
    .line 505
    .line 506
    move-result-object v7

    .line 507
    move-object v13, v7

    .line 508
    check-cast v13, Lom2;

    .line 509
    .line 510
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 511
    .line 512
    .line 513
    move-result v7

    .line 514
    if-nez v7, :cond_f

    .line 515
    .line 516
    iget-object v7, v13, Lom2;->a:Lzaa;

    .line 517
    .line 518
    invoke-virtual {v7}, Lzaa;->m()Lq1;

    .line 519
    .line 520
    .line 521
    move-result-object v7

    .line 522
    invoke-virtual {v7}, Ln0;->isEmpty()Z

    .line 523
    .line 524
    .line 525
    move-result v7

    .line 526
    if-eqz v7, :cond_f

    .line 527
    .line 528
    invoke-virtual {v13}, Lom2;->b()Z

    .line 529
    .line 530
    .line 531
    move-result v7

    .line 532
    if-nez v7, :cond_f

    .line 533
    .line 534
    goto/16 :goto_b

    .line 535
    .line 536
    :cond_f
    invoke-virtual {v6}, Lqq2;->Q()Lzs;

    .line 537
    .line 538
    .line 539
    move-result-object v7

    .line 540
    sget-object v10, Lmm2;->b:Lmm2;

    .line 541
    .line 542
    new-instance v11, Luk2;

    .line 543
    .line 544
    invoke-direct {v11, v7}, Luk2;-><init>(Lzs;)V

    .line 545
    .line 546
    .line 547
    iget-object v12, v7, Lzs;->i:Llea;

    .line 548
    .line 549
    invoke-virtual {v12}, Llea;->getValue()Ljava/lang/Object;

    .line 550
    .line 551
    .line 552
    move-result-object v12

    .line 553
    check-cast v12, Lns;

    .line 554
    .line 555
    invoke-virtual {v7}, Lzs;->i()Lrs;

    .line 556
    .line 557
    .line 558
    move-result-object v14

    .line 559
    invoke-virtual {v7}, Lzs;->j()Lvs;

    .line 560
    .line 561
    .line 562
    move-result-object v15

    .line 563
    iget-object v7, v6, Lqq2;->d:Lskb;

    .line 564
    .line 565
    iget-object v3, v2, Lzx8;->a:Ljea;

    .line 566
    .line 567
    invoke-interface {v3}, Ljea;->getValue()Ljava/lang/Object;

    .line 568
    .line 569
    .line 570
    move-result-object v3

    .line 571
    move-object/from16 v17, v3

    .line 572
    .line 573
    check-cast v17, Lcj7;

    .line 574
    .line 575
    move-object/from16 v16, v7

    .line 576
    .line 577
    invoke-virtual/range {v10 .. v17}, Lmm2;->c(Lxk2;Lns;Lom2;Lrs;Lvs;Lskb;Lcj7;)Lhm2;

    .line 578
    .line 579
    .line 580
    move-result-object v3

    .line 581
    instance-of v7, v3, Lgm2;

    .line 582
    .line 583
    const/4 v12, 0x3

    .line 584
    if-eqz v7, :cond_12

    .line 585
    .line 586
    iget-object v2, v2, Lzx8;->a:Ljea;

    .line 587
    .line 588
    invoke-interface {v2}, Ljea;->getValue()Ljava/lang/Object;

    .line 589
    .line 590
    .line 591
    move-result-object v2

    .line 592
    check-cast v2, Lcj7;

    .line 593
    .line 594
    iget-object v2, v2, Lcj7;->a:Ljava/lang/String;

    .line 595
    .line 596
    invoke-static {v3, v13, v2}, Lmm2;->g(Lhm2;Lom2;Ljava/lang/String;)Z

    .line 597
    .line 598
    .line 599
    move-result v2

    .line 600
    if-eqz v2, :cond_10

    .line 601
    .line 602
    goto :goto_a

    .line 603
    :cond_10
    check-cast v3, Lgm2;

    .line 604
    .line 605
    invoke-virtual {v6}, Lqq2;->N()V

    .line 606
    .line 607
    .line 608
    iget-object v2, v3, Lgm2;->c:Lfm2;

    .line 609
    .line 610
    if-eqz v2, :cond_11

    .line 611
    .line 612
    invoke-static {}, Ls10;->u()Lzm6;

    .line 613
    .line 614
    .line 615
    move-result-object v3

    .line 616
    iget-object v3, v3, Lzm6;->b:Ljava/lang/Object;

    .line 617
    .line 618
    check-cast v3, Lslc;

    .line 619
    .line 620
    iget-object v3, v3, Lslc;->e:Ljava/lang/Object;

    .line 621
    .line 622
    check-cast v3, Lki9;

    .line 623
    .line 624
    sget-object v6, Lt39;->a:Lu39;

    .line 625
    .line 626
    invoke-virtual {v6, v1}, Lu39;->b(Ljava/lang/Class;)Ll86;

    .line 627
    .line 628
    .line 629
    move-result-object v1

    .line 630
    invoke-virtual {v3, v1, v4, v4}, Lki9;->c(Ll86;Lm98;Law8;)Ljava/lang/Object;

    .line 631
    .line 632
    .line 633
    move-result-object v1

    .line 634
    check-cast v1, Landroid/content/Context;

    .line 635
    .line 636
    invoke-static {}, Ls10;->u()Lzm6;

    .line 637
    .line 638
    .line 639
    move-result-object v1

    .line 640
    iget-object v1, v1, Lzm6;->b:Ljava/lang/Object;

    .line 641
    .line 642
    check-cast v1, Lslc;

    .line 643
    .line 644
    iget-object v1, v1, Lslc;->e:Ljava/lang/Object;

    .line 645
    .line 646
    check-cast v1, Lki9;

    .line 647
    .line 648
    sget-object v3, Lt39;->a:Lu39;

    .line 649
    .line 650
    invoke-virtual {v3, v0}, Lu39;->b(Ljava/lang/Class;)Ll86;

    .line 651
    .line 652
    .line 653
    move-result-object v0

    .line 654
    invoke-virtual {v1, v0, v4, v4}, Lki9;->c(Ll86;Lm98;Law8;)Ljava/lang/Object;

    .line 655
    .line 656
    .line 657
    move-result-object v0

    .line 658
    check-cast v0, Lu9a;

    .line 659
    .line 660
    invoke-virtual {v2, v0}, Lfm2;->a(Lu9a;)V

    .line 661
    .line 662
    .line 663
    goto :goto_9

    .line 664
    :cond_11
    new-instance v0, Lol2;

    .line 665
    .line 666
    const/16 v1, 0xb

    .line 667
    .line 668
    invoke-direct {v0, v1}, Lol2;-><init>(I)V

    .line 669
    .line 670
    .line 671
    invoke-static {v12, v0, v6, v4}, Ltq0;->M(ILly4;Ltc6;Ljava/lang/String;)V

    .line 672
    .line 673
    .line 674
    :goto_9
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 675
    .line 676
    .line 677
    move-result v0

    .line 678
    if-lez v0, :cond_14

    .line 679
    .line 680
    invoke-virtual {v5, v8}, Lh82;->v(Ljava/lang/String;)V

    .line 681
    .line 682
    .line 683
    goto :goto_b

    .line 684
    :cond_12
    :goto_a
    iget-object v0, v6, Lqq2;->p:Lxh1;

    .line 685
    .line 686
    if-eqz v0, :cond_13

    .line 687
    .line 688
    invoke-virtual {v0}, Lxh1;->x()Z

    .line 689
    .line 690
    .line 691
    move-result v0

    .line 692
    if-nez v0, :cond_13

    .line 693
    .line 694
    goto :goto_b

    .line 695
    :cond_13
    iget-object v0, v6, Lqq2;->f:Lbz2;

    .line 696
    .line 697
    new-instance v5, Ll5;

    .line 698
    .line 699
    const/4 v10, 0x0

    .line 700
    const/16 v11, 0x15

    .line 701
    .line 702
    move-object v7, v13

    .line 703
    invoke-direct/range {v5 .. v11}, Ll5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ldc3;I)V

    .line 704
    .line 705
    .line 706
    const/4 v1, 0x0

    .line 707
    invoke-static {v0, v4, v1, v5, v12}, Lyu7;->F(Lgd3;Lyc3;ILzy4;I)Lqda;

    .line 708
    .line 709
    .line 710
    :cond_14
    :goto_b
    sget-object v0, Lghb;->a:Lghb;

    .line 711
    .line 712
    return-object v0

    .line 713
    :pswitch_f
    move-object/from16 v1, p1

    .line 714
    .line 715
    check-cast v1, Ljl2;

    .line 716
    .line 717
    instance-of v2, v1, Lhl2;

    .line 718
    .line 719
    if-eqz v2, :cond_15

    .line 720
    .line 721
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 722
    .line 723
    check-cast v0, Landroid/app/Activity;

    .line 724
    .line 725
    if-eqz v0, :cond_15

    .line 726
    .line 727
    check-cast v1, Lhl2;

    .line 728
    .line 729
    iget-object v1, v1, Lhl2;->a:Ljava/lang/String;

    .line 730
    .line 731
    new-instance v2, Lp9c;

    .line 732
    .line 733
    invoke-direct {v2, v0}, Lp9c;-><init>(Landroid/content/Context;)V

    .line 734
    .line 735
    .line 736
    iget-object v3, v2, Lp9c;->b:Ljava/lang/Object;

    .line 737
    .line 738
    check-cast v3, Landroid/content/Intent;

    .line 739
    .line 740
    const-string v5, "android.intent.extra.TEXT"

    .line 741
    .line 742
    invoke-virtual {v3, v5, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;

    .line 743
    .line 744
    .line 745
    const-string/jumbo v1, "text/plain"

    .line 746
    .line 747
    .line 748
    invoke-virtual {v3, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 749
    .line 750
    .line 751
    const-string v1, "android.intent.extra.STREAM"

    .line 752
    .line 753
    iget-object v2, v2, Lp9c;->b:Ljava/lang/Object;

    .line 754
    .line 755
    check-cast v2, Landroid/content/Intent;

    .line 756
    .line 757
    const-string v3, "android.intent.action.SEND"

    .line 758
    .line 759
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 760
    .line 761
    .line 762
    invoke-virtual {v2, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    .line 763
    .line 764
    .line 765
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    .line 766
    .line 767
    .line 768
    invoke-virtual {v2}, Landroid/content/Intent;->getFlags()I

    .line 769
    .line 770
    .line 771
    move-result v1

    .line 772
    and-int/lit8 v1, v1, -0x2

    .line 773
    .line 774
    invoke-virtual {v2, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 775
    .line 776
    .line 777
    const v1, 0x7f0f0325

    .line 778
    .line 779
    .line 780
    invoke-static {v1, v0}, Lbc1;->R(ILandroid/content/Context;)Ljava/lang/String;

    .line 781
    .line 782
    .line 783
    move-result-object v1

    .line 784
    new-instance v3, Landroid/content/Intent;

    .line 785
    .line 786
    const-class v4, Lcom/deepseek/chat/system/ShareResultReceiver;

    .line 787
    .line 788
    invoke-direct {v3, v0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 789
    .line 790
    .line 791
    const-string v4, "INTENT_EXTRA_SHARE_SCENE"

    .line 792
    .line 793
    const-string v5, "link"

    .line 794
    .line 795
    invoke-virtual {v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 796
    .line 797
    .line 798
    const/high16 v4, 0xa000000

    .line 799
    .line 800
    const/4 v5, 0x0

    .line 801
    invoke-static {v0, v5, v3, v4}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 802
    .line 803
    .line 804
    move-result-object v3

    .line 805
    invoke-virtual {v3}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    .line 806
    .line 807
    .line 808
    move-result-object v3

    .line 809
    invoke-static {v2, v1, v3}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;Landroid/content/IntentSender;)Landroid/content/Intent;

    .line 810
    .line 811
    .line 812
    move-result-object v1

    .line 813
    const/high16 v3, 0x10000000

    .line 814
    .line 815
    invoke-virtual {v1, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 816
    .line 817
    .line 818
    move-result-object v1

    .line 819
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 820
    .line 821
    .line 822
    move-result-object v3

    .line 823
    invoke-virtual {v2, v3}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    .line 824
    .line 825
    .line 826
    move-result-object v2

    .line 827
    if-eqz v2, :cond_15

    .line 828
    .line 829
    :try_start_2
    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_2
    .catch Landroid/content/ActivityNotFoundException; {:try_start_2 .. :try_end_2} :catch_0

    .line 830
    .line 831
    .line 832
    :catch_0
    :cond_15
    sget-object v0, Lghb;->a:Lghb;

    .line 833
    .line 834
    return-object v0

    .line 835
    :pswitch_10
    move-object/from16 v1, p1

    .line 836
    .line 837
    check-cast v1, Ljava/lang/Boolean;

    .line 838
    .line 839
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 840
    .line 841
    .line 842
    move-result v1

    .line 843
    if-nez v1, :cond_16

    .line 844
    .line 845
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 846
    .line 847
    check-cast v0, Lp2b;

    .line 848
    .line 849
    iput-object v4, v0, Lp2b;->c:Lfv5;

    .line 850
    .line 851
    :cond_16
    sget-object v0, Lghb;->a:Lghb;

    .line 852
    .line 853
    return-object v0

    .line 854
    :pswitch_11
    move-object/from16 v1, p1

    .line 855
    .line 856
    check-cast v1, Ljava/lang/String;

    .line 857
    .line 858
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 859
    .line 860
    check-cast v0, Lcs;

    .line 861
    .line 862
    new-instance v2, Lp9c;

    .line 863
    .line 864
    const/4 v3, 0x2

    .line 865
    invoke-direct {v2, v3, v1}, Lp9c;-><init>(ILjava/lang/Object;)V

    .line 866
    .line 867
    .line 868
    iget-object v0, v0, Lcs;->a:Ljava/util/HashMap;

    .line 869
    .line 870
    const-string v1, "SESSION_CHANGED"

    .line 871
    .line 872
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 873
    .line 874
    .line 875
    move-result-object v0

    .line 876
    check-cast v0, Ljava/util/List;

    .line 877
    .line 878
    if-eqz v0, :cond_17

    .line 879
    .line 880
    check-cast v0, Ljava/lang/Iterable;

    .line 881
    .line 882
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 883
    .line 884
    .line 885
    move-result-object v0

    .line 886
    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 887
    .line 888
    .line 889
    move-result v1

    .line 890
    if-eqz v1, :cond_17

    .line 891
    .line 892
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 893
    .line 894
    .line 895
    move-result-object v1

    .line 896
    check-cast v1, Lds;

    .line 897
    .line 898
    invoke-interface {v1, v2}, Lds;->a(Lp9c;)V

    .line 899
    .line 900
    .line 901
    goto :goto_c

    .line 902
    :cond_17
    sget-object v0, Lghb;->a:Lghb;

    .line 903
    .line 904
    return-object v0

    .line 905
    :pswitch_12
    move-object/from16 v1, p1

    .line 906
    .line 907
    check-cast v1, Lsab;

    .line 908
    .line 909
    sget-object v2, Lghb;->a:Lghb;

    .line 910
    .line 911
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 912
    .line 913
    check-cast v0, Lsb2;

    .line 914
    .line 915
    iget-object v3, v0, Lsb2;->d:Lzs;

    .line 916
    .line 917
    if-eqz v3, :cond_1a

    .line 918
    .line 919
    iget-object v5, v3, Lzs;->a:Ljava/lang/String;

    .line 920
    .line 921
    iget-object v6, v1, Lsab;->c:Ljava/lang/String;

    .line 922
    .line 923
    invoke-static {v5, v6}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 924
    .line 925
    .line 926
    move-result v5

    .line 927
    if-eqz v5, :cond_18

    .line 928
    .line 929
    move-object v4, v3

    .line 930
    :cond_18
    if-nez v4, :cond_19

    .line 931
    .line 932
    goto :goto_d

    .line 933
    :cond_19
    invoke-virtual {v0, v1, v4}, Lsb2;->p(Lsab;Lzs;)V

    .line 934
    .line 935
    .line 936
    :cond_1a
    :goto_d
    return-object v2

    .line 937
    :pswitch_13
    sget-object v1, Lghb;->a:Lghb;

    .line 938
    .line 939
    move-object/from16 v2, p1

    .line 940
    .line 941
    check-cast v2, Lg72;

    .line 942
    .line 943
    sget-object v3, Le72;->c:Le72;

    .line 944
    .line 945
    invoke-static {v2, v3}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 946
    .line 947
    .line 948
    move-result v3

    .line 949
    if-nez v3, :cond_1b

    .line 950
    .line 951
    sget-object v3, Le72;->b:Le72;

    .line 952
    .line 953
    invoke-static {v2, v3}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 954
    .line 955
    .line 956
    move-result v3

    .line 957
    if-nez v3, :cond_1b

    .line 958
    .line 959
    goto :goto_f

    .line 960
    :cond_1b
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 961
    .line 962
    check-cast v0, Lh82;

    .line 963
    .line 964
    iget-object v3, v0, Lh82;->o:Ljava/lang/Object;

    .line 965
    .line 966
    monitor-enter v3

    .line 967
    :try_start_3
    iget-object v0, v0, Lh82;->p:Ljava/util/ArrayList;

    .line 968
    .line 969
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 970
    .line 971
    .line 972
    move-result v5

    .line 973
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->listIterator(I)Ljava/util/ListIterator;

    .line 974
    .line 975
    .line 976
    move-result-object v0

    .line 977
    :cond_1c
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 978
    .line 979
    .line 980
    move-result v5

    .line 981
    if-eqz v5, :cond_1d

    .line 982
    .line 983
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 984
    .line 985
    .line 986
    move-result-object v5

    .line 987
    move-object v6, v5

    .line 988
    check-cast v6, Lu72;

    .line 989
    .line 990
    iget-object v6, v6, Lu72;->b:Llr0;

    .line 991
    .line 992
    if-eqz v6, :cond_1c

    .line 993
    .line 994
    goto :goto_e

    .line 995
    :catchall_2
    move-exception v0

    .line 996
    goto :goto_10

    .line 997
    :cond_1d
    move-object v5, v4

    .line 998
    :goto_e
    check-cast v5, Lu72;

    .line 999
    .line 1000
    if-eqz v5, :cond_1e

    .line 1001
    .line 1002
    iget-object v4, v5, Lu72;->b:Llr0;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 1003
    .line 1004
    :cond_1e
    monitor-exit v3

    .line 1005
    if-eqz v4, :cond_1f

    .line 1006
    .line 1007
    invoke-virtual {v4, v2}, Llr0;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1008
    .line 1009
    .line 1010
    :cond_1f
    :goto_f
    return-object v1

    .line 1011
    :goto_10
    monitor-exit v3

    .line 1012
    throw v0

    .line 1013
    :pswitch_14
    move-object/from16 v2, p1

    .line 1014
    .line 1015
    check-cast v2, Lfv1;

    .line 1016
    .line 1017
    invoke-virtual {v0, v2, v1}, Lr3;->c(Lfv1;Ldc3;)Ljava/lang/Object;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v0

    .line 1021
    return-object v0

    .line 1022
    :pswitch_15
    move-object/from16 v1, p1

    .line 1023
    .line 1024
    check-cast v1, Ljava/lang/Number;

    .line 1025
    .line 1026
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 1027
    .line 1028
    .line 1029
    move-result v1

    .line 1030
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1031
    .line 1032
    check-cast v0, Lhj1;

    .line 1033
    .line 1034
    iget-object v0, v0, Lhj1;->c:Lwm6;

    .line 1035
    .line 1036
    if-eqz v0, :cond_20

    .line 1037
    .line 1038
    invoke-virtual {v0}, Lwm6;->j()Lvi1;

    .line 1039
    .line 1040
    .line 1041
    move-result-object v0

    .line 1042
    if-eqz v0, :cond_20

    .line 1043
    .line 1044
    check-cast v0, Lx7;

    .line 1045
    .line 1046
    invoke-virtual {v0, v1}, Lx7;->b(F)Ljp6;

    .line 1047
    .line 1048
    .line 1049
    :cond_20
    sget-object v0, Lghb;->a:Lghb;

    .line 1050
    .line 1051
    return-object v0

    .line 1052
    :pswitch_16
    move-object/from16 v1, p1

    .line 1053
    .line 1054
    check-cast v1, Ljava/lang/Number;

    .line 1055
    .line 1056
    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    .line 1057
    .line 1058
    .line 1059
    move-result v1

    .line 1060
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1061
    .line 1062
    check-cast v0, Lr98;

    .line 1063
    .line 1064
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 1065
    .line 1066
    .line 1067
    move-result v2

    .line 1068
    const v3, 0x7f7fffff    # Float.MAX_VALUE

    .line 1069
    .line 1070
    .line 1071
    cmpg-float v2, v2, v3

    .line 1072
    .line 1073
    if-gtz v2, :cond_21

    .line 1074
    .line 1075
    const/4 v2, 0x0

    .line 1076
    cmpg-float v3, v1, v2

    .line 1077
    .line 1078
    if-gez v3, :cond_22

    .line 1079
    .line 1080
    move v1, v2

    .line 1081
    goto :goto_11

    .line 1082
    :cond_21
    const/high16 v1, 0x3f800000    # 1.0f

    .line 1083
    .line 1084
    :cond_22
    :goto_11
    invoke-virtual {v0, v1}, Lr98;->g(F)V

    .line 1085
    .line 1086
    .line 1087
    sget-object v0, Lghb;->a:Lghb;

    .line 1088
    .line 1089
    return-object v0

    .line 1090
    :pswitch_17
    move-object/from16 v1, p1

    .line 1091
    .line 1092
    check-cast v1, Lxs4;

    .line 1093
    .line 1094
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1095
    .line 1096
    check-cast v0, Lcom/deepseek/chat/services/foreground/BaseForegroundService;

    .line 1097
    .line 1098
    if-nez v1, :cond_23

    .line 1099
    .line 1100
    sget v1, Lcom/deepseek/chat/services/foreground/BaseForegroundService;->h:I

    .line 1101
    .line 1102
    invoke-virtual {v0}, Lcom/deepseek/chat/services/foreground/BaseForegroundService;->h()V

    .line 1103
    .line 1104
    .line 1105
    goto :goto_12

    .line 1106
    :cond_23
    const/4 v5, 0x0

    .line 1107
    iput-boolean v5, v0, Lcom/deepseek/chat/services/foreground/BaseForegroundService;->e:Z

    .line 1108
    .line 1109
    invoke-virtual {v0, v1}, Lcom/deepseek/chat/services/foreground/BaseForegroundService;->g(Lxs4;)V

    .line 1110
    .line 1111
    .line 1112
    :goto_12
    sget-object v0, Lghb;->a:Lghb;

    .line 1113
    .line 1114
    return-object v0

    .line 1115
    :pswitch_18
    move-object/from16 v2, p1

    .line 1116
    .line 1117
    check-cast v2, Ljava/lang/Integer;

    .line 1118
    .line 1119
    invoke-virtual {v0, v2, v1}, Lr3;->e(Ljava/lang/Integer;Ldc3;)Ljava/lang/Object;

    .line 1120
    .line 1121
    .line 1122
    move-result-object v0

    .line 1123
    return-object v0

    .line 1124
    :pswitch_19
    move-object/from16 v2, p1

    .line 1125
    .line 1126
    check-cast v2, Lipa;

    .line 1127
    .line 1128
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1129
    .line 1130
    check-cast v0, Lka0;

    .line 1131
    .line 1132
    iget-object v3, v0, Lka0;->d:Llea;

    .line 1133
    .line 1134
    :cond_24
    invoke-virtual {v3}, Llea;->getValue()Ljava/lang/Object;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v0

    .line 1138
    move-object v1, v0

    .line 1139
    check-cast v1, Lja0;

    .line 1140
    .line 1141
    iget-object v4, v1, Lja0;->b:Lp1;

    .line 1142
    .line 1143
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1144
    .line 1145
    .line 1146
    new-instance v1, Lja0;

    .line 1147
    .line 1148
    invoke-direct {v1, v2, v4}, Lja0;-><init>(Lipa;Lp1;)V

    .line 1149
    .line 1150
    .line 1151
    invoke-virtual {v3, v0, v1}, Llea;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1152
    .line 1153
    .line 1154
    move-result v0

    .line 1155
    if-eqz v0, :cond_24

    .line 1156
    .line 1157
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1158
    .line 1159
    const-string v1, "State: "

    .line 1160
    .line 1161
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1162
    .line 1163
    .line 1164
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1165
    .line 1166
    .line 1167
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1168
    .line 1169
    .line 1170
    move-result-object v0

    .line 1171
    invoke-static {v0}, Ly2c;->Q(Ljava/lang/String;)V

    .line 1172
    .line 1173
    .line 1174
    :cond_25
    invoke-virtual {v3}, Llea;->getValue()Ljava/lang/Object;

    .line 1175
    .line 1176
    .line 1177
    move-result-object v1

    .line 1178
    move-object v2, v1

    .line 1179
    check-cast v2, Lja0;

    .line 1180
    .line 1181
    iget-object v4, v2, Lja0;->b:Lp1;

    .line 1182
    .line 1183
    invoke-virtual {v4}, Lp1;->c()Lwf8;

    .line 1184
    .line 1185
    .line 1186
    move-result-object v4

    .line 1187
    invoke-virtual {v4, v0}, Lwf8;->add(Ljava/lang/Object;)Z

    .line 1188
    .line 1189
    .line 1190
    invoke-virtual {v4}, Lwf8;->k()Lp1;

    .line 1191
    .line 1192
    .line 1193
    move-result-object v4

    .line 1194
    invoke-virtual {v4}, Ln0;->a()I

    .line 1195
    .line 1196
    .line 1197
    move-result v5

    .line 1198
    const/16 v6, 0x64

    .line 1199
    .line 1200
    if-le v5, v6, :cond_26

    .line 1201
    .line 1202
    invoke-virtual {v4}, Ln0;->a()I

    .line 1203
    .line 1204
    .line 1205
    move-result v5

    .line 1206
    sub-int/2addr v5, v6

    .line 1207
    invoke-virtual {v4}, Ln0;->a()I

    .line 1208
    .line 1209
    .line 1210
    move-result v6

    .line 1211
    new-instance v7, Lno5;

    .line 1212
    .line 1213
    invoke-direct {v7, v4, v5, v6}, Lno5;-><init>(Lp1;II)V

    .line 1214
    .line 1215
    .line 1216
    invoke-static {v7}, Lgn3;->X(Ljava/lang/Iterable;)Lp1;

    .line 1217
    .line 1218
    .line 1219
    move-result-object v4

    .line 1220
    :cond_26
    iget-object v2, v2, Lja0;->a:Lipa;

    .line 1221
    .line 1222
    new-instance v5, Lja0;

    .line 1223
    .line 1224
    invoke-direct {v5, v2, v4}, Lja0;-><init>(Lipa;Lp1;)V

    .line 1225
    .line 1226
    .line 1227
    invoke-virtual {v3, v1, v5}, Llea;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1228
    .line 1229
    .line 1230
    move-result v1

    .line 1231
    if-eqz v1, :cond_25

    .line 1232
    .line 1233
    sget-object v0, Lghb;->a:Lghb;

    .line 1234
    .line 1235
    return-object v0

    .line 1236
    :pswitch_1a
    move-object/from16 v2, p1

    .line 1237
    .line 1238
    check-cast v2, Lea0;

    .line 1239
    .line 1240
    invoke-virtual {v0, v2, v1}, Lr3;->b(Lea0;Ldc3;)Ljava/lang/Object;

    .line 1241
    .line 1242
    .line 1243
    move-result-object v0

    .line 1244
    return-object v0

    .line 1245
    :pswitch_1b
    move-object/from16 v1, p1

    .line 1246
    .line 1247
    check-cast v1, Lghb;

    .line 1248
    .line 1249
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1250
    .line 1251
    check-cast v0, Lrtc;

    .line 1252
    .line 1253
    invoke-virtual {v0}, Lrtc;->G()V

    .line 1254
    .line 1255
    .line 1256
    sget-object v0, Lghb;->a:Lghb;

    .line 1257
    .line 1258
    return-object v0

    .line 1259
    :pswitch_1c
    move-object/from16 v1, p1

    .line 1260
    .line 1261
    check-cast v1, Lt3;

    .line 1262
    .line 1263
    iget-object v0, v0, Lr3;->b:Ljava/lang/Object;

    .line 1264
    .line 1265
    check-cast v0, Lu3;

    .line 1266
    .line 1267
    iget-object v2, v0, Lu3;->c:Landroid/view/accessibility/AccessibilityManager;

    .line 1268
    .line 1269
    iget-object v0, v0, Lu3;->a:Landroid/content/Context;

    .line 1270
    .line 1271
    if-eqz v2, :cond_28

    .line 1272
    .line 1273
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1274
    .line 1275
    const/16 v4, 0x1e

    .line 1276
    .line 1277
    if-lt v3, v4, :cond_27

    .line 1278
    .line 1279
    invoke-static {}, Lq3;->c()Landroid/view/accessibility/AccessibilityEvent;

    .line 1280
    .line 1281
    .line 1282
    move-result-object v3

    .line 1283
    goto :goto_13

    .line 1284
    :cond_27
    invoke-static {}, Landroid/view/accessibility/AccessibilityEvent;->obtain()Landroid/view/accessibility/AccessibilityEvent;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v3

    .line 1288
    :goto_13
    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;

    .line 1289
    .line 1290
    .line 1291
    move-result-object v4

    .line 1292
    iget-object v1, v1, Lt3;->a:Lly4;

    .line 1293
    .line 1294
    invoke-static {v0}, Lbc1;->M(Landroid/content/Context;)Landroid/content/Context;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v5

    .line 1298
    invoke-interface {v1, v5}, Lly4;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1299
    .line 1300
    .line 1301
    move-result-object v1

    .line 1302
    invoke-interface {v4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1303
    .line 1304
    .line 1305
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v0

    .line 1309
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityEvent;->setPackageName(Ljava/lang/CharSequence;)V

    .line 1310
    .line 1311
    .line 1312
    const/16 v0, 0x4000

    .line 1313
    .line 1314
    invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityEvent;->setEventType(I)V

    .line 1315
    .line 1316
    .line 1317
    :try_start_4
    invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityManager;->sendAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    :try_end_4
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_1

    .line 1318
    .line 1319
    .line 1320
    :catch_1
    :cond_28
    sget-object v0, Lghb;->a:Lghb;

    .line 1321
    .line 1322
    return-object v0

    .line 1323
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public b(Lea0;Ldc3;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, Lr3;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Llt0;

    .line 4
    .line 5
    instance-of v1, p2, Lc20;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    move-object v1, p2

    .line 10
    check-cast v1, Lc20;

    .line 11
    .line 12
    iget v2, v1, Lc20;->g:I

    .line 13
    .line 14
    const/high16 v3, -0x80000000

    .line 15
    .line 16
    and-int v4, v2, v3

    .line 17
    .line 18
    if-eqz v4, :cond_0

    .line 19
    .line 20
    sub-int/2addr v2, v3

    .line 21
    iput v2, v1, Lc20;->g:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v1, Lc20;

    .line 25
    .line 26
    invoke-direct {v1, p0, p2}, Lc20;-><init>(Lr3;Ldc3;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    iget-object p0, v1, Lc20;->e:Ljava/lang/Object;

    .line 30
    .line 31
    iget p2, v1, Lc20;->g:I

    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    const/4 v3, 0x1

    .line 35
    if-eqz p2, :cond_2

    .line 36
    .line 37
    if-ne p2, v3, :cond_1

    .line 38
    .line 39
    iget-object p1, v1, Lc20;->d:Lea0;

    .line 40
    .line 41
    invoke-static {p0}, Lu07;->z(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-static {p0}, Lrs0;->g(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-object v2

    .line 51
    :cond_2
    invoke-static {p0}, Lu07;->z(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    iput-object p1, v1, Lc20;->d:Lea0;

    .line 55
    .line 56
    iput v3, v1, Lc20;->g:I

    .line 57
    .line 58
    invoke-interface {v0, v1, p1}, Lhr9;->m(Ldc3;Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    sget-object p2, Lhd3;->a:Lhd3;

    .line 63
    .line 64
    if-ne p0, p2, :cond_3

    .line 65
    .line 66
    return-object p2

    .line 67
    :cond_3
    :goto_1
    instance-of p0, p1, Lda0;

    .line 68
    .line 69
    if-nez p0, :cond_4

    .line 70
    .line 71
    invoke-virtual {v0, v2}, Llt0;->n(Ljava/lang/Throwable;)Z

    .line 72
    .line 73
    .line 74
    :cond_4
    sget-object p0, Lghb;->a:Lghb;

    .line 75
    .line 76
    return-object p0
.end method

.method public c(Lfv1;Ldc3;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-object v0, p0, Lr3;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp52;

    .line 4
    .line 5
    iget-object v1, v0, Lp52;->e:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    instance-of v2, p2, Lm52;

    .line 10
    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    move-object v2, p2

    .line 14
    check-cast v2, Lm52;

    .line 15
    .line 16
    iget v3, v2, Lm52;->g:I

    .line 17
    .line 18
    const/high16 v4, -0x80000000

    .line 19
    .line 20
    and-int v5, v3, v4

    .line 21
    .line 22
    if-eqz v5, :cond_0

    .line 23
    .line 24
    sub-int/2addr v3, v4

    .line 25
    iput v3, v2, Lm52;->g:I

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    new-instance v2, Lm52;

    .line 29
    .line 30
    invoke-direct {v2, p0, p2}, Lm52;-><init>(Lr3;Ldc3;)V

    .line 31
    .line 32
    .line 33
    :goto_0
    iget-object p0, v2, Lm52;->e:Ljava/lang/Object;

    .line 34
    .line 35
    iget p2, v2, Lm52;->g:I

    .line 36
    .line 37
    const/4 v3, 0x2

    .line 38
    sget-object v4, Lghb;->a:Lghb;

    .line 39
    .line 40
    const/4 v5, 0x1

    .line 41
    const/4 v6, 0x0

    .line 42
    if-eqz p2, :cond_3

    .line 43
    .line 44
    if-eq p2, v5, :cond_2

    .line 45
    .line 46
    if-eq p2, v3, :cond_1

    .line 47
    .line 48
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 49
    .line 50
    invoke-static {p0}, Lrs0;->g(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    return-object v6

    .line 54
    :cond_1
    iget-object p1, v2, Lm52;->d:Ldu7;

    .line 55
    .line 56
    invoke-static {p0}, Lu07;->z(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    goto/16 :goto_a

    .line 60
    .line 61
    :cond_2
    invoke-static {p0}, Lu07;->z(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    return-object v4

    .line 65
    :cond_3
    invoke-static {p0}, Lu07;->z(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    instance-of p0, p1, Lcv1;

    .line 69
    .line 70
    if-eqz p0, :cond_4

    .line 71
    .line 72
    check-cast p1, Lcv1;

    .line 73
    .line 74
    iget-object p0, p1, Lcv1;->a:Ljava/lang/String;

    .line 75
    .line 76
    iput-object p0, v0, Lp52;->f:Ljava/lang/Object;

    .line 77
    .line 78
    return-object v4

    .line 79
    :cond_4
    instance-of p0, p1, Lev1;

    .line 80
    .line 81
    sget-object p2, Lhd3;->a:Lhd3;

    .line 82
    .line 83
    if-eqz p0, :cond_1a

    .line 84
    .line 85
    check-cast p1, Lev1;

    .line 86
    .line 87
    iget-object p0, p1, Lev1;->a:Lbia;

    .line 88
    .line 89
    iput v5, v2, Lm52;->g:I

    .line 90
    .line 91
    iget-object p1, v0, Lp52;->h:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast p1, Lcoc;

    .line 94
    .line 95
    iget v3, v0, Lp52;->c:I

    .line 96
    .line 97
    iget-object v7, p0, Lbia;->a:Ljava/lang/String;

    .line 98
    .line 99
    iget-object p0, p0, Lbia;->b:Ljava/lang/String;

    .line 100
    .line 101
    invoke-static {v7, v6}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v8

    .line 105
    const/4 v9, 0x0

    .line 106
    const-string v10, "InvalidEvent"

    .line 107
    .line 108
    if-eqz v8, :cond_a

    .line 109
    .line 110
    :try_start_0
    sget-object v1, Ls36;->a:Li36;

    .line 111
    .line 112
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    sget-object v3, Lwt3;->Companion:Lvt3;

    .line 116
    .line 117
    invoke-virtual {v3}, Lvt3;->serializer()Lbb6;

    .line 118
    .line 119
    .line 120
    move-result-object v3

    .line 121
    check-cast v3, Lbb6;

    .line 122
    .line 123
    invoke-virtual {v1, v3, p0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 127
    check-cast p0, Lwt3;

    .line 128
    .line 129
    iget-boolean v1, v0, Lp52;->b:Z

    .line 130
    .line 131
    if-nez v1, :cond_7

    .line 132
    .line 133
    iget-object p0, p0, Lwt3;->c:Lh26;

    .line 134
    .line 135
    invoke-virtual {p1, p0}, Lcoc;->c0(Lh26;)Lida;

    .line 136
    .line 137
    .line 138
    move-result-object p0

    .line 139
    if-eqz p0, :cond_6

    .line 140
    .line 141
    iget-object p0, p0, Lida;->a:Lky;

    .line 142
    .line 143
    invoke-virtual {v0, p0}, Lp52;->g(Lyr;)V

    .line 144
    .line 145
    .line 146
    iget-object v1, p0, Lky;->n:Ljy1;

    .line 147
    .line 148
    iget-object v3, v1, Ljy1;->a:Lzaa;

    .line 149
    .line 150
    invoke-virtual {v3}, Lzaa;->isEmpty()Z

    .line 151
    .line 152
    .line 153
    move-result v3

    .line 154
    if-eqz v3, :cond_5

    .line 155
    .line 156
    iget-object v3, p0, Lky;->A:Llea;

    .line 157
    .line 158
    iget-object v7, p0, Lyr;->e:Lzw2;

    .line 159
    .line 160
    invoke-virtual {v3, v7}, Llea;->j(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :cond_5
    iget-object p0, p0, Lky;->C:Llea;

    .line 164
    .line 165
    invoke-static {v1}, Lx17;->y(Ljava/util/List;)Lrl9;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    .line 171
    .line 172
    invoke-virtual {p0, v6, v1}, Llea;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    iput-boolean v5, v0, Lp52;->b:Z

    .line 176
    .line 177
    goto :goto_1

    .line 178
    :cond_6
    new-instance p0, Lq52;

    .line 179
    .line 180
    invoke-direct {p0, v10, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 181
    .line 182
    .line 183
    throw p0

    .line 184
    :cond_7
    invoke-virtual {p1, p0, v6}, Lcoc;->W(Lwt3;Liv1;)Z

    .line 185
    .line 186
    .line 187
    move-result p0

    .line 188
    if-eqz p0, :cond_9

    .line 189
    .line 190
    :goto_1
    iget-object p0, p1, Lcoc;->c:Ljava/lang/Object;

    .line 191
    .line 192
    check-cast p0, Lida;

    .line 193
    .line 194
    if-eqz p0, :cond_8

    .line 195
    .line 196
    iget-object p0, p0, Lida;->a:Lky;

    .line 197
    .line 198
    invoke-virtual {v0, p0, v2}, Lp52;->d(Lyr;Lec3;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object p0

    .line 202
    if-ne p0, p2, :cond_18

    .line 203
    .line 204
    goto/16 :goto_5

    .line 205
    .line 206
    :cond_8
    const-string p0, "Required value was null."

    .line 207
    .line 208
    invoke-static {p0}, Lrs0;->g(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    return-object v6

    .line 212
    :cond_9
    new-instance p0, Lq52;

    .line 213
    .line 214
    const-string p1, "InvalidDelta"

    .line 215
    .line 216
    invoke-direct {p0, p1, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 217
    .line 218
    .line 219
    throw p0

    .line 220
    :catch_0
    new-instance p0, Lq52;

    .line 221
    .line 222
    invoke-direct {p0, v10, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 223
    .line 224
    .line 225
    throw p0

    .line 226
    :cond_a
    const-string p1, "ready"

    .line 227
    .line 228
    invoke-static {v7, p1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    move-result p1

    .line 232
    const-string v5, "parse_error"

    .line 233
    .line 234
    const-string v8, "delta"

    .line 235
    .line 236
    if-eqz p1, :cond_10

    .line 237
    .line 238
    sget-object p1, Ls36;->a:Li36;

    .line 239
    .line 240
    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 241
    .line 242
    .line 243
    sget-object v10, Lwu1;->Companion:Lvu1;

    .line 244
    .line 245
    invoke-virtual {v10}, Lvu1;->serializer()Lbb6;

    .line 246
    .line 247
    .line 248
    move-result-object v10

    .line 249
    check-cast v10, Lbb6;

    .line 250
    .line 251
    invoke-virtual {p1, v10, p0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v6
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 255
    :catch_1
    if-nez v6, :cond_c

    .line 256
    .line 257
    iget-object p0, v0, Lp52;->f:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast p0, Ljava/lang/String;

    .line 260
    .line 261
    if-nez v7, :cond_b

    .line 262
    .line 263
    move-object v7, v8

    .line 264
    :cond_b
    new-instance p1, Ljava/lang/Integer;

    .line 265
    .line 266
    invoke-direct {p1, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 267
    .line 268
    .line 269
    invoke-static {v1, p1, p0, v7, v5}, Lfu0;->u(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 270
    .line 271
    .line 272
    :cond_c
    check-cast v6, Lwu1;

    .line 273
    .line 274
    if-nez v6, :cond_d

    .line 275
    .line 276
    goto/16 :goto_4

    .line 277
    .line 278
    :cond_d
    iget-object p0, v6, Lwu1;->b:Ljava/lang/Integer;

    .line 279
    .line 280
    if-eqz p0, :cond_f

    .line 281
    .line 282
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 283
    .line 284
    .line 285
    move-result p0

    .line 286
    if-ne p0, v3, :cond_e

    .line 287
    .line 288
    goto :goto_2

    .line 289
    :cond_e
    new-instance p0, Lq52;

    .line 290
    .line 291
    const-string p1, "UnexpectedMessage"

    .line 292
    .line 293
    invoke-direct {p0, p1, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 294
    .line 295
    .line 296
    throw p0

    .line 297
    :cond_f
    :goto_2
    new-instance p0, Le52;

    .line 298
    .line 299
    invoke-direct {p0, v6}, Le52;-><init>(Lwu1;)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v0, p0, v2}, Lp52;->b(Lh52;Lec3;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object p0

    .line 306
    if-ne p0, p2, :cond_18

    .line 307
    .line 308
    goto/16 :goto_5

    .line 309
    .line 310
    :cond_10
    const-string p1, "hint"

    .line 311
    .line 312
    invoke-static {v7, p1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 313
    .line 314
    .line 315
    move-result p1

    .line 316
    if-eqz p1, :cond_15

    .line 317
    .line 318
    sget-object p1, Ls36;->a:Li36;

    .line 319
    .line 320
    :try_start_2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 321
    .line 322
    .line 323
    sget-object v9, Ltu1;->Companion:Lsu1;

    .line 324
    .line 325
    invoke-virtual {v9}, Lsu1;->serializer()Lbb6;

    .line 326
    .line 327
    .line 328
    move-result-object v9

    .line 329
    check-cast v9, Lbb6;

    .line 330
    .line 331
    invoke-virtual {p1, v9, p0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 332
    .line 333
    .line 334
    move-result-object p0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 335
    goto :goto_3

    .line 336
    :catch_2
    move-object p0, v6

    .line 337
    :goto_3
    if-nez p0, :cond_12

    .line 338
    .line 339
    iget-object p1, v0, Lp52;->f:Ljava/lang/Object;

    .line 340
    .line 341
    check-cast p1, Ljava/lang/String;

    .line 342
    .line 343
    if-nez v7, :cond_11

    .line 344
    .line 345
    move-object v7, v8

    .line 346
    :cond_11
    new-instance v8, Ljava/lang/Integer;

    .line 347
    .line 348
    invoke-direct {v8, v3}, Ljava/lang/Integer;-><init>(I)V

    .line 349
    .line 350
    .line 351
    invoke-static {v1, v8, p1, v7, v5}, Lfu0;->u(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 352
    .line 353
    .line 354
    :cond_12
    check-cast p0, Ltu1;

    .line 355
    .line 356
    if-eqz p0, :cond_13

    .line 357
    .line 358
    iget-object v6, p0, Ltu1;->a:Ljt9;

    .line 359
    .line 360
    :cond_13
    if-nez v6, :cond_14

    .line 361
    .line 362
    goto/16 :goto_4

    .line 363
    .line 364
    :cond_14
    new-instance p0, Lc52;

    .line 365
    .line 366
    invoke-direct {p0, v6}, Lc52;-><init>(Ljt9;)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v0, p0, v2}, Lp52;->b(Lh52;Lec3;)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object p0

    .line 373
    if-ne p0, p2, :cond_18

    .line 374
    .line 375
    goto :goto_5

    .line 376
    :cond_15
    const-string/jumbo p1, "title"

    .line 377
    .line 378
    .line 379
    invoke-static {v7, p1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 380
    .line 381
    .line 382
    move-result p1

    .line 383
    if-eqz p1, :cond_16

    .line 384
    .line 385
    :try_start_3
    sget-object p1, Ls36;->a:Li36;

    .line 386
    .line 387
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 388
    .line 389
    .line 390
    sget-object v1, Lsv1;->Companion:Lrv1;

    .line 391
    .line 392
    invoke-virtual {v1}, Lrv1;->serializer()Lbb6;

    .line 393
    .line 394
    .line 395
    move-result-object v1

    .line 396
    check-cast v1, Lbb6;

    .line 397
    .line 398
    invoke-virtual {p1, v1, p0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object p0
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_3

    .line 402
    check-cast p0, Lsv1;

    .line 403
    .line 404
    new-instance p1, Lg52;

    .line 405
    .line 406
    invoke-direct {p1, p0}, Lg52;-><init>(Lsv1;)V

    .line 407
    .line 408
    .line 409
    invoke-virtual {v0, p1, v2}, Lp52;->b(Lh52;Lec3;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object p0

    .line 413
    if-ne p0, p2, :cond_18

    .line 414
    .line 415
    goto :goto_5

    .line 416
    :catch_3
    new-instance p0, Lq52;

    .line 417
    .line 418
    invoke-direct {p0, v10, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 419
    .line 420
    .line 421
    throw p0

    .line 422
    :cond_16
    const-string/jumbo p1, "update_session"

    .line 423
    .line 424
    .line 425
    invoke-static {v7, p1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 426
    .line 427
    .line 428
    move-result p1

    .line 429
    if-eqz p1, :cond_17

    .line 430
    .line 431
    :try_start_4
    sget-object p1, Ls36;->a:Li36;

    .line 432
    .line 433
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 434
    .line 435
    .line 436
    sget-object v1, Lew1;->Companion:Ldw1;

    .line 437
    .line 438
    invoke-virtual {v1}, Ldw1;->serializer()Lbb6;

    .line 439
    .line 440
    .line 441
    move-result-object v1

    .line 442
    check-cast v1, Lbb6;

    .line 443
    .line 444
    invoke-virtual {p1, v1, p0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    move-result-object p0
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_4

    .line 448
    check-cast p0, Lew1;

    .line 449
    .line 450
    new-instance p1, Lf52;

    .line 451
    .line 452
    invoke-direct {p1, p0}, Lf52;-><init>(Lew1;)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {v0, p1, v2}, Lp52;->b(Lh52;Lec3;)Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object p0

    .line 459
    if-ne p0, p2, :cond_18

    .line 460
    .line 461
    goto :goto_5

    .line 462
    :catch_4
    new-instance p0, Lq52;

    .line 463
    .line 464
    invoke-direct {p0, v10, v9}, Lq52;-><init>(Ljava/lang/String;I)V

    .line 465
    .line 466
    .line 467
    throw p0

    .line 468
    :cond_17
    const-string p0, "close"

    .line 469
    .line 470
    invoke-static {v7, p0}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 471
    .line 472
    .line 473
    move-result p0

    .line 474
    if-eqz p0, :cond_18

    .line 475
    .line 476
    sget-object p0, Lb52;->a:Lb52;

    .line 477
    .line 478
    invoke-virtual {v0, p0, v2}, Lp52;->b(Lh52;Lec3;)Ljava/lang/Object;

    .line 479
    .line 480
    .line 481
    move-result-object p0

    .line 482
    if-ne p0, p2, :cond_18

    .line 483
    .line 484
    goto :goto_5

    .line 485
    :cond_18
    :goto_4
    move-object p0, v4

    .line 486
    :goto_5
    if-ne p0, p2, :cond_19

    .line 487
    .line 488
    goto/16 :goto_9

    .line 489
    .line 490
    :cond_19
    return-object v4

    .line 491
    :cond_1a
    instance-of p0, p1, Ldv1;

    .line 492
    .line 493
    if-eqz p0, :cond_21

    .line 494
    .line 495
    check-cast p1, Ldv1;

    .line 496
    .line 497
    iget-object p0, p1, Ldv1;->a:Lgt9;

    .line 498
    .line 499
    iget-object p1, p0, Lgt9;->h:Lqs9;

    .line 500
    .line 501
    iget-object v1, p0, Lgt9;->d:Ljava/lang/String;

    .line 502
    .line 503
    iget-object v4, p0, Lgt9;->c:Ljava/lang/String;

    .line 504
    .line 505
    if-nez p1, :cond_1b

    .line 506
    .line 507
    iget-object p1, p0, Lgt9;->i:Lqs9;

    .line 508
    .line 509
    if-nez p1, :cond_1b

    .line 510
    .line 511
    new-instance p0, Lcu7;

    .line 512
    .line 513
    invoke-direct {p0, v4, v1}, Lcu7;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 514
    .line 515
    .line 516
    :goto_6
    move-object p1, p0

    .line 517
    goto :goto_7

    .line 518
    :cond_1b
    :try_start_5
    invoke-virtual {p0}, Lgt9;->b()Ljava/lang/Object;

    .line 519
    .line 520
    .line 521
    move-result-object p0

    .line 522
    check-cast p0, Lmt9;
    :try_end_5
    .catch Lat9; {:try_start_5 .. :try_end_5} :catch_6

    .line 523
    .line 524
    if-nez p0, :cond_1c

    .line 525
    .line 526
    new-instance p0, Lcu7;

    .line 527
    .line 528
    invoke-direct {p0, v4, v1}, Lcu7;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 529
    .line 530
    .line 531
    goto :goto_6

    .line 532
    :cond_1c
    :try_start_6
    iget-object p1, p0, Lmt9;->a:Ljava/lang/Object;

    .line 533
    .line 534
    invoke-static {p0}, Ltw5;->E(Lmt9;)Ldu1;

    .line 535
    .line 536
    .line 537
    move-result-object p0

    .line 538
    if-eqz p0, :cond_1d

    .line 539
    .line 540
    new-instance v5, Lwt7;

    .line 541
    .line 542
    invoke-direct {v5, p1, p0}, Lwt7;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 543
    .line 544
    .line 545
    move-object p1, v5

    .line 546
    goto :goto_7

    .line 547
    :cond_1d
    new-instance p0, Lau7;

    .line 548
    .line 549
    invoke-direct {p0, p1, v4, v1}, Lau7;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_6} :catch_5

    .line 550
    .line 551
    .line 552
    goto :goto_6

    .line 553
    :catch_5
    new-instance p0, Lcu7;

    .line 554
    .line 555
    invoke-direct {p0, v4, v1}, Lcu7;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 556
    .line 557
    .line 558
    goto :goto_6

    .line 559
    :catch_6
    move-exception p0

    .line 560
    new-instance p1, Lbu7;

    .line 561
    .line 562
    invoke-direct {p1, p0, v4, v1}, Lbu7;-><init>(Lat9;Ljava/lang/String;Ljava/lang/String;)V

    .line 563
    .line 564
    .line 565
    move-object p0, p1

    .line 566
    goto :goto_6

    .line 567
    :goto_7
    invoke-virtual {p1}, Ldu7;->b()Ljava/lang/Object;

    .line 568
    .line 569
    .line 570
    move-result-object p0

    .line 571
    instance-of v1, p0, Lau1;

    .line 572
    .line 573
    if-eqz v1, :cond_1e

    .line 574
    .line 575
    check-cast p0, Lau1;

    .line 576
    .line 577
    goto :goto_8

    .line 578
    :cond_1e
    move-object p0, v6

    .line 579
    :goto_8
    if-eqz p0, :cond_1f

    .line 580
    .line 581
    iget-object v6, p0, Lau1;->a:Liy;

    .line 582
    .line 583
    :cond_1f
    if-eqz v6, :cond_20

    .line 584
    .line 585
    iput-object p1, v2, Lm52;->d:Ldu7;

    .line 586
    .line 587
    iput v3, v2, Lm52;->g:I

    .line 588
    .line 589
    invoke-virtual {v0, v6, v2}, Lp52;->d(Lyr;Lec3;)Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    move-result-object p0

    .line 593
    if-ne p0, p2, :cond_20

    .line 594
    .line 595
    :goto_9
    return-object p2

    .line 596
    :cond_20
    :goto_a
    new-instance p0, Lj52;

    .line 597
    .line 598
    invoke-direct {p0, p1}, Lj52;-><init>(Ldu7;)V

    .line 599
    .line 600
    .line 601
    throw p0

    .line 602
    :cond_21
    invoke-static {}, Lgf3;->d()V

    .line 603
    .line 604
    .line 605
    return-object v6
.end method

.method public d(Lfq5;Ldc3;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    sget-object v3, Ley4;->b:Ley4;

    .line 8
    .line 9
    iget-object v4, v0, Lr3;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v4, Li2b;

    .line 12
    .line 13
    instance-of v5, v2, Lhy4;

    .line 14
    .line 15
    if-eqz v5, :cond_0

    .line 16
    .line 17
    move-object v5, v2

    .line 18
    check-cast v5, Lhy4;

    .line 19
    .line 20
    iget v6, v5, Lhy4;->g:I

    .line 21
    .line 22
    const/high16 v7, -0x80000000

    .line 23
    .line 24
    and-int v8, v6, v7

    .line 25
    .line 26
    if-eqz v8, :cond_0

    .line 27
    .line 28
    sub-int/2addr v6, v7

    .line 29
    iput v6, v5, Lhy4;->g:I

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_0
    new-instance v5, Lhy4;

    .line 33
    .line 34
    invoke-direct {v5, v0, v2}, Lhy4;-><init>(Lr3;Ldc3;)V

    .line 35
    .line 36
    .line 37
    :goto_0
    iget-object v0, v5, Lhy4;->e:Ljava/lang/Object;

    .line 38
    .line 39
    iget v2, v5, Lhy4;->g:I

    .line 40
    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x1

    .line 43
    sget-object v8, Lghb;->a:Lghb;

    .line 44
    .line 45
    if-eqz v2, :cond_2

    .line 46
    .line 47
    if-ne v2, v7, :cond_1

    .line 48
    .line 49
    iget-object v1, v5, Lhy4;->d:Ldq5;

    .line 50
    .line 51
    :try_start_0
    invoke-static {v0}, Lu07;->z(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 52
    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 56
    .line 57
    invoke-static {v0}, Lrs0;->g(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    return-object v6

    .line 61
    :cond_2
    invoke-static {v0}, Lu07;->z(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    iget-object v0, v4, Li2b;->h:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v0, Lfy4;

    .line 67
    .line 68
    iget-object v2, v4, Li2b;->d:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v2, Lwnc;

    .line 71
    .line 72
    if-nez v0, :cond_3

    .line 73
    .line 74
    goto/16 :goto_5

    .line 75
    .line 76
    :cond_3
    instance-of v0, v1, Ldq5;

    .line 77
    .line 78
    if-eqz v0, :cond_7

    .line 79
    .line 80
    move-object v0, v1

    .line 81
    check-cast v0, Ldq5;

    .line 82
    .line 83
    iget-object v0, v0, Ldq5;->a:Lgt9;

    .line 84
    .line 85
    iget-object v0, v0, Lgt9;->h:Lqs9;

    .line 86
    .line 87
    if-eqz v0, :cond_4

    .line 88
    .line 89
    iget v0, v0, Lqs9;->a:I

    .line 90
    .line 91
    const v9, 0x9c5d

    .line 92
    .line 93
    .line 94
    if-ne v0, v9, :cond_4

    .line 95
    .line 96
    sget-object v0, Ley4;->i:Ley4;

    .line 97
    .line 98
    invoke-virtual {v4, v0}, Li2b;->l(Ley4;)V

    .line 99
    .line 100
    .line 101
    const-string v0, "Rate Limit"

    .line 102
    .line 103
    invoke-virtual {v2, v0}, Lwnc;->v(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    return-object v8

    .line 107
    :cond_4
    :try_start_1
    move-object v0, v1

    .line 108
    check-cast v0, Ldq5;

    .line 109
    .line 110
    iget-object v0, v0, Ldq5;->a:Lgt9;

    .line 111
    .line 112
    move-object v2, v1

    .line 113
    check-cast v2, Ldq5;

    .line 114
    .line 115
    iput-object v2, v5, Lhy4;->d:Ldq5;

    .line 116
    .line 117
    iput v7, v5, Lhy4;->g:I

    .line 118
    .line 119
    invoke-virtual {v0, v7, v5}, Lgt9;->a(ZLdc3;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 123
    sget-object v2, Lhd3;->a:Lhd3;

    .line 124
    .line 125
    if-ne v0, v2, :cond_5

    .line 126
    .line 127
    return-object v2

    .line 128
    :catchall_0
    :cond_5
    :goto_1
    iget-object v0, v4, Li2b;->d:Ljava/lang/Object;

    .line 129
    .line 130
    check-cast v0, Lwnc;

    .line 131
    .line 132
    check-cast v1, Ldq5;

    .line 133
    .line 134
    iget-object v1, v1, Ldq5;->a:Lgt9;

    .line 135
    .line 136
    iget-object v1, v1, Lgt9;->h:Lqs9;

    .line 137
    .line 138
    if-eqz v1, :cond_6

    .line 139
    .line 140
    iget-object v6, v1, Lqs9;->b:Ljava/lang/String;

    .line 141
    .line 142
    :cond_6
    invoke-virtual {v0, v6}, Lwnc;->v(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v4, v3}, Li2b;->l(Ley4;)V

    .line 146
    .line 147
    .line 148
    return-object v8

    .line 149
    :cond_7
    instance-of v0, v1, Lcq5;

    .line 150
    .line 151
    if-nez v0, :cond_1e

    .line 152
    .line 153
    instance-of v0, v1, Leq5;

    .line 154
    .line 155
    const/16 v5, 0xa

    .line 156
    .line 157
    const-string v7, "success"

    .line 158
    .line 159
    if-eqz v0, :cond_15

    .line 160
    .line 161
    move-object v0, v1

    .line 162
    check-cast v0, Leq5;

    .line 163
    .line 164
    iget-object v0, v0, Leq5;->a:Lwm9;

    .line 165
    .line 166
    iget-object v1, v0, Lwm9;->a:Ljava/lang/String;

    .line 167
    .line 168
    iget-object v0, v0, Lwm9;->b:Ljava/lang/String;

    .line 169
    .line 170
    const-string v9, "item"

    .line 171
    .line 172
    invoke-static {v1, v9}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    move-result v9

    .line 176
    if-eqz v9, :cond_9

    .line 177
    .line 178
    sget-object v1, Ls36;->a:Li36;

    .line 179
    .line 180
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 181
    .line 182
    .line 183
    sget-object v2, Lrp5;->Companion:Lqp5;

    .line 184
    .line 185
    invoke-virtual {v2}, Lqp5;->serializer()Lbb6;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    check-cast v2, Lbb6;

    .line 190
    .line 191
    invoke-virtual {v1, v2, v0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    check-cast v0, Lrp5;

    .line 196
    .line 197
    iget-object v10, v0, Lrp5;->a:Ljava/lang/String;

    .line 198
    .line 199
    iget v11, v0, Lrp5;->b:I

    .line 200
    .line 201
    iget-wide v12, v0, Lrp5;->e:D

    .line 202
    .line 203
    iget-object v14, v0, Lrp5;->g:Lmb5;

    .line 204
    .line 205
    iget-object v15, v0, Lrp5;->h:Ljava/lang/String;

    .line 206
    .line 207
    iget-object v1, v0, Lrp5;->c:Ljava/lang/String;

    .line 208
    .line 209
    iget-object v2, v0, Lrp5;->d:Ljava/lang/Integer;

    .line 210
    .line 211
    iget-object v3, v0, Lrp5;->i:Lmb5;

    .line 212
    .line 213
    iget-object v6, v0, Lrp5;->k:Ljava/util/List;

    .line 214
    .line 215
    check-cast v6, Ljava/lang/Iterable;

    .line 216
    .line 217
    new-instance v7, Ljava/util/ArrayList;

    .line 218
    .line 219
    invoke-static {v6, v5}, Lk03;->V(Ljava/lang/Iterable;I)I

    .line 220
    .line 221
    .line 222
    move-result v5

    .line 223
    invoke-direct {v7, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 224
    .line 225
    .line 226
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 227
    .line 228
    .line 229
    move-result-object v5

    .line 230
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 231
    .line 232
    .line 233
    move-result v6

    .line 234
    if-eqz v6, :cond_8

    .line 235
    .line 236
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 237
    .line 238
    .line 239
    move-result-object v6

    .line 240
    check-cast v6, Lup5;

    .line 241
    .line 242
    new-instance v9, Lxk9;

    .line 243
    .line 244
    move-object/from16 v16, v1

    .line 245
    .line 246
    iget-object v1, v6, Lup5;->a:Ljava/lang/String;

    .line 247
    .line 248
    iget-object v6, v6, Lup5;->b:Lmb5;

    .line 249
    .line 250
    invoke-direct {v9, v1, v6}, Lxk9;-><init>(Ljava/lang/String;Lmb5;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    move-object/from16 v1, v16

    .line 257
    .line 258
    goto :goto_2

    .line 259
    :cond_8
    move-object/from16 v16, v1

    .line 260
    .line 261
    iget v1, v0, Lrp5;->l:I

    .line 262
    .line 263
    iget v5, v0, Lrp5;->m:I

    .line 264
    .line 265
    iget-boolean v6, v0, Lrp5;->j:Z

    .line 266
    .line 267
    new-instance v9, Lyk9;

    .line 268
    .line 269
    move/from16 v20, v1

    .line 270
    .line 271
    move-object/from16 v17, v2

    .line 272
    .line 273
    move-object/from16 v18, v3

    .line 274
    .line 275
    move/from16 v21, v5

    .line 276
    .line 277
    move/from16 v22, v6

    .line 278
    .line 279
    move-object/from16 v19, v7

    .line 280
    .line 281
    invoke-direct/range {v9 .. v22}, Lyk9;-><init>(Ljava/lang/String;IDLmb5;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lmb5;Ljava/util/ArrayList;IIZ)V

    .line 282
    .line 283
    .line 284
    iget-object v0, v0, Lrp5;->f:Ljava/lang/String;

    .line 285
    .line 286
    invoke-static {v4, v9, v0}, Li2b;->d(Li2b;Lal9;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    return-object v8

    .line 290
    :cond_9
    const-string v9, "chat_session_title_item"

    .line 291
    .line 292
    invoke-static {v1, v9}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    move-result v9

    .line 296
    if-eqz v9, :cond_a

    .line 297
    .line 298
    sget-object v1, Ls36;->a:Li36;

    .line 299
    .line 300
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    sget-object v2, Llp5;->Companion:Lkp5;

    .line 304
    .line 305
    invoke-virtual {v2}, Lkp5;->serializer()Lbb6;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    check-cast v2, Lbb6;

    .line 310
    .line 311
    invoke-virtual {v1, v2, v0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object v0

    .line 315
    check-cast v0, Llp5;

    .line 316
    .line 317
    new-instance v9, Lzk9;

    .line 318
    .line 319
    iget-object v10, v0, Llp5;->a:Ljava/lang/String;

    .line 320
    .line 321
    iget-wide v11, v0, Llp5;->c:D

    .line 322
    .line 323
    iget-object v13, v0, Llp5;->b:Lmb5;

    .line 324
    .line 325
    iget-object v14, v0, Llp5;->e:Ljava/lang/String;

    .line 326
    .line 327
    invoke-direct/range {v9 .. v14}, Lzk9;-><init>(Ljava/lang/String;DLmb5;Ljava/lang/String;)V

    .line 328
    .line 329
    .line 330
    iget-object v0, v0, Llp5;->d:Ljava/lang/String;

    .line 331
    .line 332
    invoke-static {v4, v9, v0}, Li2b;->d(Li2b;Lal9;Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    return-object v8

    .line 336
    :cond_a
    const-string v9, "status"

    .line 337
    .line 338
    invoke-static {v1, v9}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 339
    .line 340
    .line 341
    move-result v9

    .line 342
    if-eqz v9, :cond_10

    .line 343
    .line 344
    sget-object v1, Ls36;->a:Li36;

    .line 345
    .line 346
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 347
    .line 348
    .line 349
    sget-object v2, Lxp5;->Companion:Lwp5;

    .line 350
    .line 351
    invoke-virtual {v2}, Lwp5;->serializer()Lbb6;

    .line 352
    .line 353
    .line 354
    move-result-object v2

    .line 355
    check-cast v2, Lbb6;

    .line 356
    .line 357
    invoke-virtual {v1, v2, v0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v0

    .line 361
    check-cast v0, Lxp5;

    .line 362
    .line 363
    iget-object v0, v0, Lxp5;->a:Ljava/lang/String;

    .line 364
    .line 365
    iget-object v1, v4, Li2b;->h:Ljava/lang/Object;

    .line 366
    .line 367
    check-cast v1, Lfy4;

    .line 368
    .line 369
    if-nez v1, :cond_b

    .line 370
    .line 371
    goto/16 :goto_5

    .line 372
    .line 373
    :cond_b
    iget-object v2, v1, Lfy4;->b:Ljava/lang/String;

    .line 374
    .line 375
    if-nez v2, :cond_c

    .line 376
    .line 377
    goto :goto_4

    .line 378
    :cond_c
    invoke-static {v5, v2}, Lwja;->H(ILjava/lang/String;)Ljava/lang/Long;

    .line 379
    .line 380
    .line 381
    move-result-object v3

    .line 382
    invoke-static {v5, v0}, Lwja;->H(ILjava/lang/String;)Ljava/lang/Long;

    .line 383
    .line 384
    .line 385
    move-result-object v5

    .line 386
    if-nez v3, :cond_d

    .line 387
    .line 388
    if-nez v5, :cond_f

    .line 389
    .line 390
    goto :goto_3

    .line 391
    :cond_d
    if-nez v5, :cond_e

    .line 392
    .line 393
    goto :goto_3

    .line 394
    :cond_e
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 395
    .line 396
    .line 397
    move-result-wide v9

    .line 398
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 399
    .line 400
    .line 401
    move-result-wide v11

    .line 402
    cmp-long v3, v9, v11

    .line 403
    .line 404
    if-gez v3, :cond_f

    .line 405
    .line 406
    :goto_3
    move-object v0, v2

    .line 407
    :cond_f
    :goto_4
    const/16 v2, 0xd

    .line 408
    .line 409
    invoke-static {v1, v0, v6, v6, v2}, Lfy4;->a(Lfy4;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;I)Lfy4;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    iput-object v0, v4, Li2b;->h:Ljava/lang/Object;

    .line 414
    .line 415
    return-object v8

    .line 416
    :cond_10
    const-string v5, "close"

    .line 417
    .line 418
    invoke-static {v1, v5}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 419
    .line 420
    .line 421
    move-result v1

    .line 422
    if-eqz v1, :cond_18

    .line 423
    .line 424
    sget-object v1, Ls36;->a:Li36;

    .line 425
    .line 426
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 427
    .line 428
    .line 429
    sget-object v5, Lop5;->Companion:Lnp5;

    .line 430
    .line 431
    invoke-virtual {v5}, Lnp5;->serializer()Lbb6;

    .line 432
    .line 433
    .line 434
    move-result-object v5

    .line 435
    check-cast v5, Lbb6;

    .line 436
    .line 437
    invoke-virtual {v1, v5, v0}, Lg16;->b(Lbb6;Ljava/lang/String;)Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v0

    .line 441
    check-cast v0, Lop5;

    .line 442
    .line 443
    iget-object v1, v4, Li2b;->h:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast v1, Lfy4;

    .line 446
    .line 447
    if-nez v1, :cond_11

    .line 448
    .line 449
    goto/16 :goto_5

    .line 450
    .line 451
    :cond_11
    iget-object v0, v0, Lop5;->a:Ljava/lang/String;

    .line 452
    .line 453
    const/4 v5, 0x7

    .line 454
    invoke-static {v1, v6, v6, v0, v5}, Lfy4;->a(Lfy4;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;I)Lfy4;

    .line 455
    .line 456
    .line 457
    move-result-object v1

    .line 458
    iput-object v1, v4, Li2b;->h:Ljava/lang/Object;

    .line 459
    .line 460
    sget-object v1, Lyy2;->Companion:Lwy2;

    .line 461
    .line 462
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 463
    .line 464
    .line 465
    invoke-static {v0, v7}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 466
    .line 467
    .line 468
    move-result v1

    .line 469
    if-nez v1, :cond_18

    .line 470
    .line 471
    const-string v1, "error"

    .line 472
    .line 473
    invoke-static {v0, v1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 474
    .line 475
    .line 476
    move-result v1

    .line 477
    if-eqz v1, :cond_12

    .line 478
    .line 479
    const-string v0, "Close Reason is Error"

    .line 480
    .line 481
    invoke-virtual {v2, v0}, Lwnc;->v(Ljava/lang/String;)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {v4, v3}, Li2b;->l(Ley4;)V

    .line 485
    .line 486
    .line 487
    return-object v8

    .line 488
    :cond_12
    const-string v1, "invalid_query"

    .line 489
    .line 490
    invoke-static {v0, v1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 491
    .line 492
    .line 493
    move-result v1

    .line 494
    if-eqz v1, :cond_13

    .line 495
    .line 496
    sget-object v0, Ley4;->d:Ley4;

    .line 497
    .line 498
    invoke-virtual {v4, v0}, Li2b;->l(Ley4;)V

    .line 499
    .line 500
    .line 501
    return-object v8

    .line 502
    :cond_13
    const-string/jumbo v1, "timeout"

    .line 503
    .line 504
    .line 505
    invoke-static {v0, v1}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 506
    .line 507
    .line 508
    move-result v1

    .line 509
    if-eqz v1, :cond_14

    .line 510
    .line 511
    sget-object v0, Ley4;->h:Ley4;

    .line 512
    .line 513
    invoke-virtual {v4, v0}, Li2b;->l(Ley4;)V

    .line 514
    .line 515
    .line 516
    return-object v8

    .line 517
    :cond_14
    invoke-virtual {v2, v0}, Lwnc;->v(Ljava/lang/String;)V

    .line 518
    .line 519
    .line 520
    invoke-virtual {v4, v3}, Li2b;->l(Ley4;)V

    .line 521
    .line 522
    .line 523
    return-object v8

    .line 524
    :cond_15
    sget-object v0, Lbq5;->a:Lbq5;

    .line 525
    .line 526
    invoke-static {v1, v0}, Luw5;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 527
    .line 528
    .line 529
    move-result v0

    .line 530
    if-eqz v0, :cond_1d

    .line 531
    .line 532
    iget-object v0, v4, Li2b;->h:Ljava/lang/Object;

    .line 533
    .line 534
    check-cast v0, Lfy4;

    .line 535
    .line 536
    if-nez v0, :cond_16

    .line 537
    .line 538
    goto :goto_5

    .line 539
    :cond_16
    iget-object v1, v0, Lfy4;->d:Ljava/lang/String;

    .line 540
    .line 541
    if-nez v1, :cond_17

    .line 542
    .line 543
    const-string v0, "Close reason is null"

    .line 544
    .line 545
    invoke-virtual {v2, v0}, Lwnc;->v(Ljava/lang/String;)V

    .line 546
    .line 547
    .line 548
    const-string v1, "FullTextSearchManager"

    .line 549
    .line 550
    invoke-static {v1}, Ly2c;->j0(Ljava/lang/String;)Lps6;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    invoke-virtual {v1, v0}, Lps6;->c(Ljava/lang/String;)V

    .line 555
    .line 556
    .line 557
    invoke-virtual {v4, v3}, Li2b;->l(Ley4;)V

    .line 558
    .line 559
    .line 560
    return-object v8

    .line 561
    :cond_17
    sget-object v6, Lyy2;->Companion:Lwy2;

    .line 562
    .line 563
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 564
    .line 565
    .line 566
    invoke-virtual {v1, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 567
    .line 568
    .line 569
    move-result v1

    .line 570
    if-nez v1, :cond_19

    .line 571
    .line 572
    :cond_18
    :goto_5
    return-object v8

    .line 573
    :cond_19
    iget-object v0, v0, Lfy4;->b:Ljava/lang/String;

    .line 574
    .line 575
    if-nez v0, :cond_1a

    .line 576
    .line 577
    const-string v0, "Without any cursor"

    .line 578
    .line 579
    invoke-virtual {v2, v0}, Lwnc;->v(Ljava/lang/String;)V

    .line 580
    .line 581
    .line 582
    invoke-virtual {v4, v3}, Li2b;->l(Ley4;)V

    .line 583
    .line 584
    .line 585
    return-object v8

    .line 586
    :cond_1a
    if-eqz v0, :cond_1c

    .line 587
    .line 588
    invoke-static {v5, v0}, Lwja;->H(ILjava/lang/String;)Ljava/lang/Long;

    .line 589
    .line 590
    .line 591
    move-result-object v0

    .line 592
    if-nez v0, :cond_1b

    .line 593
    .line 594
    goto :goto_6

    .line 595
    :cond_1b
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 596
    .line 597
    .line 598
    move-result-wide v0

    .line 599
    const-wide/16 v2, 0x0

    .line 600
    .line 601
    cmp-long v0, v0, v2

    .line 602
    .line 603
    if-nez v0, :cond_1c

    .line 604
    .line 605
    sget-object v0, Ley4;->f:Ley4;

    .line 606
    .line 607
    invoke-virtual {v4, v0}, Li2b;->l(Ley4;)V

    .line 608
    .line 609
    .line 610
    return-object v8

    .line 611
    :cond_1c
    :goto_6
    sget-object v0, Ley4;->g:Ley4;

    .line 612
    .line 613
    invoke-virtual {v4, v0}, Li2b;->l(Ley4;)V

    .line 614
    .line 615
    .line 616
    return-object v8

    .line 617
    :cond_1d
    invoke-static {}, Lgf3;->d()V

    .line 618
    .line 619
    .line 620
    return-object v6

    .line 621
    :cond_1e
    return-object v8
.end method

.method public e(Ljava/lang/Integer;Ldc3;)Ljava/lang/Object;
    .locals 9

    .line 1
    sget-object v0, Lghb;->a:Lghb;

    .line 2
    .line 3
    instance-of v1, p2, Lya0;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    move-object v1, p2

    .line 8
    check-cast v1, Lya0;

    .line 9
    .line 10
    iget v2, v1, Lya0;->j:I

    .line 11
    .line 12
    const/high16 v3, -0x80000000

    .line 13
    .line 14
    and-int v4, v2, v3

    .line 15
    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    sub-int/2addr v2, v3

    .line 19
    iput v2, v1, Lya0;->j:I

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance v1, Lya0;

    .line 23
    .line 24
    invoke-direct {v1, p0, p2}, Lya0;-><init>(Lr3;Ldc3;)V

    .line 25
    .line 26
    .line 27
    :goto_0
    iget-object p2, v1, Lya0;->h:Ljava/lang/Object;

    .line 28
    .line 29
    sget-object v2, Lhd3;->a:Lhd3;

    .line 30
    .line 31
    iget v3, v1, Lya0;->j:I

    .line 32
    .line 33
    const/4 v4, 0x2

    .line 34
    const/4 v5, 0x1

    .line 35
    const/4 v6, 0x0

    .line 36
    if-eqz v3, :cond_3

    .line 37
    .line 38
    if-eq v3, v5, :cond_2

    .line 39
    .line 40
    if-ne v3, v4, :cond_1

    .line 41
    .line 42
    iget-object p0, v1, Lya0;->e:Lep7;

    .line 43
    .line 44
    :try_start_0
    invoke-static {p2}, Lu07;->z(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 45
    .line 46
    .line 47
    goto :goto_3

    .line 48
    :catchall_0
    move-exception p1

    .line 49
    goto :goto_4

    .line 50
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 51
    .line 52
    invoke-static {p0}, Lrs0;->g(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return-object v6

    .line 56
    :cond_2
    iget p0, v1, Lya0;->g:I

    .line 57
    .line 58
    iget-object p1, v1, Lya0;->f:Ljb0;

    .line 59
    .line 60
    iget-object v3, v1, Lya0;->e:Lep7;

    .line 61
    .line 62
    iget-object v5, v1, Lya0;->d:Ljava/lang/Integer;

    .line 63
    .line 64
    invoke-static {p2}, Lu07;->z(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    move-object v8, v3

    .line 68
    move v3, p0

    .line 69
    move-object p0, v8

    .line 70
    goto :goto_1

    .line 71
    :cond_3
    invoke-static {p2}, Lu07;->z(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    if-eqz p1, :cond_6

    .line 75
    .line 76
    iget-object p2, p0, Lr3;->b:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast p2, Ljb0;

    .line 79
    .line 80
    iget-object p2, p2, Ljb0;->c:Lps6;

    .line 81
    .line 82
    new-instance v3, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    const-string v7, "focus change: "

    .line 85
    .line 86
    invoke-direct {v3, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    invoke-virtual {p2, v3}, Lps6;->b(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    iget-object p0, p0, Lr3;->b:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast p0, Ljb0;

    .line 102
    .line 103
    iget-object p2, p0, Ljb0;->i:Lep7;

    .line 104
    .line 105
    iput-object p1, v1, Lya0;->d:Ljava/lang/Integer;

    .line 106
    .line 107
    iput-object p2, v1, Lya0;->e:Lep7;

    .line 108
    .line 109
    iput-object p0, v1, Lya0;->f:Ljb0;

    .line 110
    .line 111
    const/4 v3, 0x0

    .line 112
    iput v3, v1, Lya0;->g:I

    .line 113
    .line 114
    iput v5, v1, Lya0;->j:I

    .line 115
    .line 116
    invoke-virtual {p2, v1}, Lep7;->e(Ldc3;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v5

    .line 120
    if-ne v5, v2, :cond_4

    .line 121
    .line 122
    goto :goto_2

    .line 123
    :cond_4
    move-object v5, p1

    .line 124
    move-object p1, p0

    .line 125
    move-object p0, p2

    .line 126
    :goto_1
    :try_start_1
    iget-object p2, p1, Ljb0;->j:Lu90;

    .line 127
    .line 128
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 129
    .line 130
    .line 131
    move-result v5

    .line 132
    iget-object p1, p1, Ljb0;->k:Lv6c;

    .line 133
    .line 134
    iput-object v6, v1, Lya0;->d:Ljava/lang/Integer;

    .line 135
    .line 136
    iput-object p0, v1, Lya0;->e:Lep7;

    .line 137
    .line 138
    iput-object v6, v1, Lya0;->f:Ljb0;

    .line 139
    .line 140
    iput v3, v1, Lya0;->g:I

    .line 141
    .line 142
    iput v4, v1, Lya0;->j:I

    .line 143
    .line 144
    invoke-interface {p2, v5, p1, v1}, Lu90;->j(ILv6c;Ldc3;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 148
    if-ne p1, v2, :cond_5

    .line 149
    .line 150
    :goto_2
    return-object v2

    .line 151
    :cond_5
    :goto_3
    invoke-virtual {p0, v6}, Lep7;->g(Ljava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    return-object v0

    .line 155
    :goto_4
    invoke-virtual {p0, v6}, Lep7;->g(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    throw p1

    .line 159
    :cond_6
    return-object v0
.end method
