# DeepSeek 2.7.3 vs 2.7.5 static comparison

| Metric | 2.7.3 | 2.7.5 |
|---|---:|---:|
| APK bytes | 14211169 | 22210268 |
| SHA-256 | a6d025c14c98118a5a67849e04aaef6f3c9c13aaf0fa62caaee0e47091374ea3 | ddc52ef868b991fd33e634de834a3e2c022b0cd7ff9e854f4f141996aaeadb70 |
| DEX count | 3 | 3 |
| JADX exit | 3 | 3 |
| Java files | 12319 | 13940 |
| Smali files | 13311 | 15364 |
| Native libs | 11 | 16 |

## Marker match counts

| Marker | 2.7.3 | 2.7.5 |
|---|---:|---:|
| /api/v0/chat/completion | 6 | 10 |
| /api/v0/chat/regenerate | 2 | 6 |
| /api/v0/chat/continue | 2 | 6 |
| /api/v0/chat/edit_message | 2 | 6 |
| /api/v0/chat/resume_stream | 2 | 2 |
| /api/v0/chat/create_pow_challenge | 2 | 2 |
| /api/v0/chat/stop_stream | 2 | 2 |
| /api/v0/chat/history_messages | 4 | 4 |
| X-DS-PoW-Response | 5 | 8 |
| X-DS-Challenge-Response | 0 | 2 |
| nativeCalculateDeepSeekHashV1Pow | 6 | 6 |
| PowCalculator | 31 | 31 |
| ChatCompletionReadyEventData | 2 | 2 |
| DeltaCommand | 2 | 2 |
| ToolOpenFragment | 30 | 30 |
| ToolFindFragment | 19 | 24 |
| SearchFragment | 40 | 40 |
| allow_parallel_streams | 27 | 27 |
| interrupt_and_send_enabled | 27 | 27 |
| sse_first_delta | 2 | 3 |
| sse_auto_resume | 4 | 5 |
| text/event-stream | 0 | 0 |
| readUTF8Line | 0 | 0 |
| update_session | 2 | 4 |
| update_parent_message | 2 | 2 |
| check_client_update | 3 | 4 |
| auto_tts_capability | 2 | 2 |
| x-ds-sse-heartbeat-timeout-secs | 3 | 3 |

## Native library deltas

- Only 2.7.3: none
- Only 2.7.5: lib/arm64-v8a/libimage_processing_util_jni.so, lib/arm64-v8a/libliteavsdk.so, lib/arm64-v8a/libsurface_util_jni.so, lib/arm64-v8a/libtxffmpeg.so, lib/arm64-v8a/libtxsoundtouch.so
- Changed at same path: lib/arm64-v8a/libEncryptorP.so, lib/arm64-v8a/libapminsighta.so, lib/arm64-v8a/libapminsightb.so, lib/arm64-v8a/libsmsdk.so

## Interpretation limits

- Match counts are static reconnaissance, not runtime counts.
- No string match does not prove feature absence.
- Class mapping requires descriptor, inheritance, call-site and behavior evidence.
- This audit does not prove device Hook compatibility.
