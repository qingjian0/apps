.class public final La11;
.super Ljava/lang/Object;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lb11;


# instance fields
.field public final a:Lgw8;


# direct methods
.method public constructor <init>(Lgw8;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La11;->a:Lgw8;

    .line 5
    .line 6
    return-void
.end method
