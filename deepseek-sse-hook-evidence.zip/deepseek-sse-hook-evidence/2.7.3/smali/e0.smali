.class public final Le0;
.super Le09;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lwv3;


# instance fields
.field public final synthetic e:I

.field public f:J

.field public g:I

.field public h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IJLhf2;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 17
    iput p1, p0, Le0;->e:I

    iput-object p5, p0, Le0;->i:Ljava/lang/Object;

    iput-wide p2, p0, Le0;->f:J

    iput-object p6, p0, Le0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(JLyj9;Ljava/lang/String;Ljava/lang/String;Lhf2;)V
    .locals 1

    .line 1
    const/4 v0, 0x7

    .line 2
    iput v0, p0, Le0;->e:I

    .line 3
    .line 4
    iput-wide p1, p0, Le0;->f:J

    .line 5
    .line 6
    iput-object p3, p0, Le0;->h:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p4, p0, Le0;->i:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p5, p0, Le0;->j:Ljava/lang/Object;

    .line 11
    .line 12
    const/4 p1, 0x2

    .line 13
    invoke-direct {p0, p1, p6}, Le09;-><init>(ILhf2;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Lb69;JLg69;La69;Lhf2;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, Le0;->e:I

    .line 21
    iput-object p1, p0, Le0;->h:Ljava/lang/Object;

    iput-wide p2, p0, Le0;->f:J

    iput-object p4, p0, Le0;->i:Ljava/lang/Object;

    iput-object p5, p0, Le0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lli3;Ljava/lang/String;Lhf2;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Le0;->e:I

    .line 18
    iput-object p1, p0, Le0;->i:Ljava/lang/Object;

    iput-object p2, p0, Le0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lmc5;Lpg3;JLhf2;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Le0;->e:I

    .line 19
    iput-object p1, p0, Le0;->i:Ljava/lang/Object;

    iput-object p2, p0, Le0;->j:Ljava/lang/Object;

    iput-wide p3, p0, Le0;->f:J

    invoke-direct {p0, v0, p5}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lw37;Ljava/lang/CharSequence;JLe89;Lhf2;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, Le0;->e:I

    .line 20
    iput-object p1, p0, Le0;->h:Ljava/lang/Object;

    iput-object p2, p0, Le0;->i:Ljava/lang/Object;

    iput-wide p3, p0, Le0;->f:J

    iput-object p5, p0, Le0;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Le09;-><init>(ILhf2;)V

    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v4, p0

    .line 2
    .line 3
    iget v0, v4, Le0;->e:I

    .line 4
    .line 5
    const/4 v1, 0x3

    .line 6
    const/4 v7, 0x0

    .line 7
    const/4 v2, 0x2

    .line 8
    iget-object v3, v4, Le0;->j:Ljava/lang/Object;

    .line 9
    .line 10
    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    .line 11
    .line 12
    sget-object v8, Ljg2;->a:Ljg2;

    .line 13
    .line 14
    const/4 v6, 0x1

    .line 15
    sget-object v9, Llp9;->a:Llp9;

    .line 16
    .line 17
    iget-object v10, v4, Le0;->i:Ljava/lang/Object;

    .line 18
    .line 19
    const/4 v11, 0x0

    .line 20
    packed-switch v0, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    check-cast v10, Ljava/lang/String;

    .line 24
    .line 25
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 26
    .line 27
    move-object v1, v0

    .line 28
    check-cast v1, Lyj9;

    .line 29
    .line 30
    iget-object v2, v1, Lyj9;->c:Lcl5;

    .line 31
    .line 32
    iget v0, v4, Le0;->g:I

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    if-ne v0, v6, :cond_0

    .line 37
    .line 38
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    move-object/from16 v0, p1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    move-object v8, v11

    .line 48
    goto/16 :goto_2

    .line 49
    .line 50
    :cond_1
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    sget-object v0, Li43;->b:Lmj0;

    .line 54
    .line 55
    const-wide/16 v12, 0x7d0

    .line 56
    .line 57
    sget-object v0, Lm43;->d:Lm43;

    .line 58
    .line 59
    invoke-static {v12, v13, v0}, Ldm0;->I0(JLm43;)J

    .line 60
    .line 61
    .line 62
    move-result-wide v12

    .line 63
    new-instance v0, Lle8;

    .line 64
    .line 65
    check-cast v3, Ljava/lang/String;

    .line 66
    .line 67
    const/16 v5, 0x18

    .line 68
    .line 69
    invoke-direct {v0, v1, v3, v11, v5}, Lle8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 70
    .line 71
    .line 72
    iput v6, v4, Le0;->g:I

    .line 73
    .line 74
    invoke-static {v12, v13}, Luia;->V(J)J

    .line 75
    .line 76
    .line 77
    move-result-wide v11

    .line 78
    invoke-static {v11, v12, v0, v4}, Lp75;->Q(JLwv3;Lif2;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    if-ne v0, v8, :cond_2

    .line 83
    .line 84
    goto/16 :goto_2

    .line 85
    .line 86
    :cond_2
    :goto_0
    check-cast v0, Ljava/io/File;

    .line 87
    .line 88
    iget-wide v3, v4, Le0;->f:J

    .line 89
    .line 90
    iget-wide v7, v1, Lyj9;->g:J

    .line 91
    .line 92
    cmp-long v5, v3, v7

    .line 93
    .line 94
    if-eqz v5, :cond_3

    .line 95
    .line 96
    :goto_1
    move-object v8, v9

    .line 97
    goto :goto_2

    .line 98
    :cond_3
    if-nez v0, :cond_4

    .line 99
    .line 100
    new-instance v0, Ljava/lang/StringBuilder;

    .line 101
    .line 102
    const-string v3, "play: obtain audio timed out or failed, voice="

    .line 103
    .line 104
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-virtual {v2, v0}, Lcl5;->e(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    new-instance v0, Ltj9;

    .line 118
    .line 119
    invoke-direct {v0, v10}, Ltj9;-><init>(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v1, v0}, Lyj9;->b(Lxj9;)V

    .line 123
    .line 124
    .line 125
    goto :goto_1

    .line 126
    :cond_4
    new-instance v5, Landroid/media/MediaPlayer;

    .line 127
    .line 128
    invoke-direct {v5}, Landroid/media/MediaPlayer;-><init>()V

    .line 129
    .line 130
    .line 131
    iput-object v5, v1, Lyj9;->h:Landroid/media/MediaPlayer;

    .line 132
    .line 133
    :try_start_0
    new-instance v7, Landroid/media/AudioAttributes$Builder;

    .line 134
    .line 135
    invoke-direct {v7}, Landroid/media/AudioAttributes$Builder;-><init>()V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v7, v6}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    .line 139
    .line 140
    .line 141
    move-result-object v7

    .line 142
    invoke-virtual {v7, v6}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    .line 143
    .line 144
    .line 145
    move-result-object v6

    .line 146
    invoke-virtual {v6}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    invoke-virtual {v5, v6}, Landroid/media/MediaPlayer;->setAudioAttributes(Landroid/media/AudioAttributes;)V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-virtual {v5, v0}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    new-instance v0, Lqj9;

    .line 161
    .line 162
    invoke-direct {v0, v3, v4, v1, v10}, Lqj9;-><init>(JLyj9;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v5, v0}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 166
    .line 167
    .line 168
    new-instance v0, Lrj9;

    .line 169
    .line 170
    invoke-direct {v0, v3, v4, v1}, Lrj9;-><init>(JLyj9;)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v5, v0}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 174
    .line 175
    .line 176
    new-instance v0, Lsj9;

    .line 177
    .line 178
    invoke-direct {v0, v3, v4, v1, v10}, Lsj9;-><init>(JLyj9;Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v5, v0}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v5}, Landroid/media/MediaPlayer;->prepareAsync()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 185
    .line 186
    .line 187
    goto :goto_1

    .line 188
    :catch_0
    move-exception v0

    .line 189
    new-instance v3, Ljava/lang/StringBuilder;

    .line 190
    .line 191
    const-string v4, "play: prepare failed, voice="

    .line 192
    .line 193
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v3

    .line 203
    invoke-virtual {v2, v3, v0}, Lcl5;->f(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 204
    .line 205
    .line 206
    new-instance v0, Ltj9;

    .line 207
    .line 208
    invoke-direct {v0, v10}, Ltj9;-><init>(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v1, v0}, Lyj9;->b(Lxj9;)V

    .line 212
    .line 213
    .line 214
    goto :goto_1

    .line 215
    :goto_2
    return-object v8

    .line 216
    :pswitch_0
    check-cast v3, Lca6;

    .line 217
    .line 218
    check-cast v10, Le89;

    .line 219
    .line 220
    iget v0, v4, Le0;->g:I

    .line 221
    .line 222
    if-eqz v0, :cond_7

    .line 223
    .line 224
    if-eq v0, v6, :cond_6

    .line 225
    .line 226
    if-ne v0, v2, :cond_5

    .line 227
    .line 228
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v0, Lk87;

    .line 231
    .line 232
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 233
    .line 234
    .line 235
    goto :goto_4

    .line 236
    :cond_5
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    move-object v8, v11

    .line 240
    goto :goto_5

    .line 241
    :cond_6
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v0, Le89;

    .line 244
    .line 245
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    goto :goto_3

    .line 249
    :cond_7
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    iget-object v0, v10, Le89;->w:Lk87;

    .line 253
    .line 254
    if-eqz v0, :cond_9

    .line 255
    .line 256
    new-instance v1, Lj87;

    .line 257
    .line 258
    invoke-direct {v1, v0}, Lj87;-><init>(Lk87;)V

    .line 259
    .line 260
    .line 261
    iput-object v10, v4, Le0;->h:Ljava/lang/Object;

    .line 262
    .line 263
    iput v6, v4, Le0;->g:I

    .line 264
    .line 265
    invoke-interface {v3, v1, v4}, Lca6;->b(Lwo4;Lhf2;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    if-ne v0, v8, :cond_8

    .line 270
    .line 271
    goto :goto_5

    .line 272
    :cond_8
    move-object v0, v10

    .line 273
    :goto_3
    iput-object v11, v0, Le89;->w:Lk87;

    .line 274
    .line 275
    :cond_9
    new-instance v0, Lk87;

    .line 276
    .line 277
    iget-wide v5, v4, Le0;->f:J

    .line 278
    .line 279
    invoke-direct {v0, v5, v6}, Lk87;-><init>(J)V

    .line 280
    .line 281
    .line 282
    iput-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 283
    .line 284
    iput v2, v4, Le0;->g:I

    .line 285
    .line 286
    invoke-interface {v3, v0, v4}, Lca6;->b(Lwo4;Lhf2;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v1

    .line 290
    if-ne v1, v8, :cond_a

    .line 291
    .line 292
    goto :goto_5

    .line 293
    :cond_a
    :goto_4
    iput-object v0, v10, Le89;->w:Lk87;

    .line 294
    .line 295
    move-object v8, v9

    .line 296
    :goto_5
    return-object v8

    .line 297
    :pswitch_1
    move-object/from16 v17, v10

    .line 298
    .line 299
    check-cast v17, Ljava/lang/CharSequence;

    .line 300
    .line 301
    check-cast v3, Le89;

    .line 302
    .line 303
    iget-object v0, v3, Le89;->a:Luf9;

    .line 304
    .line 305
    iget v1, v4, Le0;->g:I

    .line 306
    .line 307
    if-eqz v1, :cond_c

    .line 308
    .line 309
    if-ne v1, v6, :cond_b

    .line 310
    .line 311
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 312
    .line 313
    .line 314
    move-object/from16 v1, p1

    .line 315
    .line 316
    move-object/from16 v10, v17

    .line 317
    .line 318
    goto :goto_8

    .line 319
    :cond_b
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 320
    .line 321
    .line 322
    move-object v8, v11

    .line 323
    goto/16 :goto_9

    .line 324
    .line 325
    :cond_c
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    iget-object v1, v4, Le0;->h:Ljava/lang/Object;

    .line 329
    .line 330
    check-cast v1, Lw37;

    .line 331
    .line 332
    iget-wide v13, v4, Le0;->f:J

    .line 333
    .line 334
    iput v6, v4, Le0;->g:I

    .line 335
    .line 336
    move-object/from16 v16, v1

    .line 337
    .line 338
    check-cast v16, Lb47;

    .line 339
    .line 340
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 341
    .line 342
    .line 343
    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    .line 344
    .line 345
    .line 346
    move-result v1

    .line 347
    if-nez v1, :cond_d

    .line 348
    .line 349
    goto :goto_6

    .line 350
    :cond_d
    invoke-static {v13, v14}, Lo99;->b(J)Z

    .line 351
    .line 352
    .line 353
    move-result v1

    .line 354
    if-eqz v1, :cond_e

    .line 355
    .line 356
    :goto_6
    move-object v1, v11

    .line 357
    move-object/from16 v10, v17

    .line 358
    .line 359
    goto :goto_7

    .line 360
    :cond_e
    new-instance v12, La47;

    .line 361
    .line 362
    const/4 v15, 0x0

    .line 363
    invoke-direct/range {v12 .. v17}, La47;-><init>(JLhf2;Lb47;Ljava/lang/CharSequence;)V

    .line 364
    .line 365
    .line 366
    move-object/from16 v1, v16

    .line 367
    .line 368
    move-object/from16 v10, v17

    .line 369
    .line 370
    iget-object v2, v1, Lb47;->a:Lag2;

    .line 371
    .line 372
    new-instance v3, Lz37;

    .line 373
    .line 374
    invoke-direct {v3, v1, v12, v11}, Lz37;-><init>(Lb47;Lwv3;Lhf2;)V

    .line 375
    .line 376
    .line 377
    invoke-static {v2, v3, v4}, Lv9a;->f0(Lag2;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    :goto_7
    if-ne v1, v8, :cond_f

    .line 382
    .line 383
    goto :goto_9

    .line 384
    :cond_f
    :goto_8
    check-cast v1, Lo99;

    .line 385
    .line 386
    if-eqz v1, :cond_10

    .line 387
    .line 388
    iget-wide v1, v1, Lo99;->a:J

    .line 389
    .line 390
    invoke-virtual {v0}, Luf9;->d()Lq69;

    .line 391
    .line 392
    .line 393
    move-result-object v3

    .line 394
    iget-object v3, v3, Lq69;->c:Ljava/lang/CharSequence;

    .line 395
    .line 396
    invoke-static {v3, v10}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 397
    .line 398
    .line 399
    move-result v3

    .line 400
    if-eqz v3, :cond_10

    .line 401
    .line 402
    invoke-virtual {v0}, Luf9;->d()Lq69;

    .line 403
    .line 404
    .line 405
    move-result-object v3

    .line 406
    iget-wide v5, v3, Lq69;->d:J

    .line 407
    .line 408
    iget-wide v3, v4, Le0;->f:J

    .line 409
    .line 410
    invoke-static {v5, v6, v3, v4}, Lo99;->a(JJ)Z

    .line 411
    .line 412
    .line 413
    move-result v3

    .line 414
    if-eqz v3, :cond_10

    .line 415
    .line 416
    invoke-virtual {v0}, Luf9;->d()Lq69;

    .line 417
    .line 418
    .line 419
    move-result-object v3

    .line 420
    iget-wide v3, v3, Lq69;->d:J

    .line 421
    .line 422
    invoke-static {v1, v2, v3, v4}, Lo99;->a(JJ)Z

    .line 423
    .line 424
    .line 425
    move-result v3

    .line 426
    if-nez v3, :cond_10

    .line 427
    .line 428
    invoke-virtual {v0, v1, v2}, Luf9;->j(J)V

    .line 429
    .line 430
    .line 431
    :cond_10
    move-object v8, v9

    .line 432
    :goto_9
    return-object v8

    .line 433
    :pswitch_2
    iget v0, v4, Le0;->g:I

    .line 434
    .line 435
    if-eqz v0, :cond_13

    .line 436
    .line 437
    if-eq v0, v6, :cond_12

    .line 438
    .line 439
    if-ne v0, v2, :cond_11

    .line 440
    .line 441
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 442
    .line 443
    .line 444
    goto :goto_b

    .line 445
    :cond_11
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 446
    .line 447
    .line 448
    move-object v8, v11

    .line 449
    goto :goto_c

    .line 450
    :cond_12
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 451
    .line 452
    .line 453
    goto :goto_a

    .line 454
    :cond_13
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 455
    .line 456
    .line 457
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v0, Lb69;

    .line 460
    .line 461
    iget-object v0, v0, Lb69;->q:Lwv3;

    .line 462
    .line 463
    if-eqz v0, :cond_14

    .line 464
    .line 465
    iget-wide v11, v4, Le0;->f:J

    .line 466
    .line 467
    new-instance v1, Lyl6;

    .line 468
    .line 469
    invoke-direct {v1, v11, v12}, Lyl6;-><init>(J)V

    .line 470
    .line 471
    .line 472
    iput v6, v4, Le0;->g:I

    .line 473
    .line 474
    invoke-interface {v0, v1, v4}, Lwv3;->q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    move-result-object v0

    .line 478
    if-ne v0, v8, :cond_14

    .line 479
    .line 480
    goto :goto_c

    .line 481
    :cond_14
    :goto_a
    check-cast v10, Lg69;

    .line 482
    .line 483
    check-cast v3, La69;

    .line 484
    .line 485
    iput v2, v4, Le0;->g:I

    .line 486
    .line 487
    invoke-interface {v10, v3, v4}, Lg69;->a(Lx59;Le09;)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    if-ne v0, v8, :cond_15

    .line 492
    .line 493
    goto :goto_c

    .line 494
    :cond_15
    :goto_b
    move-object v8, v9

    .line 495
    :goto_c
    return-object v8

    .line 496
    :pswitch_3
    check-cast v10, La28;

    .line 497
    .line 498
    iget v0, v4, Le0;->g:I

    .line 499
    .line 500
    if-eqz v0, :cond_17

    .line 501
    .line 502
    if-ne v0, v6, :cond_16

    .line 503
    .line 504
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 505
    .line 506
    .line 507
    goto :goto_d

    .line 508
    :cond_16
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 509
    .line 510
    .line 511
    move-object v8, v11

    .line 512
    goto :goto_e

    .line 513
    :cond_17
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 514
    .line 515
    .line 516
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 517
    .line 518
    check-cast v0, Ly18;

    .line 519
    .line 520
    iget-wide v1, v4, Le0;->f:J

    .line 521
    .line 522
    invoke-virtual {v10, v1, v2}, La28;->g(J)F

    .line 523
    .line 524
    .line 525
    move-result v1

    .line 526
    check-cast v3, Lhl7;

    .line 527
    .line 528
    new-instance v2, Lzf5;

    .line 529
    .line 530
    const/16 v5, 0xb

    .line 531
    .line 532
    invoke-direct {v2, v3, v10, v0, v5}, Lzf5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 533
    .line 534
    .line 535
    iput v6, v4, Le0;->g:I

    .line 536
    .line 537
    const/4 v0, 0x0

    .line 538
    move-object v3, v2

    .line 539
    const/4 v2, 0x0

    .line 540
    const/16 v5, 0xc

    .line 541
    .line 542
    invoke-static/range {v0 .. v5}, Lge5;->k(FFLsl;Lwv3;Le09;I)Ljava/lang/Object;

    .line 543
    .line 544
    .line 545
    move-result-object v0

    .line 546
    if-ne v0, v8, :cond_18

    .line 547
    .line 548
    goto :goto_e

    .line 549
    :cond_18
    :goto_d
    move-object v8, v9

    .line 550
    :goto_e
    return-object v8

    .line 551
    :pswitch_4
    iget-wide v0, v4, Le0;->f:J

    .line 552
    .line 553
    check-cast v10, Lmc5;

    .line 554
    .line 555
    iget-object v12, v10, Lmc5;->o:Lui;

    .line 556
    .line 557
    iget v13, v4, Le0;->g:I

    .line 558
    .line 559
    if-eqz v13, :cond_1b

    .line 560
    .line 561
    if-eq v13, v6, :cond_1a

    .line 562
    .line 563
    if-ne v13, v2, :cond_19

    .line 564
    .line 565
    :try_start_1
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_1

    .line 566
    .line 567
    .line 568
    goto/16 :goto_11

    .line 569
    .line 570
    :cond_19
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 571
    .line 572
    .line 573
    move-object v8, v11

    .line 574
    goto/16 :goto_12

    .line 575
    .line 576
    :cond_1a
    iget-object v3, v4, Le0;->h:Ljava/lang/Object;

    .line 577
    .line 578
    check-cast v3, Lpg3;

    .line 579
    .line 580
    :try_start_2
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_1

    .line 581
    .line 582
    .line 583
    goto :goto_10

    .line 584
    :cond_1b
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 585
    .line 586
    .line 587
    :try_start_3
    invoke-virtual {v12}, Lui;->e()Z

    .line 588
    .line 589
    .line 590
    move-result v5
    :try_end_3
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3 .. :try_end_3} :catch_1

    .line 591
    check-cast v3, Lpg3;

    .line 592
    .line 593
    if-eqz v5, :cond_1d

    .line 594
    .line 595
    :try_start_4
    instance-of v5, v3, Lcr8;

    .line 596
    .line 597
    if-eqz v5, :cond_1c

    .line 598
    .line 599
    check-cast v3, Lcr8;

    .line 600
    .line 601
    goto :goto_f

    .line 602
    :cond_1c
    sget-object v3, Lnc5;->a:Lcr8;

    .line 603
    .line 604
    :cond_1d
    :goto_f
    invoke-virtual {v12}, Lui;->e()Z

    .line 605
    .line 606
    .line 607
    move-result v5

    .line 608
    if-nez v5, :cond_1f

    .line 609
    .line 610
    new-instance v5, Lgo4;

    .line 611
    .line 612
    invoke-direct {v5, v0, v1}, Lgo4;-><init>(J)V

    .line 613
    .line 614
    .line 615
    iput-object v3, v4, Le0;->h:Ljava/lang/Object;

    .line 616
    .line 617
    iput v6, v4, Le0;->g:I

    .line 618
    .line 619
    invoke-virtual {v12, v4, v5}, Lui;->f(Lhf2;Ljava/lang/Object;)Ljava/lang/Object;

    .line 620
    .line 621
    .line 622
    move-result-object v5

    .line 623
    if-ne v5, v8, :cond_1e

    .line 624
    .line 625
    goto :goto_12

    .line 626
    :cond_1e
    :goto_10
    iget-object v5, v10, Lmc5;->c:Lkt1;

    .line 627
    .line 628
    invoke-virtual {v5}, Lkt1;->v()Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    :cond_1f
    invoke-virtual {v12}, Lui;->d()Ljava/lang/Object;

    .line 632
    .line 633
    .line 634
    move-result-object v5

    .line 635
    check-cast v5, Lgo4;

    .line 636
    .line 637
    iget-wide v5, v5, Lgo4;->a:J

    .line 638
    .line 639
    invoke-static {v5, v6, v0, v1}, Lgo4;->c(JJ)J

    .line 640
    .line 641
    .line 642
    move-result-wide v0

    .line 643
    iget-object v5, v10, Lmc5;->o:Lui;

    .line 644
    .line 645
    new-instance v6, Lgo4;

    .line 646
    .line 647
    invoke-direct {v6, v0, v1}, Lgo4;-><init>(J)V

    .line 648
    .line 649
    .line 650
    new-instance v12, Lo40;

    .line 651
    .line 652
    invoke-direct {v12, v2, v0, v1, v10}, Lo40;-><init>(IJLjava/lang/Object;)V

    .line 653
    .line 654
    .line 655
    iput-object v11, v4, Le0;->h:Ljava/lang/Object;

    .line 656
    .line 657
    iput v2, v4, Le0;->g:I

    .line 658
    .line 659
    move-object v2, v3

    .line 660
    const/4 v3, 0x0

    .line 661
    move-object v1, v6

    .line 662
    const/4 v6, 0x4

    .line 663
    move-object v0, v5

    .line 664
    move-object v5, v4

    .line 665
    move-object v4, v12

    .line 666
    invoke-static/range {v0 .. v6}, Lui;->b(Lui;Ljava/lang/Object;Lsl;Ljava/lang/Float;Lsv3;Lhf2;I)Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v0

    .line 670
    if-ne v0, v8, :cond_20

    .line 671
    .line 672
    goto :goto_12

    .line 673
    :cond_20
    :goto_11
    invoke-virtual {v10, v7}, Lmc5;->f(Z)V

    .line 674
    .line 675
    .line 676
    iput-boolean v7, v10, Lmc5;->g:Z
    :try_end_4
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4 .. :try_end_4} :catch_1

    .line 677
    .line 678
    :catch_1
    move-object v8, v9

    .line 679
    :goto_12
    return-object v8

    .line 680
    :pswitch_5
    check-cast v10, Lli3;

    .line 681
    .line 682
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 683
    .line 684
    move-object v13, v0

    .line 685
    check-cast v13, Lec4;

    .line 686
    .line 687
    iget v0, v4, Le0;->g:I

    .line 688
    .line 689
    const/4 v12, 0x5

    .line 690
    const/4 v14, 0x4

    .line 691
    const/16 v16, 0x0

    .line 692
    .line 693
    if-eqz v0, :cond_27

    .line 694
    .line 695
    if-eq v0, v6, :cond_25

    .line 696
    .line 697
    if-eq v0, v2, :cond_24

    .line 698
    .line 699
    if-eq v0, v1, :cond_23

    .line 700
    .line 701
    if-eq v0, v14, :cond_22

    .line 702
    .line 703
    if-ne v0, v12, :cond_21

    .line 704
    .line 705
    goto :goto_13

    .line 706
    :cond_21
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 707
    .line 708
    .line 709
    move-object v8, v11

    .line 710
    goto/16 :goto_1b

    .line 711
    .line 712
    :cond_22
    iget-wide v0, v4, Le0;->f:J

    .line 713
    .line 714
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 715
    .line 716
    .line 717
    move-object/from16 v2, p1

    .line 718
    .line 719
    move v6, v12

    .line 720
    move-object/from16 v11, v16

    .line 721
    .line 722
    goto/16 :goto_19

    .line 723
    .line 724
    :cond_23
    iget-wide v0, v4, Le0;->f:J

    .line 725
    .line 726
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 727
    .line 728
    .line 729
    move v6, v12

    .line 730
    move-object/from16 v11, v16

    .line 731
    .line 732
    goto/16 :goto_18

    .line 733
    .line 734
    :cond_24
    :goto_13
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 735
    .line 736
    .line 737
    goto/16 :goto_1a

    .line 738
    .line 739
    :cond_25
    iget-wide v0, v4, Le0;->f:J

    .line 740
    .line 741
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 742
    .line 743
    .line 744
    move-wide v14, v0

    .line 745
    :cond_26
    move v0, v12

    .line 746
    goto :goto_17

    .line 747
    :cond_27
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 748
    .line 749
    .line 750
    invoke-static {v13}, Loy4;->B(Lhb4;)Lge2;

    .line 751
    .line 752
    .line 753
    move-result-object v0

    .line 754
    invoke-static {v13}, Lfh6;->G(Lec4;)Ljava/lang/String;

    .line 755
    .line 756
    .line 757
    move-result-object v5

    .line 758
    invoke-static {v13}, Lfh6;->B(Lec4;)Ljava/lang/String;

    .line 759
    .line 760
    .line 761
    invoke-static {v13}, Lfh6;->C(Lec4;)Ljava/lang/String;

    .line 762
    .line 763
    .line 764
    invoke-interface {v13}, Lhb4;->a()Ln54;

    .line 765
    .line 766
    .line 767
    move-result-object v11

    .line 768
    const-string v15, "x-ds-sse-heartbeat-timeout-secs"

    .line 769
    .line 770
    invoke-interface {v11, v15}, Lix8;->s(Ljava/lang/String;)Ljava/lang/String;

    .line 771
    .line 772
    .line 773
    move-result-object v11

    .line 774
    if-eqz v11, :cond_28

    .line 775
    .line 776
    const/16 v15, 0xa

    .line 777
    .line 778
    invoke-static {v15, v11}, Lsx8;->W(ILjava/lang/String;)Ljava/lang/Long;

    .line 779
    .line 780
    .line 781
    move-result-object v11

    .line 782
    if-eqz v11, :cond_28

    .line 783
    .line 784
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 785
    .line 786
    .line 787
    move-result-wide v17

    .line 788
    :goto_14
    move-wide/from16 v14, v17

    .line 789
    .line 790
    goto :goto_15

    .line 791
    :cond_28
    const-wide/16 v17, 0xa

    .line 792
    .line 793
    goto :goto_14

    .line 794
    :goto_15
    if-eqz v0, :cond_29

    .line 795
    .line 796
    invoke-virtual {v0}, Lge2;->E()Lge2;

    .line 797
    .line 798
    .line 799
    move-result-object v0

    .line 800
    goto :goto_16

    .line 801
    :cond_29
    move-object/from16 v0, v16

    .line 802
    .line 803
    :goto_16
    sget-object v11, Lfe2;->b:Lge2;

    .line 804
    .line 805
    invoke-static {v0, v11}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 806
    .line 807
    .line 808
    move-result v11

    .line 809
    if-eqz v11, :cond_2a

    .line 810
    .line 811
    new-instance v0, Ly01;

    .line 812
    .line 813
    invoke-direct {v0, v14, v15, v5, v6}, Ly01;-><init>(JLjava/lang/String;Z)V

    .line 814
    .line 815
    .line 816
    iput-object v13, v4, Le0;->h:Ljava/lang/Object;

    .line 817
    .line 818
    iput-wide v14, v4, Le0;->f:J

    .line 819
    .line 820
    iput v6, v4, Le0;->g:I

    .line 821
    .line 822
    invoke-interface {v10, v0, v4}, Lli3;->a(Ljava/lang/Object;Lhf2;)Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v0

    .line 826
    if-ne v0, v8, :cond_26

    .line 827
    .line 828
    goto/16 :goto_1b

    .line 829
    .line 830
    :goto_17
    new-instance v12, Ljz0;

    .line 831
    .line 832
    const/16 v17, 0x0

    .line 833
    .line 834
    move v6, v0

    .line 835
    invoke-direct/range {v12 .. v17}, Ljz0;-><init>(Lec4;JLhf2;I)V

    .line 836
    .line 837
    .line 838
    move-object/from16 v11, v16

    .line 839
    .line 840
    new-instance v0, Lz40;

    .line 841
    .line 842
    invoke-direct {v0, v6, v12}, Lz40;-><init>(ILjava/lang/Object;)V

    .line 843
    .line 844
    .line 845
    new-instance v1, Lg5;

    .line 846
    .line 847
    invoke-direct {v1, v10, v6}, Lg5;-><init>(Lli3;I)V

    .line 848
    .line 849
    .line 850
    iput-object v11, v4, Le0;->h:Ljava/lang/Object;

    .line 851
    .line 852
    iput-wide v14, v4, Le0;->f:J

    .line 853
    .line 854
    iput v2, v4, Le0;->g:I

    .line 855
    .line 856
    invoke-virtual {v0, v1, v4}, Lz40;->b(Lli3;Lhf2;)Ljava/lang/Object;

    .line 857
    .line 858
    .line 859
    move-result-object v0

    .line 860
    if-ne v0, v8, :cond_2d

    .line 861
    .line 862
    goto/16 :goto_1b

    .line 863
    .line 864
    :cond_2a
    move v6, v12

    .line 865
    move-object/from16 v11, v16

    .line 866
    .line 867
    sget-object v2, Lce2;->a:Lge2;

    .line 868
    .line 869
    invoke-static {v0, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 870
    .line 871
    .line 872
    move-result v0

    .line 873
    if-eqz v0, :cond_2d

    .line 874
    .line 875
    new-instance v0, Ly01;

    .line 876
    .line 877
    invoke-direct {v0, v14, v15, v5, v7}, Ly01;-><init>(JLjava/lang/String;Z)V

    .line 878
    .line 879
    .line 880
    iput-object v13, v4, Le0;->h:Ljava/lang/Object;

    .line 881
    .line 882
    iput-wide v14, v4, Le0;->f:J

    .line 883
    .line 884
    iput v1, v4, Le0;->g:I

    .line 885
    .line 886
    invoke-interface {v10, v0, v4}, Lli3;->a(Ljava/lang/Object;Lhf2;)Ljava/lang/Object;

    .line 887
    .line 888
    .line 889
    move-result-object v0

    .line 890
    if-ne v0, v8, :cond_2b

    .line 891
    .line 892
    goto/16 :goto_1b

    .line 893
    .line 894
    :cond_2b
    move-wide v0, v14

    .line 895
    :goto_18
    iput-object v13, v4, Le0;->h:Ljava/lang/Object;

    .line 896
    .line 897
    iput-wide v0, v4, Le0;->f:J

    .line 898
    .line 899
    const/4 v2, 0x4

    .line 900
    iput v2, v4, Le0;->g:I

    .line 901
    .line 902
    sget-object v2, Lfz0;->a:Ljava/nio/charset/Charset;

    .line 903
    .line 904
    invoke-static {v13, v2, v4}, Lgh6;->o(Lec4;Ljava/nio/charset/Charset;Lif2;)Ljava/lang/Object;

    .line 905
    .line 906
    .line 907
    move-result-object v2

    .line 908
    if-ne v2, v8, :cond_2c

    .line 909
    .line 910
    goto :goto_1b

    .line 911
    :cond_2c
    :goto_19
    check-cast v2, Ljava/lang/String;

    .line 912
    .line 913
    sget-object v5, Low4;->a:Lew4;

    .line 914
    .line 915
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 916
    .line 917
    .line 918
    sget-object v7, Lk88;->Companion:Lj88;

    .line 919
    .line 920
    sget-object v12, Lg98;->Companion:Lf98;

    .line 921
    .line 922
    sget-object v14, Ll01;->Companion:Lk01;

    .line 923
    .line 924
    invoke-virtual {v14}, Lk01;->serializer()Lv35;

    .line 925
    .line 926
    .line 927
    move-result-object v14

    .line 928
    invoke-virtual {v12, v14}, Lf98;->serializer(Lv35;)Lv35;

    .line 929
    .line 930
    .line 931
    move-result-object v12

    .line 932
    invoke-virtual {v7, v12}, Lj88;->serializer(Lv35;)Lv35;

    .line 933
    .line 934
    .line 935
    move-result-object v7

    .line 936
    check-cast v7, Lv35;

    .line 937
    .line 938
    invoke-virtual {v5, v7, v2}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 939
    .line 940
    .line 941
    move-result-object v5

    .line 942
    move-object/from16 v22, v5

    .line 943
    .line 944
    check-cast v22, Lk88;

    .line 945
    .line 946
    new-instance v14, La98;

    .line 947
    .line 948
    move-object v15, v3

    .line 949
    check-cast v15, Ljava/lang/String;

    .line 950
    .line 951
    invoke-virtual {v13}, Lec4;->K()Lpa4;

    .line 952
    .line 953
    .line 954
    move-result-object v3

    .line 955
    invoke-virtual {v3}, Lpa4;->c()Lxb4;

    .line 956
    .line 957
    .line 958
    move-result-object v3

    .line 959
    invoke-static {v3}, Lac4;->a(Lxb4;)Ljava/lang/String;

    .line 960
    .line 961
    .line 962
    move-result-object v16

    .line 963
    invoke-static {v13}, Lfh6;->G(Lec4;)Ljava/lang/String;

    .line 964
    .line 965
    .line 966
    move-result-object v17

    .line 967
    invoke-static {v13}, Lfh6;->B(Lec4;)Ljava/lang/String;

    .line 968
    .line 969
    .line 970
    move-result-object v18

    .line 971
    invoke-static {v13}, Lfh6;->C(Lec4;)Ljava/lang/String;

    .line 972
    .line 973
    .line 974
    move-result-object v19

    .line 975
    invoke-static {v13}, Lfh6;->E(Lec4;)Ljava/lang/String;

    .line 976
    .line 977
    .line 978
    move-result-object v20

    .line 979
    invoke-static {v13}, Lfh6;->F(Lec4;)Ljava/lang/Long;

    .line 980
    .line 981
    .line 982
    move-result-object v21

    .line 983
    const/16 v3, 0x200

    .line 984
    .line 985
    invoke-static {v3, v2}, Llx8;->F0(ILjava/lang/String;)Ljava/lang/String;

    .line 986
    .line 987
    .line 988
    move-result-object v24

    .line 989
    invoke-interface {v13}, Lhb4;->a()Ln54;

    .line 990
    .line 991
    .line 992
    move-result-object v25

    .line 993
    const/16 v23, 0x0

    .line 994
    .line 995
    invoke-direct/range {v14 .. v25}, La98;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Lk88;Lk88;Ljava/lang/String;Ln54;)V

    .line 996
    .line 997
    .line 998
    new-instance v2, Lz01;

    .line 999
    .line 1000
    invoke-direct {v2, v14}, Lz01;-><init>(La98;)V

    .line 1001
    .line 1002
    .line 1003
    iput-object v11, v4, Le0;->h:Ljava/lang/Object;

    .line 1004
    .line 1005
    iput-wide v0, v4, Le0;->f:J

    .line 1006
    .line 1007
    iput v6, v4, Le0;->g:I

    .line 1008
    .line 1009
    invoke-interface {v10, v2, v4}, Lli3;->a(Ljava/lang/Object;Lhf2;)Ljava/lang/Object;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v0

    .line 1013
    if-ne v0, v8, :cond_2d

    .line 1014
    .line 1015
    goto :goto_1b

    .line 1016
    :cond_2d
    :goto_1a
    move-object v8, v9

    .line 1017
    :goto_1b
    return-object v8

    .line 1018
    :pswitch_6
    check-cast v3, Lca6;

    .line 1019
    .line 1020
    iget v0, v4, Le0;->g:I

    .line 1021
    .line 1022
    if-eqz v0, :cond_31

    .line 1023
    .line 1024
    if-eq v0, v6, :cond_30

    .line 1025
    .line 1026
    if-eq v0, v2, :cond_2f

    .line 1027
    .line 1028
    if-ne v0, v1, :cond_2e

    .line 1029
    .line 1030
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 1031
    .line 1032
    .line 1033
    goto :goto_1e

    .line 1034
    :cond_2e
    invoke-static {v5}, Lpm0;->e(Ljava/lang/String;)V

    .line 1035
    .line 1036
    .line 1037
    move-object v8, v11

    .line 1038
    goto :goto_1f

    .line 1039
    :cond_2f
    iget-object v0, v4, Le0;->h:Ljava/lang/Object;

    .line 1040
    .line 1041
    check-cast v0, Ll87;

    .line 1042
    .line 1043
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 1044
    .line 1045
    .line 1046
    goto :goto_1d

    .line 1047
    :cond_30
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 1048
    .line 1049
    .line 1050
    goto :goto_1c

    .line 1051
    :cond_31
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 1052
    .line 1053
    .line 1054
    check-cast v10, Lht4;

    .line 1055
    .line 1056
    iput v6, v4, Le0;->g:I

    .line 1057
    .line 1058
    invoke-interface {v10, v4}, Lht4;->Y(Lif2;)Ljava/lang/Object;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v0

    .line 1062
    if-ne v0, v8, :cond_32

    .line 1063
    .line 1064
    goto :goto_1f

    .line 1065
    :cond_32
    :goto_1c
    new-instance v0, Lk87;

    .line 1066
    .line 1067
    iget-wide v5, v4, Le0;->f:J

    .line 1068
    .line 1069
    invoke-direct {v0, v5, v6}, Lk87;-><init>(J)V

    .line 1070
    .line 1071
    .line 1072
    new-instance v5, Ll87;

    .line 1073
    .line 1074
    invoke-direct {v5, v0}, Ll87;-><init>(Lk87;)V

    .line 1075
    .line 1076
    .line 1077
    iput-object v5, v4, Le0;->h:Ljava/lang/Object;

    .line 1078
    .line 1079
    iput v2, v4, Le0;->g:I

    .line 1080
    .line 1081
    invoke-interface {v3, v0, v4}, Lca6;->b(Lwo4;Lhf2;)Ljava/lang/Object;

    .line 1082
    .line 1083
    .line 1084
    move-result-object v0

    .line 1085
    if-ne v0, v8, :cond_33

    .line 1086
    .line 1087
    goto :goto_1f

    .line 1088
    :cond_33
    move-object v0, v5

    .line 1089
    :goto_1d
    iput-object v11, v4, Le0;->h:Ljava/lang/Object;

    .line 1090
    .line 1091
    iput v1, v4, Le0;->g:I

    .line 1092
    .line 1093
    invoke-interface {v3, v0, v4}, Lca6;->b(Lwo4;Lhf2;)Ljava/lang/Object;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v0

    .line 1097
    if-ne v0, v8, :cond_34

    .line 1098
    .line 1099
    goto :goto_1f

    .line 1100
    :cond_34
    :goto_1e
    move-object v8, v9

    .line 1101
    :goto_1f
    return-object v8

    .line 1102
    nop

    .line 1103
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Le0;->e:I

    .line 2
    .line 3
    sget-object v1, Llp9;->a:Llp9;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p1, Lig2;

    .line 9
    .line 10
    check-cast p2, Lhf2;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Le0;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lig2;

    .line 24
    .line 25
    check-cast p2, Lhf2;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Le0;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_1
    check-cast p1, Lig2;

    .line 39
    .line 40
    check-cast p2, Lhf2;

    .line 41
    .line 42
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Le0;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_2
    check-cast p1, Lig2;

    .line 54
    .line 55
    check-cast p2, Lhf2;

    .line 56
    .line 57
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 58
    .line 59
    .line 60
    move-result-object p0

    .line 61
    check-cast p0, Le0;

    .line 62
    .line 63
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_3
    check-cast p1, Ly18;

    .line 69
    .line 70
    check-cast p2, Lhf2;

    .line 71
    .line 72
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    check-cast p0, Le0;

    .line 77
    .line 78
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    return-object p0

    .line 83
    :pswitch_4
    check-cast p1, Lig2;

    .line 84
    .line 85
    check-cast p2, Lhf2;

    .line 86
    .line 87
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    check-cast p0, Le0;

    .line 92
    .line 93
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0

    .line 98
    :pswitch_5
    check-cast p1, Lec4;

    .line 99
    .line 100
    check-cast p2, Lhf2;

    .line 101
    .line 102
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    check-cast p0, Le0;

    .line 107
    .line 108
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p0

    .line 112
    return-object p0

    .line 113
    :pswitch_6
    check-cast p1, Lig2;

    .line 114
    .line 115
    check-cast p2, Lhf2;

    .line 116
    .line 117
    invoke-virtual {p0, p2, p1}, Le0;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    check-cast p0, Le0;

    .line 122
    .line 123
    invoke-virtual {p0, v1}, Le0;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    return-object p0

    .line 128
    nop

    .line 129
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final x(Lhf2;Ljava/lang/Object;)Lhf2;
    .locals 11

    .line 1
    iget v0, p0, Le0;->e:I

    .line 2
    .line 3
    iget-object v1, p0, Le0;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Le0;->i:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    new-instance v3, Le0;

    .line 11
    .line 12
    iget-wide v4, p0, Le0;->f:J

    .line 13
    .line 14
    iget-object p0, p0, Le0;->h:Ljava/lang/Object;

    .line 15
    .line 16
    move-object v6, p0

    .line 17
    check-cast v6, Lyj9;

    .line 18
    .line 19
    move-object v7, v2

    .line 20
    check-cast v7, Ljava/lang/String;

    .line 21
    .line 22
    move-object v8, v1

    .line 23
    check-cast v8, Ljava/lang/String;

    .line 24
    .line 25
    move-object v9, p1

    .line 26
    invoke-direct/range {v3 .. v9}, Le0;-><init>(JLyj9;Ljava/lang/String;Ljava/lang/String;Lhf2;)V

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :pswitch_0
    move-object v8, p1

    .line 31
    new-instance v4, Le0;

    .line 32
    .line 33
    move-object v9, v2

    .line 34
    check-cast v9, Le89;

    .line 35
    .line 36
    iget-wide v6, p0, Le0;->f:J

    .line 37
    .line 38
    move-object v10, v1

    .line 39
    check-cast v10, Lca6;

    .line 40
    .line 41
    const/4 v5, 0x6

    .line 42
    invoke-direct/range {v4 .. v10}, Le0;-><init>(IJLhf2;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-object v4

    .line 46
    :pswitch_1
    move-object v8, p1

    .line 47
    new-instance v4, Le0;

    .line 48
    .line 49
    iget-object p1, p0, Le0;->h:Ljava/lang/Object;

    .line 50
    .line 51
    move-object v5, p1

    .line 52
    check-cast v5, Lw37;

    .line 53
    .line 54
    move-object v6, v2

    .line 55
    check-cast v6, Ljava/lang/CharSequence;

    .line 56
    .line 57
    move-object v9, v8

    .line 58
    iget-wide v7, p0, Le0;->f:J

    .line 59
    .line 60
    check-cast v1, Le89;

    .line 61
    .line 62
    move-object v10, v9

    .line 63
    move-object v9, v1

    .line 64
    invoke-direct/range {v4 .. v10}, Le0;-><init>(Lw37;Ljava/lang/CharSequence;JLe89;Lhf2;)V

    .line 65
    .line 66
    .line 67
    return-object v4

    .line 68
    :pswitch_2
    move-object v8, p1

    .line 69
    new-instance v4, Le0;

    .line 70
    .line 71
    iget-object p1, p0, Le0;->h:Ljava/lang/Object;

    .line 72
    .line 73
    move-object v5, p1

    .line 74
    check-cast v5, Lb69;

    .line 75
    .line 76
    iget-wide v6, p0, Le0;->f:J

    .line 77
    .line 78
    check-cast v2, Lg69;

    .line 79
    .line 80
    move-object v9, v1

    .line 81
    check-cast v9, La69;

    .line 82
    .line 83
    move-object v10, v8

    .line 84
    move-object v8, v2

    .line 85
    invoke-direct/range {v4 .. v10}, Le0;-><init>(Lb69;JLg69;La69;Lhf2;)V

    .line 86
    .line 87
    .line 88
    return-object v4

    .line 89
    :pswitch_3
    move-object v8, p1

    .line 90
    new-instance v4, Le0;

    .line 91
    .line 92
    move-object v9, v2

    .line 93
    check-cast v9, La28;

    .line 94
    .line 95
    iget-wide v6, p0, Le0;->f:J

    .line 96
    .line 97
    move-object v10, v1

    .line 98
    check-cast v10, Lhl7;

    .line 99
    .line 100
    const/4 v5, 0x3

    .line 101
    invoke-direct/range {v4 .. v10}, Le0;-><init>(IJLhf2;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    iput-object p2, v4, Le0;->h:Ljava/lang/Object;

    .line 105
    .line 106
    return-object v4

    .line 107
    :pswitch_4
    move-object v8, p1

    .line 108
    new-instance v4, Le0;

    .line 109
    .line 110
    move-object v5, v2

    .line 111
    check-cast v5, Lmc5;

    .line 112
    .line 113
    move-object v6, v1

    .line 114
    check-cast v6, Lpg3;

    .line 115
    .line 116
    move-object v9, v8

    .line 117
    iget-wide v7, p0, Le0;->f:J

    .line 118
    .line 119
    invoke-direct/range {v4 .. v9}, Le0;-><init>(Lmc5;Lpg3;JLhf2;)V

    .line 120
    .line 121
    .line 122
    return-object v4

    .line 123
    :pswitch_5
    move-object v8, p1

    .line 124
    new-instance p0, Le0;

    .line 125
    .line 126
    check-cast v2, Lli3;

    .line 127
    .line 128
    check-cast v1, Ljava/lang/String;

    .line 129
    .line 130
    invoke-direct {p0, v2, v1, v8}, Le0;-><init>(Lli3;Ljava/lang/String;Lhf2;)V

    .line 131
    .line 132
    .line 133
    iput-object p2, p0, Le0;->h:Ljava/lang/Object;

    .line 134
    .line 135
    return-object p0

    .line 136
    :pswitch_6
    move-object v8, p1

    .line 137
    new-instance v4, Le0;

    .line 138
    .line 139
    move-object v9, v2

    .line 140
    check-cast v9, Lht4;

    .line 141
    .line 142
    iget-wide v6, p0, Le0;->f:J

    .line 143
    .line 144
    move-object v10, v1

    .line 145
    check-cast v10, Lca6;

    .line 146
    .line 147
    const/4 v5, 0x0

    .line 148
    invoke-direct/range {v4 .. v10}, Le0;-><init>(IJLhf2;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    return-object v4

    .line 152
    nop

    .line 153
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
