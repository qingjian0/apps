.class public final Lix;
.super Le09;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lwv3;


# instance fields
.field public final synthetic e:I

.field public f:I

.field public final synthetic g:Z

.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
    .locals 0

    .line 17
    iput p1, p0, Lix;->e:I

    iput-boolean p6, p0, Lix;->g:Z

    iput-object p3, p0, Lix;->h:Ljava/lang/Object;

    iput-object p4, p0, Lix;->i:Ljava/lang/Object;

    iput-object p5, p0, Lix;->j:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lb11;Lk11;Lig2;ZLhf2;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lix;->e:I

    .line 18
    iput-object p1, p0, Lix;->h:Ljava/lang/Object;

    iput-object p2, p0, Lix;->i:Ljava/lang/Object;

    iput-object p3, p0, Lix;->j:Ljava/lang/Object;

    iput-boolean p4, p0, Lix;->g:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lki3;Lk11;ZLhf2;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lix;->e:I

    .line 19
    iput-object p1, p0, Lix;->i:Ljava/lang/Object;

    iput-object p2, p0, Lix;->j:Ljava/lang/Object;

    iput-boolean p3, p0, Lix;->g:Z

    invoke-direct {p0, v0, p4}, Le09;-><init>(ILhf2;)V

    return-void
.end method

.method public constructor <init>(Lui;ZLsk9;Lhv3;Lhf2;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lix;->e:I

    .line 3
    .line 4
    iput-object p1, p0, Lix;->h:Ljava/lang/Object;

    .line 5
    .line 6
    iput-boolean p2, p0, Lix;->g:Z

    .line 7
    .line 8
    iput-object p3, p0, Lix;->i:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p4, p0, Lix;->j:Ljava/lang/Object;

    .line 11
    .line 12
    const/4 p1, 0x2

    .line 13
    invoke-direct {p0, p1, p5}, Le09;-><init>(ILhf2;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 15

    .line 1
    iget v0, p0, Lix;->e:I

    .line 2
    .line 3
    const/high16 v1, 0x3f800000    # 1.0f

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v7, 0x0

    .line 7
    sget-object v8, Llp9;->a:Llp9;

    .line 8
    .line 9
    iget-object v9, p0, Lix;->j:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v3, p0, Lix;->i:Ljava/lang/Object;

    .line 12
    .line 13
    iget-boolean v4, p0, Lix;->g:Z

    .line 14
    .line 15
    const-string v6, "call to \'resume\' before \'invoke\' with coroutine"

    .line 16
    .line 17
    sget-object v10, Ljg2;->a:Ljg2;

    .line 18
    .line 19
    const/4 v11, 0x1

    .line 20
    const/4 v12, 0x0

    .line 21
    packed-switch v0, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 25
    .line 26
    move-object v13, v0

    .line 27
    check-cast v13, Lmc5;

    .line 28
    .line 29
    iget v0, p0, Lix;->f:I

    .line 30
    .line 31
    const/4 v14, 0x2

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    if-eq v0, v11, :cond_1

    .line 35
    .line 36
    if-ne v0, v14, :cond_0

    .line 37
    .line 38
    :try_start_0
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    .line 41
    move-object/from16 v0, p1

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :catchall_0
    move-exception v0

    .line 45
    goto :goto_4

    .line 46
    :cond_0
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    move-object v8, v12

    .line 50
    goto :goto_3

    .line 51
    :cond_1
    :try_start_1
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 52
    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_2
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    if-eqz v4, :cond_3

    .line 59
    .line 60
    :try_start_2
    iget-object v0, v13, Lmc5;->p:Lui;

    .line 61
    .line 62
    new-instance v4, Ljava/lang/Float;

    .line 63
    .line 64
    invoke-direct {v4, v2}, Ljava/lang/Float;-><init>(F)V

    .line 65
    .line 66
    .line 67
    iput v11, p0, Lix;->f:I

    .line 68
    .line 69
    invoke-virtual {v0, p0, v4}, Lui;->f(Lhf2;Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    if-ne v0, v10, :cond_3

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_3
    :goto_0
    iget-object v0, v13, Lmc5;->p:Lui;

    .line 77
    .line 78
    new-instance v2, Ljava/lang/Float;

    .line 79
    .line 80
    invoke-direct {v2, v1}, Ljava/lang/Float;-><init>(F)V

    .line 81
    .line 82
    .line 83
    check-cast v3, Lpg3;

    .line 84
    .line 85
    check-cast v9, Ln24;

    .line 86
    .line 87
    new-instance v4, Llc5;

    .line 88
    .line 89
    invoke-direct {v4, v9, v13, v7}, Llc5;-><init>(Ln24;Lmc5;I)V

    .line 90
    .line 91
    .line 92
    iput v14, p0, Lix;->f:I

    .line 93
    .line 94
    move-object v1, v2

    .line 95
    move-object v2, v3

    .line 96
    const/4 v3, 0x0

    .line 97
    const/4 v6, 0x4

    .line 98
    move-object v5, p0

    .line 99
    invoke-static/range {v0 .. v6}, Lui;->b(Lui;Ljava/lang/Object;Lsl;Ljava/lang/Float;Lsv3;Lhf2;I)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    if-ne v0, v10, :cond_4

    .line 104
    .line 105
    :goto_1
    move-object v8, v10

    .line 106
    goto :goto_3

    .line 107
    :cond_4
    :goto_2
    check-cast v0, Lql;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 108
    .line 109
    invoke-virtual {v13, v7}, Lmc5;->d(Z)V

    .line 110
    .line 111
    .line 112
    :goto_3
    return-object v8

    .line 113
    :goto_4
    invoke-virtual {v13, v7}, Lmc5;->d(Z)V

    .line 114
    .line 115
    .line 116
    throw v0

    .line 117
    :pswitch_0
    iget v0, p0, Lix;->f:I

    .line 118
    .line 119
    if-eqz v0, :cond_6

    .line 120
    .line 121
    if-ne v0, v11, :cond_5

    .line 122
    .line 123
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    goto :goto_5

    .line 127
    :cond_5
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    move-object v8, v12

    .line 131
    goto :goto_5

    .line 132
    :cond_6
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    check-cast v3, Lns8;

    .line 136
    .line 137
    invoke-interface {v3}, Lns8;->getValue()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    check-cast v0, Ljava/lang/Boolean;

    .line 142
    .line 143
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    if-nez v0, :cond_7

    .line 148
    .line 149
    if-eqz v4, :cond_8

    .line 150
    .line 151
    :cond_7
    check-cast v9, Ldb6;

    .line 152
    .line 153
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 154
    .line 155
    invoke-interface {v9, v0}, Ldb6;->setValue(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v0, Lui;

    .line 161
    .line 162
    new-instance v1, Ljava/lang/Float;

    .line 163
    .line 164
    invoke-direct {v1, v2}, Ljava/lang/Float;-><init>(F)V

    .line 165
    .line 166
    .line 167
    iput v11, p0, Lix;->f:I

    .line 168
    .line 169
    invoke-virtual {v0, p0, v1}, Lui;->f(Lhf2;Ljava/lang/Object;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    if-ne v0, v10, :cond_8

    .line 174
    .line 175
    move-object v8, v10

    .line 176
    :cond_8
    :goto_5
    return-object v8

    .line 177
    :pswitch_1
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 178
    .line 179
    check-cast v0, Ldb6;

    .line 180
    .line 181
    iget v1, p0, Lix;->f:I

    .line 182
    .line 183
    if-eqz v1, :cond_a

    .line 184
    .line 185
    if-ne v1, v11, :cond_9

    .line 186
    .line 187
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    goto :goto_6

    .line 191
    :cond_9
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    move-object v8, v12

    .line 195
    goto :goto_7

    .line 196
    :cond_a
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 197
    .line 198
    .line 199
    if-eqz v4, :cond_b

    .line 200
    .line 201
    invoke-interface {v0}, Lns8;->getValue()Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    move-result-object v1

    .line 205
    check-cast v1, Ljava/lang/Boolean;

    .line 206
    .line 207
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 208
    .line 209
    .line 210
    move-result v1

    .line 211
    if-eqz v1, :cond_b

    .line 212
    .line 213
    check-cast v3, Lpm3;

    .line 214
    .line 215
    invoke-interface {v3, v7}, Lpm3;->b(Z)V

    .line 216
    .line 217
    .line 218
    new-instance v1, Llw0;

    .line 219
    .line 220
    invoke-direct {v1, v0, v12, v11}, Llw0;-><init>(Ldb6;Lhf2;I)V

    .line 221
    .line 222
    .line 223
    iput v11, p0, Lix;->f:I

    .line 224
    .line 225
    const-wide/16 v2, 0x1f4

    .line 226
    .line 227
    invoke-static {v2, v3, v1, p0}, Lp75;->Q(JLwv3;Lif2;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    if-ne v0, v10, :cond_b

    .line 232
    .line 233
    move-object v8, v10

    .line 234
    goto :goto_7

    .line 235
    :cond_b
    :goto_6
    check-cast v9, Leb6;

    .line 236
    .line 237
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    invoke-virtual {v9, v0}, Leb6;->i1(Ljava/lang/Object;)V

    .line 242
    .line 243
    .line 244
    :goto_7
    return-object v8

    .line 245
    :pswitch_2
    check-cast v9, Lk11;

    .line 246
    .line 247
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v0, Lig2;

    .line 250
    .line 251
    iget v1, p0, Lix;->f:I

    .line 252
    .line 253
    if-eqz v1, :cond_d

    .line 254
    .line 255
    if-ne v1, v11, :cond_c

    .line 256
    .line 257
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    goto :goto_8

    .line 261
    :cond_c
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    move-object v8, v12

    .line 265
    goto :goto_8

    .line 266
    :cond_d
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 267
    .line 268
    .line 269
    check-cast v3, Lki3;

    .line 270
    .line 271
    iget-object v1, v9, Lk11;->a:Lcg2;

    .line 272
    .line 273
    invoke-static {v3, v1}, Llj0;->W(Lki3;Lag2;)Lki3;

    .line 274
    .line 275
    .line 276
    move-result-object v1

    .line 277
    new-instance v2, Ln4;

    .line 278
    .line 279
    invoke-direct {v2, v9, v0, v4}, Ln4;-><init>(Lk11;Lig2;Z)V

    .line 280
    .line 281
    .line 282
    iput-object v12, p0, Lix;->h:Ljava/lang/Object;

    .line 283
    .line 284
    iput v11, p0, Lix;->f:I

    .line 285
    .line 286
    invoke-interface {v1, v2, p0}, Lki3;->b(Lli3;Lhf2;)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    if-ne v0, v10, :cond_e

    .line 291
    .line 292
    move-object v8, v10

    .line 293
    :cond_e
    :goto_8
    return-object v8

    .line 294
    :pswitch_3
    check-cast v3, Lk11;

    .line 295
    .line 296
    iget v0, p0, Lix;->f:I

    .line 297
    .line 298
    if-eqz v0, :cond_10

    .line 299
    .line 300
    if-ne v0, v11, :cond_f

    .line 301
    .line 302
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 303
    .line 304
    .line 305
    goto/16 :goto_c

    .line 306
    .line 307
    :cond_f
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    :goto_9
    move-object v8, v12

    .line 311
    goto/16 :goto_c

    .line 312
    .line 313
    :cond_10
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 317
    .line 318
    check-cast v0, Lb11;

    .line 319
    .line 320
    instance-of v1, v0, Ly01;

    .line 321
    .line 322
    move v13, v4

    .line 323
    const/4 v4, 0x0

    .line 324
    if-eqz v1, :cond_11

    .line 325
    .line 326
    check-cast v0, Ly01;

    .line 327
    .line 328
    check-cast v9, Lig2;

    .line 329
    .line 330
    iget-object v1, v0, Ly01;->a:Ljava/lang/String;

    .line 331
    .line 332
    iput-object v1, v3, Lk11;->n:Ljava/lang/String;

    .line 333
    .line 334
    iget-object v1, v3, Lk11;->c:Lru1;

    .line 335
    .line 336
    sget-object v2, Lkw8;->d:Lkw8;

    .line 337
    .line 338
    iput-object v2, v1, Lru1;->b:Lkw8;

    .line 339
    .line 340
    iget-object v1, v3, Lk11;->k:Le11;

    .line 341
    .line 342
    new-instance v2, Lhr8;

    .line 343
    .line 344
    invoke-direct {v2, v0}, Lhr8;-><init>(Ly01;)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v1, v2}, Le11;->f(Llr8;)V

    .line 348
    .line 349
    .line 350
    iget-object v0, v3, Lk11;->l:Ljava/lang/Long;

    .line 351
    .line 352
    if-eqz v0, :cond_19

    .line 353
    .line 354
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 355
    .line 356
    .line 357
    move-result-wide v1

    .line 358
    new-instance v0, Lbi;

    .line 359
    .line 360
    const/4 v5, 0x1

    .line 361
    invoke-direct/range {v0 .. v5}, Lbi;-><init>(JLjava/lang/Object;Lhf2;I)V

    .line 362
    .line 363
    .line 364
    const/4 v1, 0x3

    .line 365
    invoke-static {v9, v4, v7, v0, v1}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    iput-object v0, v3, Lk11;->o:Lwr8;

    .line 370
    .line 371
    goto :goto_c

    .line 372
    :cond_11
    instance-of v1, v0, Lz01;

    .line 373
    .line 374
    if-eqz v1, :cond_17

    .line 375
    .line 376
    check-cast v0, Lz01;

    .line 377
    .line 378
    iget-object v0, v0, Lz01;->a:La98;

    .line 379
    .line 380
    iput-object v0, v3, Lk11;->t:La98;

    .line 381
    .line 382
    iput-boolean v13, v3, Lk11;->u:Z

    .line 383
    .line 384
    new-instance v1, Lm01;

    .line 385
    .line 386
    iget-object v2, v0, La98;->i:Lk88;

    .line 387
    .line 388
    iget-object v3, v0, La98;->h:Lk88;

    .line 389
    .line 390
    if-eqz v3, :cond_13

    .line 391
    .line 392
    iget v5, v3, Lk88;->a:I

    .line 393
    .line 394
    if-eqz v5, :cond_12

    .line 395
    .line 396
    goto :goto_a

    .line 397
    :cond_12
    iget-object v2, v3, Lk88;->c:Ljava/lang/Object;

    .line 398
    .line 399
    check-cast v2, Lg98;

    .line 400
    .line 401
    invoke-direct {v1, v2, v0}, Lm01;-><init>(Lg98;La98;)V

    .line 402
    .line 403
    .line 404
    throw v1

    .line 405
    :cond_13
    :goto_a
    if-eqz v3, :cond_14

    .line 406
    .line 407
    iget v0, v3, Lk88;->a:I

    .line 408
    .line 409
    goto :goto_b

    .line 410
    :cond_14
    if-eqz v2, :cond_15

    .line 411
    .line 412
    iget v0, v2, Lk88;->a:I

    .line 413
    .line 414
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 415
    .line 416
    .line 417
    move-result-object v4

    .line 418
    :cond_15
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 419
    .line 420
    .line 421
    move-result v0

    .line 422
    :goto_b
    new-instance v1, Lu88;

    .line 423
    .line 424
    if-eqz v3, :cond_16

    .line 425
    .line 426
    iget-object v2, v3, Lk88;->b:Ljava/lang/String;

    .line 427
    .line 428
    :cond_16
    invoke-direct {v1, v0}, Lu88;-><init>(I)V

    .line 429
    .line 430
    .line 431
    throw v1

    .line 432
    :cond_17
    instance-of v1, v0, La11;

    .line 433
    .line 434
    if-eqz v1, :cond_18

    .line 435
    .line 436
    check-cast v0, La11;

    .line 437
    .line 438
    iget-object v0, v0, La11;->a:Lgw8;

    .line 439
    .line 440
    iput v11, p0, Lix;->f:I

    .line 441
    .line 442
    invoke-static {v3, v0, p0}, Lk11;->a(Lk11;Lgw8;Lif2;)Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    if-ne v0, v10, :cond_19

    .line 447
    .line 448
    move-object v8, v10

    .line 449
    goto :goto_c

    .line 450
    :cond_18
    invoke-static {}, Ld42;->d()V

    .line 451
    .line 452
    .line 453
    goto/16 :goto_9

    .line 454
    .line 455
    :cond_19
    :goto_c
    return-object v8

    .line 456
    :pswitch_4
    move v13, v4

    .line 457
    iget v0, p0, Lix;->f:I

    .line 458
    .line 459
    if-eqz v0, :cond_1b

    .line 460
    .line 461
    if-ne v0, v11, :cond_1a

    .line 462
    .line 463
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 464
    .line 465
    .line 466
    goto :goto_e

    .line 467
    :cond_1a
    invoke-static {v6}, Lpm0;->e(Ljava/lang/String;)V

    .line 468
    .line 469
    .line 470
    move-object v8, v12

    .line 471
    goto :goto_f

    .line 472
    :cond_1b
    invoke-static/range {p1 .. p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 473
    .line 474
    .line 475
    iget-object v0, p0, Lix;->h:Ljava/lang/Object;

    .line 476
    .line 477
    check-cast v0, Lui;

    .line 478
    .line 479
    if-eqz v13, :cond_1c

    .line 480
    .line 481
    goto :goto_d

    .line 482
    :cond_1c
    move v1, v2

    .line 483
    :goto_d
    new-instance v2, Ljava/lang/Float;

    .line 484
    .line 485
    invoke-direct {v2, v1}, Ljava/lang/Float;-><init>(F)V

    .line 486
    .line 487
    .line 488
    check-cast v3, Lsk9;

    .line 489
    .line 490
    iput v11, p0, Lix;->f:I

    .line 491
    .line 492
    move-object v1, v2

    .line 493
    move-object v2, v3

    .line 494
    const/4 v3, 0x0

    .line 495
    const/4 v4, 0x0

    .line 496
    const/16 v6, 0xc

    .line 497
    .line 498
    move-object v5, p0

    .line 499
    invoke-static/range {v0 .. v6}, Lui;->b(Lui;Ljava/lang/Object;Lsl;Ljava/lang/Float;Lsv3;Lhf2;I)Ljava/lang/Object;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    if-ne v0, v10, :cond_1d

    .line 504
    .line 505
    move-object v8, v10

    .line 506
    goto :goto_f

    .line 507
    :cond_1d
    :goto_e
    check-cast v9, Lhv3;

    .line 508
    .line 509
    invoke-interface {v9}, Lhv3;->v()Ljava/lang/Object;

    .line 510
    .line 511
    .line 512
    :goto_f
    return-object v8

    .line 513
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Lix;->e:I

    .line 2
    .line 3
    sget-object v1, Llp9;->a:Llp9;

    .line 4
    .line 5
    check-cast p1, Lig2;

    .line 6
    .line 7
    check-cast p2, Lhf2;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lix;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lix;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_1
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Lix;

    .line 39
    .line 40
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_2
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Lix;

    .line 50
    .line 51
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :pswitch_3
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    check-cast p0, Lix;

    .line 61
    .line 62
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    return-object p0

    .line 67
    :pswitch_4
    invoke-virtual {p0, p2, p1}, Lix;->x(Lhf2;Ljava/lang/Object;)Lhf2;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    check-cast p0, Lix;

    .line 72
    .line 73
    invoke-virtual {p0, v1}, Lix;->A(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    return-object p0

    .line 78
    nop

    .line 79
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final x(Lhf2;Ljava/lang/Object;)Lhf2;
    .locals 11

    .line 1
    iget v0, p0, Lix;->e:I

    .line 2
    .line 3
    iget-object v1, p0, Lix;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lix;->i:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    new-instance v3, Lix;

    .line 11
    .line 12
    iget-object p2, p0, Lix;->h:Ljava/lang/Object;

    .line 13
    .line 14
    move-object v6, p2

    .line 15
    check-cast v6, Lmc5;

    .line 16
    .line 17
    move-object v7, v2

    .line 18
    check-cast v7, Lpg3;

    .line 19
    .line 20
    move-object v8, v1

    .line 21
    check-cast v8, Ln24;

    .line 22
    .line 23
    const/4 v4, 0x5

    .line 24
    iget-boolean v9, p0, Lix;->g:Z

    .line 25
    .line 26
    move-object v5, p1

    .line 27
    invoke-direct/range {v3 .. v9}, Lix;-><init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 28
    .line 29
    .line 30
    return-object v3

    .line 31
    :pswitch_0
    move-object v6, p1

    .line 32
    new-instance v4, Lix;

    .line 33
    .line 34
    iget-object p1, p0, Lix;->h:Ljava/lang/Object;

    .line 35
    .line 36
    move-object v7, p1

    .line 37
    check-cast v7, Lui;

    .line 38
    .line 39
    move-object v8, v2

    .line 40
    check-cast v8, Lns8;

    .line 41
    .line 42
    move-object v9, v1

    .line 43
    check-cast v9, Ldb6;

    .line 44
    .line 45
    const/4 v5, 0x4

    .line 46
    iget-boolean v10, p0, Lix;->g:Z

    .line 47
    .line 48
    invoke-direct/range {v4 .. v10}, Lix;-><init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 49
    .line 50
    .line 51
    return-object v4

    .line 52
    :pswitch_1
    move-object v6, p1

    .line 53
    new-instance v4, Lix;

    .line 54
    .line 55
    iget-object p1, p0, Lix;->h:Ljava/lang/Object;

    .line 56
    .line 57
    move-object v7, p1

    .line 58
    check-cast v7, Ldb6;

    .line 59
    .line 60
    move-object v8, v2

    .line 61
    check-cast v8, Lpm3;

    .line 62
    .line 63
    move-object v9, v1

    .line 64
    check-cast v9, Leb6;

    .line 65
    .line 66
    const/4 v5, 0x3

    .line 67
    iget-boolean v10, p0, Lix;->g:Z

    .line 68
    .line 69
    invoke-direct/range {v4 .. v10}, Lix;-><init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 70
    .line 71
    .line 72
    return-object v4

    .line 73
    :pswitch_2
    move-object v6, p1

    .line 74
    new-instance p1, Lix;

    .line 75
    .line 76
    check-cast v2, Lki3;

    .line 77
    .line 78
    check-cast v1, Lk11;

    .line 79
    .line 80
    iget-boolean p0, p0, Lix;->g:Z

    .line 81
    .line 82
    invoke-direct {p1, v2, v1, p0, v6}, Lix;-><init>(Lki3;Lk11;ZLhf2;)V

    .line 83
    .line 84
    .line 85
    iput-object p2, p1, Lix;->h:Ljava/lang/Object;

    .line 86
    .line 87
    return-object p1

    .line 88
    :pswitch_3
    move-object v6, p1

    .line 89
    new-instance v4, Lix;

    .line 90
    .line 91
    iget-object p1, p0, Lix;->h:Ljava/lang/Object;

    .line 92
    .line 93
    move-object v5, p1

    .line 94
    check-cast v5, Lb11;

    .line 95
    .line 96
    check-cast v2, Lk11;

    .line 97
    .line 98
    move-object v7, v1

    .line 99
    check-cast v7, Lig2;

    .line 100
    .line 101
    iget-boolean v8, p0, Lix;->g:Z

    .line 102
    .line 103
    move-object v9, v6

    .line 104
    move-object v6, v2

    .line 105
    invoke-direct/range {v4 .. v9}, Lix;-><init>(Lb11;Lk11;Lig2;ZLhf2;)V

    .line 106
    .line 107
    .line 108
    return-object v4

    .line 109
    :pswitch_4
    move-object v6, p1

    .line 110
    new-instance v4, Lix;

    .line 111
    .line 112
    iget-object p1, p0, Lix;->h:Ljava/lang/Object;

    .line 113
    .line 114
    move-object v5, p1

    .line 115
    check-cast v5, Lui;

    .line 116
    .line 117
    move-object v7, v2

    .line 118
    check-cast v7, Lsk9;

    .line 119
    .line 120
    move-object v8, v1

    .line 121
    check-cast v8, Lhv3;

    .line 122
    .line 123
    iget-boolean p0, p0, Lix;->g:Z

    .line 124
    .line 125
    move-object v9, v6

    .line 126
    move v6, p0

    .line 127
    invoke-direct/range {v4 .. v9}, Lix;-><init>(Lui;ZLsk9;Lhv3;Lhf2;)V

    .line 128
    .line 129
    .line 130
    return-object v4

    .line 131
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
