.class public final Lk11;
.super Ljava/lang/Object;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lk55;


# instance fields
.field public final a:Lcg2;

.field public final b:Lwr;

.field public final c:Lru1;

.field public final d:Lvq;

.field public final e:Lnx;

.field public final f:Lvq;

.field public final g:Lwv3;

.field public final h:Lwv3;

.field public final i:Ljava/lang/String;

.field public final j:Lsv3;

.field public final k:Le11;

.field public final l:Ljava/lang/Long;

.field public final m:Lfd0;

.field public n:Ljava/lang/String;

.field public o:Lwr8;

.field public p:Lor8;

.field public q:Lnx;

.field public r:Ljava/lang/String;

.field public s:Ld98;

.field public t:La98;

.field public u:Z

.field public v:Lkx0;

.field public w:I

.field public x:Lla1;

.field public final y:Ljava/util/LinkedHashSet;


# direct methods
.method public constructor <init>(Lcg2;Lwr;Lru1;Lvq;Lnx;Lvq;Lwv3;Lwv3;Ljava/lang/String;Lsv3;Le11;Ljava/lang/Long;Lfd0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lk11;->a:Lcg2;

    .line 5
    .line 6
    iput-object p2, p0, Lk11;->b:Lwr;

    .line 7
    .line 8
    iput-object p3, p0, Lk11;->c:Lru1;

    .line 9
    .line 10
    iput-object p4, p0, Lk11;->d:Lvq;

    .line 11
    .line 12
    iput-object p5, p0, Lk11;->e:Lnx;

    .line 13
    .line 14
    iput-object p6, p0, Lk11;->f:Lvq;

    .line 15
    .line 16
    iput-object p7, p0, Lk11;->g:Lwv3;

    .line 17
    .line 18
    iput-object p8, p0, Lk11;->h:Lwv3;

    .line 19
    .line 20
    iput-object p9, p0, Lk11;->i:Ljava/lang/String;

    .line 21
    .line 22
    iput-object p10, p0, Lk11;->j:Lsv3;

    .line 23
    .line 24
    iput-object p11, p0, Lk11;->k:Le11;

    .line 25
    .line 26
    iput-object p12, p0, Lk11;->l:Ljava/lang/Long;

    .line 27
    .line 28
    iput-object p13, p0, Lk11;->m:Lfd0;

    .line 29
    .line 30
    const-string p1, ""

    .line 31
    .line 32
    iput-object p1, p0, Lk11;->n:Ljava/lang/String;

    .line 33
    .line 34
    const/4 p1, -0x1

    .line 35
    iput p1, p0, Lk11;->w:I

    .line 36
    .line 37
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 38
    .line 39
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object p1, p0, Lk11;->y:Ljava/util/LinkedHashSet;

    .line 43
    .line 44
    new-instance p0, Lkr8;

    .line 45
    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p11, p0}, Le11;->f(Llr8;)V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public static final a(Lk11;Lgw8;Lif2;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Lk11;->k:Le11;

    .line 8
    .line 9
    iget-object v4, v0, Lk11;->b:Lwr;

    .line 10
    .line 11
    instance-of v5, v2, Lf11;

    .line 12
    .line 13
    if-eqz v5, :cond_0

    .line 14
    .line 15
    move-object v5, v2

    .line 16
    check-cast v5, Lf11;

    .line 17
    .line 18
    iget v6, v5, Lf11;->g:I

    .line 19
    .line 20
    const/high16 v7, -0x80000000

    .line 21
    .line 22
    and-int v8, v6, v7

    .line 23
    .line 24
    if-eqz v8, :cond_0

    .line 25
    .line 26
    sub-int/2addr v6, v7

    .line 27
    iput v6, v5, Lf11;->g:I

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    new-instance v5, Lf11;

    .line 31
    .line 32
    invoke-direct {v5, v0, v2}, Lf11;-><init>(Lk11;Lif2;)V

    .line 33
    .line 34
    .line 35
    :goto_0
    iget-object v2, v5, Lf11;->e:Ljava/lang/Object;

    .line 36
    .line 37
    iget v6, v5, Lf11;->g:I

    .line 38
    .line 39
    const/4 v7, 0x3

    .line 40
    const/4 v8, 0x2

    .line 41
    const/4 v9, 0x1

    .line 42
    sget-object v10, Llp9;->a:Llp9;

    .line 43
    .line 44
    const/4 v11, 0x0

    .line 45
    if-eqz v6, :cond_4

    .line 46
    .line 47
    if-eq v6, v9, :cond_3

    .line 48
    .line 49
    if-eq v6, v8, :cond_2

    .line 50
    .line 51
    if-ne v6, v7, :cond_1

    .line 52
    .line 53
    iget-object v1, v5, Lf11;->d:Lgw8;

    .line 54
    .line 55
    :try_start_0
    invoke-static {v2}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_7

    .line 56
    .line 57
    .line 58
    goto/16 :goto_4

    .line 59
    .line 60
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 61
    .line 62
    invoke-static {v0}, Lpm0;->e(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    return-object v11

    .line 66
    :cond_2
    iget-object v1, v5, Lf11;->d:Lgw8;

    .line 67
    .line 68
    :try_start_1
    invoke-static {v2}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_5

    .line 69
    .line 70
    .line 71
    goto/16 :goto_4

    .line 72
    .line 73
    :cond_3
    iget-object v1, v5, Lf11;->d:Lgw8;

    .line 74
    .line 75
    :try_start_2
    invoke-static {v2}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 76
    .line 77
    .line 78
    goto/16 :goto_4

    .line 79
    .line 80
    :cond_4
    invoke-static {v2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    iget-object v2, v0, Lk11;->i:Ljava/lang/String;

    .line 84
    .line 85
    iget-object v6, v4, Lwr;->q:Ljava/util/HashMap;

    .line 86
    .line 87
    invoke-virtual {v6, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    check-cast v2, Lhv1;

    .line 92
    .line 93
    const/4 v6, 0x0

    .line 94
    if-eqz v2, :cond_5

    .line 95
    .line 96
    iget-boolean v2, v2, Lhv1;->d:Z

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_5
    move v2, v6

    .line 100
    :goto_1
    const-string v12, "toast"

    .line 101
    .line 102
    if-nez v2, :cond_6

    .line 103
    .line 104
    iget-object v2, v1, Lgw8;->a:Ljava/lang/String;

    .line 105
    .line 106
    invoke-static {v2, v12}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    if-eqz v2, :cond_6

    .line 111
    .line 112
    goto/16 :goto_4

    .line 113
    .line 114
    :cond_6
    iget-object v2, v1, Lgw8;->a:Ljava/lang/String;

    .line 115
    .line 116
    iget-object v13, v1, Lgw8;->b:Ljava/lang/String;

    .line 117
    .line 118
    const-string v14, "ready"

    .line 119
    .line 120
    invoke-static {v2, v14}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v14

    .line 124
    if-eqz v14, :cond_7

    .line 125
    .line 126
    :try_start_3
    sget-object v1, Low4;->a:Lew4;

    .line 127
    .line 128
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    .line 131
    sget-object v3, Ls01;->Companion:Lr01;

    .line 132
    .line 133
    invoke-virtual {v3}, Lr01;->serializer()Lv35;

    .line 134
    .line 135
    .line 136
    move-result-object v3

    .line 137
    check-cast v3, Lv35;

    .line 138
    .line 139
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    check-cast v1, Ls01;

    .line 144
    .line 145
    invoke-static {v0, v1}, Lk11;->f(Lk11;Ls01;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 146
    .line 147
    .line 148
    goto/16 :goto_4

    .line 149
    .line 150
    :catch_0
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    goto/16 :goto_4

    .line 154
    .line 155
    :cond_7
    invoke-static {v2, v11}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v14

    .line 159
    sget-object v15, Ljg2;->a:Ljg2;

    .line 160
    .line 161
    if-eqz v14, :cond_8

    .line 162
    .line 163
    :try_start_4
    sget-object v2, Low4;->a:Lew4;

    .line 164
    .line 165
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    sget-object v3, Lsu2;->Companion:Lru2;

    .line 169
    .line 170
    invoke-virtual {v3}, Lru2;->serializer()Lv35;

    .line 171
    .line 172
    .line 173
    move-result-object v3

    .line 174
    check-cast v3, Lv35;

    .line 175
    .line 176
    invoke-virtual {v2, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v2

    .line 180
    check-cast v2, Lsu2;

    .line 181
    .line 182
    iget v3, v0, Lk11;->w:I

    .line 183
    .line 184
    add-int/2addr v3, v9

    .line 185
    iput v3, v0, Lk11;->w:I

    .line 186
    .line 187
    iput-object v1, v5, Lf11;->d:Lgw8;

    .line 188
    .line 189
    iput v9, v5, Lf11;->g:I

    .line 190
    .line 191
    invoke-static {v0, v3, v2, v5}, Lk11;->e(Lk11;ILsu2;Lif2;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    .line 195
    if-ne v0, v15, :cond_15

    .line 196
    .line 197
    goto/16 :goto_3

    .line 198
    .line 199
    :catch_1
    iget-object v1, v1, Lgw8;->a:Ljava/lang/String;

    .line 200
    .line 201
    invoke-virtual {v0, v1}, Lk11;->i(Ljava/lang/String;)V

    .line 202
    .line 203
    .line 204
    goto/16 :goto_4

    .line 205
    .line 206
    :cond_8
    const-string v9, "finish"

    .line 207
    .line 208
    invoke-static {v2, v9}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    move-result v9

    .line 212
    if-eqz v9, :cond_9

    .line 213
    .line 214
    goto/16 :goto_4

    .line 215
    .line 216
    :cond_9
    invoke-static {v2, v12}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v9

    .line 220
    if-eqz v9, :cond_a

    .line 221
    .line 222
    :try_start_5
    sget-object v1, Low4;->a:Lew4;

    .line 223
    .line 224
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 225
    .line 226
    .line 227
    sget-object v3, Lq11;->Companion:Lp11;

    .line 228
    .line 229
    invoke-virtual {v3}, Lp11;->serializer()Lv35;

    .line 230
    .line 231
    .line 232
    move-result-object v3

    .line 233
    check-cast v3, Lv35;

    .line 234
    .line 235
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    check-cast v1, Lq11;

    .line 240
    .line 241
    invoke-static {v0, v1}, Lk11;->g(Lk11;Lq11;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    .line 242
    .line 243
    .line 244
    goto/16 :goto_4

    .line 245
    .line 246
    :catch_2
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    goto/16 :goto_4

    .line 250
    .line 251
    :cond_a
    const-string v9, "hint"

    .line 252
    .line 253
    invoke-static {v2, v9}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    move-result v9

    .line 257
    if-eqz v9, :cond_b

    .line 258
    .line 259
    :try_start_6
    sget-object v1, Low4;->a:Lew4;

    .line 260
    .line 261
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 262
    .line 263
    .line 264
    sget-object v4, Lp01;->Companion:Lo01;

    .line 265
    .line 266
    invoke-virtual {v4}, Lo01;->serializer()Lv35;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    check-cast v4, Lv35;

    .line 271
    .line 272
    invoke-virtual {v1, v4, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v1

    .line 276
    check-cast v1, Lp01;

    .line 277
    .line 278
    iget-object v1, v1, Lp01;->a:Ld98;

    .line 279
    .line 280
    iput-object v1, v0, Lk11;->s:Ld98;

    .line 281
    .line 282
    iget-object v4, v3, Le11;->h:Ljava/lang/Object;

    .line 283
    .line 284
    move-object v11, v4

    .line 285
    check-cast v11, Ljava/lang/String;

    .line 286
    .line 287
    iget-object v4, v3, Le11;->e:Ljava/lang/Object;

    .line 288
    .line 289
    move-object v12, v4

    .line 290
    check-cast v12, Ljava/lang/String;

    .line 291
    .line 292
    invoke-virtual {v3}, Le11;->b()I

    .line 293
    .line 294
    .line 295
    move-result v13

    .line 296
    iget-object v14, v1, Ld98;->d:Ljava/lang/String;

    .line 297
    .line 298
    iget-object v15, v1, Ld98;->b:Ljava/lang/String;

    .line 299
    .line 300
    invoke-virtual {v3}, Le11;->a()Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v16

    .line 304
    iget-object v1, v3, Le11;->c:Ljava/lang/Object;

    .line 305
    .line 306
    check-cast v1, Lwr;

    .line 307
    .line 308
    invoke-virtual {v1}, Lwr;->h()Ljava/lang/String;

    .line 309
    .line 310
    .line 311
    move-result-object v17

    .line 312
    invoke-static/range {v11 .. v17}, Lkf2;->Q(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    .line 313
    .line 314
    .line 315
    goto/16 :goto_4

    .line 316
    .line 317
    :catch_3
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    goto/16 :goto_4

    .line 321
    .line 322
    :cond_b
    const-string v9, "title"

    .line 323
    .line 324
    invoke-static {v2, v9}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 325
    .line 326
    .line 327
    move-result v9

    .line 328
    if-eqz v9, :cond_c

    .line 329
    .line 330
    :try_start_7
    sget-object v1, Low4;->a:Lew4;

    .line 331
    .line 332
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 333
    .line 334
    .line 335
    sget-object v3, Ln11;->Companion:Lm11;

    .line 336
    .line 337
    invoke-virtual {v3}, Lm11;->serializer()Lv35;

    .line 338
    .line 339
    .line 340
    move-result-object v3

    .line 341
    check-cast v3, Lv35;

    .line 342
    .line 343
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    check-cast v1, Ln11;

    .line 348
    .line 349
    iget-object v1, v1, Ln11;->a:Ljava/lang/String;

    .line 350
    .line 351
    iget-object v3, v4, Lwr;->g:Lrs8;

    .line 352
    .line 353
    invoke-virtual {v3, v1}, Lrs8;->l(Ljava/lang/Object;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4

    .line 354
    .line 355
    .line 356
    goto/16 :goto_4

    .line 357
    .line 358
    :catch_4
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    goto/16 :goto_4

    .line 362
    .line 363
    :cond_c
    const-string v9, "update_session"

    .line 364
    .line 365
    invoke-static {v2, v9}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 366
    .line 367
    .line 368
    move-result v9

    .line 369
    if-eqz v9, :cond_d

    .line 370
    .line 371
    iget-object v2, v0, Lk11;->h:Lwv3;

    .line 372
    .line 373
    :try_start_8
    sget-object v3, Low4;->a:Lew4;

    .line 374
    .line 375
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 376
    .line 377
    .line 378
    sget-object v4, Lz11;->Companion:Ly11;

    .line 379
    .line 380
    invoke-virtual {v4}, Ly11;->serializer()Lv35;

    .line 381
    .line 382
    .line 383
    move-result-object v4

    .line 384
    check-cast v4, Lv35;

    .line 385
    .line 386
    invoke-virtual {v3, v4, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v3

    .line 390
    iput-object v1, v5, Lf11;->d:Lgw8;

    .line 391
    .line 392
    iput v8, v5, Lf11;->g:I

    .line 393
    .line 394
    invoke-interface {v2, v3, v5}, Lwv3;->q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_5

    .line 398
    if-ne v0, v15, :cond_15

    .line 399
    .line 400
    goto/16 :goto_3

    .line 401
    .line 402
    :catch_5
    iget-object v1, v1, Lgw8;->a:Ljava/lang/String;

    .line 403
    .line 404
    invoke-virtual {v0, v1}, Lk11;->i(Ljava/lang/String;)V

    .line 405
    .line 406
    .line 407
    goto/16 :goto_4

    .line 408
    .line 409
    :cond_d
    const-string v8, "update_file"

    .line 410
    .line 411
    invoke-static {v2, v8}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 412
    .line 413
    .line 414
    move-result v8

    .line 415
    if-eqz v8, :cond_e

    .line 416
    .line 417
    :try_start_9
    sget-object v1, Low4;->a:Lew4;

    .line 418
    .line 419
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 420
    .line 421
    .line 422
    sget-object v3, Lhr;->Companion:Lgr;

    .line 423
    .line 424
    invoke-virtual {v3}, Lgr;->serializer()Lv35;

    .line 425
    .line 426
    .line 427
    move-result-object v3

    .line 428
    check-cast v3, Lv35;

    .line 429
    .line 430
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 431
    .line 432
    .line 433
    move-result-object v1

    .line 434
    check-cast v1, Lhr;

    .line 435
    .line 436
    invoke-static {v0, v1}, Lk11;->h(Lk11;Lhr;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_6

    .line 437
    .line 438
    .line 439
    goto/16 :goto_4

    .line 440
    .line 441
    :catch_6
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 442
    .line 443
    .line 444
    goto/16 :goto_4

    .line 445
    .line 446
    :cond_e
    const-string v8, "update_parent_message"

    .line 447
    .line 448
    invoke-static {v2, v8}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 449
    .line 450
    .line 451
    move-result v8

    .line 452
    if-eqz v8, :cond_11

    .line 453
    .line 454
    :try_start_a
    sget-object v2, Low4;->a:Lew4;

    .line 455
    .line 456
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 457
    .line 458
    .line 459
    sget-object v3, Lw11;->Companion:Lv11;

    .line 460
    .line 461
    invoke-virtual {v3}, Lv11;->serializer()Lv35;

    .line 462
    .line 463
    .line 464
    move-result-object v3

    .line 465
    check-cast v3, Lv35;

    .line 466
    .line 467
    invoke-virtual {v2, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 468
    .line 469
    .line 470
    move-result-object v2

    .line 471
    check-cast v2, Lw11;

    .line 472
    .line 473
    iput-object v1, v5, Lf11;->d:Lgw8;

    .line 474
    .line 475
    iput v7, v5, Lf11;->g:I

    .line 476
    .line 477
    iget-object v3, v2, Lw11;->a:Lnx;

    .line 478
    .line 479
    iget v3, v3, Lnx;->g:I

    .line 480
    .line 481
    invoke-virtual {v4, v3}, Lwr;->k(I)Lhv1;

    .line 482
    .line 483
    .line 484
    move-result-object v3

    .line 485
    if-eqz v3, :cond_f

    .line 486
    .line 487
    iget-boolean v7, v3, Lhv1;->d:Z

    .line 488
    .line 489
    if-eqz v7, :cond_f

    .line 490
    .line 491
    iget-object v3, v3, Lhv1;->a:Ljava/lang/String;

    .line 492
    .line 493
    iget-object v7, v4, Lwr;->q:Ljava/util/HashMap;

    .line 494
    .line 495
    invoke-virtual {v7, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v3

    .line 499
    check-cast v3, Lhv1;

    .line 500
    .line 501
    if-eqz v3, :cond_f

    .line 502
    .line 503
    iput-boolean v6, v3, Lhv1;->d:Z

    .line 504
    .line 505
    :cond_f
    new-instance v3, Ll4;

    .line 506
    .line 507
    const/16 v7, 0x9

    .line 508
    .line 509
    invoke-direct {v3, v2, v11, v7}, Ll4;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 510
    .line 511
    .line 512
    invoke-virtual {v4, v6, v3, v5}, Lwr;->E(ZLwv3;Lif2;)Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_7

    .line 516
    if-ne v0, v15, :cond_10

    .line 517
    .line 518
    goto :goto_2

    .line 519
    :cond_10
    move-object v0, v10

    .line 520
    :goto_2
    if-ne v0, v15, :cond_15

    .line 521
    .line 522
    :goto_3
    return-object v15

    .line 523
    :catch_7
    iget-object v1, v1, Lgw8;->a:Ljava/lang/String;

    .line 524
    .line 525
    invoke-virtual {v0, v1}, Lk11;->i(Ljava/lang/String;)V

    .line 526
    .line 527
    .line 528
    goto/16 :goto_4

    .line 529
    .line 530
    :cond_11
    const-string v1, "close"

    .line 531
    .line 532
    invoke-static {v2, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 533
    .line 534
    .line 535
    move-result v1

    .line 536
    if-eqz v1, :cond_12

    .line 537
    .line 538
    :try_start_b
    sget-object v1, Low4;->a:Lew4;

    .line 539
    .line 540
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 541
    .line 542
    .line 543
    sget-object v3, Lh01;->Companion:Lg01;

    .line 544
    .line 545
    invoke-virtual {v3}, Lg01;->serializer()Lv35;

    .line 546
    .line 547
    .line 548
    move-result-object v3

    .line 549
    check-cast v3, Lv35;

    .line 550
    .line 551
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 552
    .line 553
    .line 554
    move-result-object v1

    .line 555
    check-cast v1, Lh01;

    .line 556
    .line 557
    invoke-static {v0, v1}, Lk11;->d(Lk11;Lh01;)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_8

    .line 558
    .line 559
    .line 560
    goto/16 :goto_4

    .line 561
    .line 562
    :catch_8
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 563
    .line 564
    .line 565
    goto/16 :goto_4

    .line 566
    .line 567
    :cond_12
    const-string v1, "check_client_update"

    .line 568
    .line 569
    invoke-static {v2, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 570
    .line 571
    .line 572
    move-result v1

    .line 573
    if-eqz v1, :cond_13

    .line 574
    .line 575
    :try_start_c
    sget-object v1, Low4;->a:Lew4;

    .line 576
    .line 577
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 578
    .line 579
    .line 580
    sget-object v3, Le01;->Companion:Ld01;

    .line 581
    .line 582
    invoke-virtual {v3}, Ld01;->serializer()Lv35;

    .line 583
    .line 584
    .line 585
    move-result-object v3

    .line 586
    check-cast v3, Lv35;

    .line 587
    .line 588
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 589
    .line 590
    .line 591
    move-result-object v1

    .line 592
    check-cast v1, Le01;

    .line 593
    .line 594
    invoke-static {v0, v1}, Lk11;->c(Lk11;Le01;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_9

    .line 595
    .line 596
    .line 597
    goto :goto_4

    .line 598
    :catch_9
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 599
    .line 600
    .line 601
    goto :goto_4

    .line 602
    :cond_13
    const-string v1, "auto_tts_capability"

    .line 603
    .line 604
    invoke-static {v2, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 605
    .line 606
    .line 607
    move-result v1

    .line 608
    if-eqz v1, :cond_14

    .line 609
    .line 610
    :try_start_d
    sget-object v1, Low4;->a:Lew4;

    .line 611
    .line 612
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 613
    .line 614
    .line 615
    sget-object v3, Lb01;->Companion:La01;

    .line 616
    .line 617
    invoke-virtual {v3}, La01;->serializer()Lv35;

    .line 618
    .line 619
    .line 620
    move-result-object v3

    .line 621
    check-cast v3, Lv35;

    .line 622
    .line 623
    invoke-virtual {v1, v3, v13}, Lfu4;->b(Lv35;Ljava/lang/String;)Ljava/lang/Object;

    .line 624
    .line 625
    .line 626
    move-result-object v1

    .line 627
    check-cast v1, Lb01;

    .line 628
    .line 629
    invoke-static {v0, v1}, Lk11;->b(Lk11;Lb01;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_a

    .line 630
    .line 631
    .line 632
    goto :goto_4

    .line 633
    :catch_a
    invoke-virtual {v0, v2}, Lk11;->i(Ljava/lang/String;)V

    .line 634
    .line 635
    .line 636
    goto :goto_4

    .line 637
    :cond_14
    if-eqz v2, :cond_15

    .line 638
    .line 639
    iget-object v0, v3, Le11;->h:Ljava/lang/Object;

    .line 640
    .line 641
    check-cast v0, Ljava/lang/String;

    .line 642
    .line 643
    iget-object v1, v3, Le11;->e:Ljava/lang/Object;

    .line 644
    .line 645
    check-cast v1, Ljava/lang/String;

    .line 646
    .line 647
    invoke-virtual {v3}, Le11;->a()Ljava/lang/String;

    .line 648
    .line 649
    .line 650
    move-result-object v4

    .line 651
    invoke-virtual {v3}, Le11;->b()I

    .line 652
    .line 653
    .line 654
    move-result v3

    .line 655
    const-string v5, "chat_session_id"

    .line 656
    .line 657
    const-string v6, "sse_transaction_uuid"

    .line 658
    .line 659
    invoke-static {v5, v0, v6, v1}, Lsqa;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 660
    .line 661
    .line 662
    move-result-object v0

    .line 663
    const-string v1, "sse_event_name"

    .line 664
    .line 665
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 666
    .line 667
    .line 668
    const-string v1, "stream_scenario"

    .line 669
    .line 670
    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 671
    .line 672
    .line 673
    const-string v1, "sse_time_elapsed"

    .line 674
    .line 675
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 676
    .line 677
    .line 678
    sget-object v1, Ldw;->a:Lnqa;

    .line 679
    .line 680
    const-string v2, "sse_event"

    .line 681
    .line 682
    invoke-virtual {v1, v2, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 683
    .line 684
    .line 685
    :cond_15
    :goto_4
    return-object v10
.end method

.method public static final b(Lk11;Lb01;)V
    .locals 6

    .line 1
    iget-object p1, p1, Lb01;->a:Ljava/lang/String;

    .line 2
    .line 3
    sget-object v0, Led0;->Companion:Ldd0;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v0, "ready"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_2

    .line 15
    .line 16
    iget-object v1, p0, Lk11;->m:Lfd0;

    .line 17
    .line 18
    if-eqz v1, :cond_2

    .line 19
    .line 20
    iget-object v2, p0, Lk11;->b:Lwr;

    .line 21
    .line 22
    iget-object v3, p0, Lk11;->i:Ljava/lang/String;

    .line 23
    .line 24
    iget-object p0, v1, Lfd0;->c:Lf21;

    .line 25
    .line 26
    invoke-virtual {p0, v2}, Lf21;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Ljava/lang/Boolean;

    .line 31
    .line 32
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    if-nez p0, :cond_0

    .line 37
    .line 38
    const-string p0, "Auto tts disabled by client switch, ignore ready capability"

    .line 39
    .line 40
    invoke-static {p0}, Lv9a;->F(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_0
    iget-object p0, v1, Lfd0;->e:Lwr8;

    .line 45
    .line 46
    if-eqz p0, :cond_1

    .line 47
    .line 48
    invoke-virtual {p0}, Lut4;->d()Z

    .line 49
    .line 50
    .line 51
    move-result p0

    .line 52
    const/4 p1, 0x1

    .line 53
    if-ne p0, p1, :cond_1

    .line 54
    .line 55
    const-string p0, "Auto tts start already pending, ignore duplicate event"

    .line 56
    .line 57
    invoke-static {p0}, Lv9a;->F(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_1
    iget-object p0, v1, Lfd0;->d:Lbs0;

    .line 62
    .line 63
    new-instance v0, Ld0;

    .line 64
    .line 65
    const/16 v5, 0xd

    .line 66
    .line 67
    const/4 v4, 0x0

    .line 68
    invoke-direct/range {v0 .. v5}, Ld0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 69
    .line 70
    .line 71
    const/4 p1, 0x3

    .line 72
    const/4 v2, 0x0

    .line 73
    invoke-static {p0, v4, v2, v0, p1}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    iput-object p0, v1, Lfd0;->e:Lwr8;

    .line 78
    .line 79
    :cond_2
    return-void
.end method

.method public static final c(Lk11;Le01;)V
    .locals 4

    .line 1
    const-class p0, Lh12;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-static {}, Ltga;->I()Lcj;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    iget-object v1, v1, Lcj;->a:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lqra;

    .line 11
    .line 12
    iget-object v1, v1, Lqra;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Li08;

    .line 15
    .line 16
    sget-object v2, Lan7;->a:Lbn7;

    .line 17
    .line 18
    invoke-virtual {v2, p0}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-virtual {v1, p0, v0, v0}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Lh12;

    .line 27
    .line 28
    iget-object p1, p1, Le01;->a:Ljava/lang/String;

    .line 29
    .line 30
    const-class v1, Lrv;

    .line 31
    .line 32
    invoke-static {}, Ltga;->I()Lcj;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    iget-object v2, v2, Lcj;->a:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v2, Lqra;

    .line 39
    .line 40
    iget-object v2, v2, Lqra;->e:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v2, Li08;

    .line 43
    .line 44
    sget-object v3, Lan7;->a:Lbn7;

    .line 45
    .line 46
    invoke-virtual {v3, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v2, v1, v0, v0}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    check-cast v1, Lrv;

    .line 55
    .line 56
    iget-object v1, v1, Lrv;->a:Lcom/tencent/mmkv/MMKV;

    .line 57
    .line 58
    const-string v2, "key_client_update_show_key"

    .line 59
    .line 60
    invoke-virtual {v1, v2}, Lcom/tencent/mmkv/MMKV;->j(Ljava/lang/String;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-static {v1, p1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    if-eqz p1, :cond_0

    .line 69
    .line 70
    return-void

    .line 71
    :cond_0
    sget-object p1, Lcom/deepseek/chat/App;->a:Lbs0;

    .line 72
    .line 73
    invoke-static {}, Ljt5;->y()Lig2;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    new-instance v1, Ld12;

    .line 78
    .line 79
    const/4 v2, 0x1

    .line 80
    invoke-direct {v1, p0, v0, v2}, Ld12;-><init>(Lh12;Lhf2;I)V

    .line 81
    .line 82
    .line 83
    const/4 p0, 0x3

    .line 84
    const/4 v2, 0x0

    .line 85
    invoke-static {p1, v0, v2, v1, p0}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 86
    .line 87
    .line 88
    return-void
.end method

.method public static final d(Lk11;Lh01;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lk11;->c:Lru1;

    .line 2
    .line 3
    sget-object v1, Lkw8;->b:Lkw8;

    .line 4
    .line 5
    iput-object v1, v0, Lru1;->b:Lkw8;

    .line 6
    .line 7
    iget-object p1, p1, Lh01;->a:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p1, p0, Lk11;->r:Ljava/lang/String;

    .line 10
    .line 11
    iget-object p1, p0, Lk11;->k:Le11;

    .line 12
    .line 13
    iget-object v0, p1, Le11;->h:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Ljava/lang/String;

    .line 16
    .line 17
    iget-object v1, p1, Le11;->e:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {p1}, Le11;->a()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {p1}, Le11;->b()I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    const-string v3, "chat_session_id"

    .line 30
    .line 31
    const-string v4, "sse_transaction_uuid"

    .line 32
    .line 33
    invoke-static {v3, v0, v4, v1}, Lsqa;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    const-string v1, "sse_event_name"

    .line 38
    .line 39
    const-string v3, "close"

    .line 40
    .line 41
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 42
    .line 43
    .line 44
    const-string v1, "stream_scenario"

    .line 45
    .line 46
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 47
    .line 48
    .line 49
    const-string v1, "sse_time_elapsed"

    .line 50
    .line 51
    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 52
    .line 53
    .line 54
    sget-object p1, Ldw;->a:Lnqa;

    .line 55
    .line 56
    const-string v1, "sse_event"

    .line 57
    .line 58
    invoke-virtual {p1, v1, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 59
    .line 60
    .line 61
    iget-object p1, p0, Lk11;->j:Lsv3;

    .line 62
    .line 63
    iget-object p0, p0, Lk11;->b:Lwr;

    .line 64
    .line 65
    invoke-interface {p1, p0}, Lsv3;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public static final e(Lk11;ILsu2;Lif2;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    move-object/from16 v1, p3

    .line 6
    .line 7
    iget-object v6, v2, Lk11;->b:Lwr;

    .line 8
    .line 9
    iget-object v7, v2, Lk11;->k:Le11;

    .line 10
    .line 11
    iget-object v3, v7, Le11;->h:Ljava/lang/Object;

    .line 12
    .line 13
    move-object v8, v3

    .line 14
    check-cast v8, Ljava/lang/String;

    .line 15
    .line 16
    instance-of v3, v1, Lg11;

    .line 17
    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    move-object v3, v1

    .line 21
    check-cast v3, Lg11;

    .line 22
    .line 23
    iget v4, v3, Lg11;->h:I

    .line 24
    .line 25
    const/high16 v5, -0x80000000

    .line 26
    .line 27
    and-int v9, v4, v5

    .line 28
    .line 29
    if-eqz v9, :cond_0

    .line 30
    .line 31
    sub-int/2addr v4, v5

    .line 32
    iput v4, v3, Lg11;->h:I

    .line 33
    .line 34
    :goto_0
    move-object v9, v3

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    new-instance v3, Lg11;

    .line 37
    .line 38
    invoke-direct {v3, v2, v1}, Lg11;-><init>(Lk11;Lif2;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :goto_1
    iget-object v1, v9, Lg11;->f:Ljava/lang/Object;

    .line 43
    .line 44
    iget v3, v9, Lg11;->h:I

    .line 45
    .line 46
    const/4 v10, 0x1

    .line 47
    sget-object v11, Llp9;->a:Llp9;

    .line 48
    .line 49
    const/4 v4, 0x0

    .line 50
    if-eqz v3, :cond_2

    .line 51
    .line 52
    if-ne v3, v10, :cond_1

    .line 53
    .line 54
    iget-object v0, v9, Lg11;->e:Lpx;

    .line 55
    .line 56
    iget-object v3, v9, Lg11;->d:Lor8;

    .line 57
    .line 58
    invoke-static {v1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    goto/16 :goto_4

    .line 62
    .line 63
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 64
    .line 65
    invoke-static {v0}, Lpm0;->e(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    return-object v0

    .line 70
    :cond_2
    invoke-static {v1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    iget-object v1, v2, Lk11;->y:Ljava/util/LinkedHashSet;

    .line 74
    .line 75
    new-instance v3, Lfw8;

    .line 76
    .line 77
    invoke-direct {v3, v4}, Lfw8;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-interface {v1, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    const-string v1, ""

    .line 84
    .line 85
    const/4 v12, 0x0

    .line 86
    if-nez p1, :cond_9

    .line 87
    .line 88
    iget-object v0, v0, Lsu2;->c:Lev4;

    .line 89
    .line 90
    new-instance v3, Lkx0;

    .line 91
    .line 92
    sget-object v5, Ljq6;->Companion:Lep6;

    .line 93
    .line 94
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    const-string v5, "SET"

    .line 98
    .line 99
    invoke-direct {v3, v1, v5, v0}, Lkx0;-><init>(Ljava/lang/String;Ljava/lang/String;Lev4;)V

    .line 100
    .line 101
    .line 102
    iput-object v3, v2, Lk11;->v:Lkx0;

    .line 103
    .line 104
    sget-object v1, Low4;->a:Lew4;

    .line 105
    .line 106
    :try_start_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    sget-object v3, Lor8;->Companion:Lnr8;

    .line 110
    .line 111
    invoke-virtual {v3}, Lnr8;->serializer()Lv35;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    check-cast v3, Lv35;

    .line 116
    .line 117
    invoke-virtual {v1, v3, v0}, Lfu4;->a(Lv35;Lev4;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 121
    goto :goto_2

    .line 122
    :catch_0
    move-object v0, v4

    .line 123
    :goto_2
    move-object v13, v0

    .line 124
    check-cast v13, Lor8;

    .line 125
    .line 126
    iput-object v13, v2, Lk11;->p:Lor8;

    .line 127
    .line 128
    if-nez v13, :cond_3

    .line 129
    .line 130
    goto/16 :goto_a

    .line 131
    .line 132
    :cond_3
    iget-object v3, v13, Lor8;->a:Lpx;

    .line 133
    .line 134
    iget-object v0, v3, Lpx;->h:Ljava/lang/Integer;

    .line 135
    .line 136
    if-nez v0, :cond_4

    .line 137
    .line 138
    goto/16 :goto_a

    .line 139
    .line 140
    :cond_4
    iget-object v1, v2, Lk11;->g:Lwv3;

    .line 141
    .line 142
    if-eqz v1, :cond_5

    .line 143
    .line 144
    iget-wide v14, v3, Lpx;->j:D

    .line 145
    .line 146
    new-instance v5, Ljava/lang/Double;

    .line 147
    .line 148
    invoke-direct {v5, v14, v15}, Ljava/lang/Double;-><init>(D)V

    .line 149
    .line 150
    .line 151
    invoke-interface {v1, v0, v5}, Lwv3;->q(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    check-cast v0, Lnx;

    .line 156
    .line 157
    move-object v1, v0

    .line 158
    goto :goto_3

    .line 159
    :cond_5
    move-object v1, v4

    .line 160
    :goto_3
    new-instance v0, Lz4;

    .line 161
    .line 162
    const/16 v5, 0x8

    .line 163
    .line 164
    invoke-direct/range {v0 .. v5}, Lz4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 165
    .line 166
    .line 167
    iput-object v13, v9, Lg11;->d:Lor8;

    .line 168
    .line 169
    iput-object v3, v9, Lg11;->e:Lpx;

    .line 170
    .line 171
    iput v10, v9, Lg11;->h:I

    .line 172
    .line 173
    invoke-virtual {v6, v12, v0, v9}, Lwr;->E(ZLwv3;Lif2;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    sget-object v1, Ljg2;->a:Ljg2;

    .line 178
    .line 179
    if-ne v0, v1, :cond_6

    .line 180
    .line 181
    move-object v11, v1

    .line 182
    goto/16 :goto_a

    .line 183
    .line 184
    :cond_6
    move-object v0, v3

    .line 185
    move-object v3, v13

    .line 186
    :goto_4
    iget-object v1, v2, Lk11;->i:Ljava/lang/String;

    .line 187
    .line 188
    iget-object v5, v6, Lwr;->q:Ljava/util/HashMap;

    .line 189
    .line 190
    invoke-virtual {v5, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    check-cast v1, Lhv1;

    .line 195
    .line 196
    if-eqz v1, :cond_7

    .line 197
    .line 198
    iget v0, v0, Lpx;->g:I

    .line 199
    .line 200
    new-instance v5, Ljava/lang/Integer;

    .line 201
    .line 202
    invoke-direct {v5, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 203
    .line 204
    .line 205
    iput-object v5, v1, Lhv1;->f:Ljava/lang/Integer;

    .line 206
    .line 207
    iget-object v0, v1, Lhv1;->e:Lo52;

    .line 208
    .line 209
    invoke-virtual {v0, v5}, Lut4;->g0(Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    :cond_7
    iget-object v0, v3, Lor8;->a:Lpx;

    .line 213
    .line 214
    iget-object v1, v0, Lpx;->n:Lx31;

    .line 215
    .line 216
    iget-object v1, v1, Lx31;->a:Lhp8;

    .line 217
    .line 218
    invoke-virtual {v1}, Lhp8;->isEmpty()Z

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-eqz v1, :cond_8

    .line 223
    .line 224
    iget-object v1, v0, Lpx;->A:Lrs8;

    .line 225
    .line 226
    iget-object v0, v0, Lvq;->e:La02;

    .line 227
    .line 228
    invoke-virtual {v1, v0}, Lrs8;->l(Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    :cond_8
    iget-object v0, v3, Lor8;->a:Lpx;

    .line 232
    .line 233
    iget-object v0, v0, Lpx;->B:Lrs8;

    .line 234
    .line 235
    invoke-virtual {v0, v4}, Lrs8;->l(Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    iget-object v0, v2, Lk11;->c:Lru1;

    .line 239
    .line 240
    sget-object v1, Lkw8;->f:Lkw8;

    .line 241
    .line 242
    iput-object v1, v0, Lru1;->b:Lkw8;

    .line 243
    .line 244
    new-instance v0, Lir8;

    .line 245
    .line 246
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v7, v0}, Le11;->f(Llr8;)V

    .line 250
    .line 251
    .line 252
    goto/16 :goto_8

    .line 253
    .line 254
    :cond_9
    new-instance v3, Lkx0;

    .line 255
    .line 256
    iget-object v5, v2, Lk11;->v:Lkx0;

    .line 257
    .line 258
    if-eqz v5, :cond_18

    .line 259
    .line 260
    iget-object v6, v0, Lsu2;->a:Ljava/lang/String;

    .line 261
    .line 262
    if-nez v6, :cond_a

    .line 263
    .line 264
    iget-object v6, v5, Lkx0;->a:Ljava/lang/String;

    .line 265
    .line 266
    :cond_a
    iget-object v9, v0, Lsu2;->b:Ljava/lang/String;

    .line 267
    .line 268
    if-nez v9, :cond_b

    .line 269
    .line 270
    iget-object v9, v5, Lkx0;->b:Ljava/lang/String;

    .line 271
    .line 272
    :cond_b
    iget-object v0, v0, Lsu2;->c:Lev4;

    .line 273
    .line 274
    invoke-direct {v3, v6, v9, v0}, Lkx0;-><init>(Ljava/lang/String;Ljava/lang/String;Lev4;)V

    .line 275
    .line 276
    .line 277
    iput-object v3, v2, Lk11;->v:Lkx0;

    .line 278
    .line 279
    :try_start_1
    new-instance v0, Lx42;

    .line 280
    .line 281
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 282
    .line 283
    .line 284
    iput-boolean v12, v0, Lx42;->a:Z

    .line 285
    .line 286
    iput-boolean v12, v0, Lx42;->b:Z

    .line 287
    .line 288
    iput-boolean v12, v0, Lx42;->c:Z

    .line 289
    .line 290
    iget-object v5, v2, Lk11;->p:Lor8;

    .line 291
    .line 292
    if-eqz v5, :cond_c

    .line 293
    .line 294
    invoke-static {v5, v3, v4, v7, v0}, Lxs0;->g(Lw42;Lkx0;Ljava/util/List;Le11;Lx42;)V

    .line 295
    .line 296
    .line 297
    goto :goto_5

    .line 298
    :catchall_0
    move-exception v0

    .line 299
    goto :goto_6

    .line 300
    :cond_c
    :goto_5
    iget-boolean v3, v0, Lx42;->b:Z

    .line 301
    .line 302
    if-nez v3, :cond_d

    .line 303
    .line 304
    iget-boolean v3, v0, Lx42;->a:Z

    .line 305
    .line 306
    if-nez v3, :cond_d

    .line 307
    .line 308
    iget-boolean v0, v0, Lx42;->c:Z

    .line 309
    .line 310
    if-eqz v0, :cond_11

    .line 311
    .line 312
    :cond_d
    iget-object v0, v2, Lk11;->p:Lor8;

    .line 313
    .line 314
    if-eqz v0, :cond_11

    .line 315
    .line 316
    iget-object v0, v0, Lor8;->a:Lpx;

    .line 317
    .line 318
    if-eqz v0, :cond_11

    .line 319
    .line 320
    invoke-virtual {v0}, Lpx;->y()Lrs8;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    invoke-virtual {v0, v4}, Lrs8;->l(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 325
    .line 326
    .line 327
    goto :goto_8

    .line 328
    :goto_6
    instance-of v3, v0, Lz78;

    .line 329
    .line 330
    if-nez v3, :cond_e

    .line 331
    .line 332
    instance-of v0, v0, Ljava/lang/IllegalArgumentException;

    .line 333
    .line 334
    if-eqz v0, :cond_11

    .line 335
    .line 336
    :cond_e
    iget-object v0, v7, Le11;->l:Ljava/lang/Object;

    .line 337
    .line 338
    check-cast v0, Ljava/lang/Integer;

    .line 339
    .line 340
    iget-object v3, v7, Le11;->k:Ljava/lang/Object;

    .line 341
    .line 342
    check-cast v3, Ly01;

    .line 343
    .line 344
    if-eqz v3, :cond_10

    .line 345
    .line 346
    iget-object v3, v3, Ly01;->a:Ljava/lang/String;

    .line 347
    .line 348
    if-nez v3, :cond_f

    .line 349
    .line 350
    goto :goto_7

    .line 351
    :cond_f
    move-object v1, v3

    .line 352
    :cond_10
    :goto_7
    const-string v3, "delta"

    .line 353
    .line 354
    const-string v5, "parse_error"

    .line 355
    .line 356
    invoke-static {v8, v0, v1, v3, v5}, Lmva;->E(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 357
    .line 358
    .line 359
    :cond_11
    :goto_8
    iget-object v0, v2, Lk11;->p:Lor8;

    .line 360
    .line 361
    if-eqz v0, :cond_12

    .line 362
    .line 363
    iget-object v0, v0, Lor8;->a:Lpx;

    .line 364
    .line 365
    goto :goto_9

    .line 366
    :cond_12
    move-object v0, v4

    .line 367
    :goto_9
    if-eqz v0, :cond_13

    .line 368
    .line 369
    iget-object v1, v0, Lpx;->C:Lrs8;

    .line 370
    .line 371
    iget-object v3, v0, Lpx;->n:Lx31;

    .line 372
    .line 373
    invoke-static {v3}, Lp75;->z(Lb41;)Lt28;

    .line 374
    .line 375
    .line 376
    move-result-object v3

    .line 377
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 378
    .line 379
    .line 380
    invoke-virtual {v1, v4, v3}, Lrs8;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 381
    .line 382
    .line 383
    :cond_13
    if-eqz v0, :cond_14

    .line 384
    .line 385
    invoke-virtual {v0}, Lvq;->L()Lla1;

    .line 386
    .line 387
    .line 388
    move-result-object v4

    .line 389
    :cond_14
    iget-object v0, v2, Lk11;->x:Lla1;

    .line 390
    .line 391
    invoke-static {v0, v4}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 392
    .line 393
    .line 394
    move-result v0

    .line 395
    if-nez v0, :cond_17

    .line 396
    .line 397
    if-eqz v4, :cond_17

    .line 398
    .line 399
    iget-object v0, v7, Le11;->e:Ljava/lang/Object;

    .line 400
    .line 401
    check-cast v0, Ljava/lang/String;

    .line 402
    .line 403
    invoke-virtual {v7}, Le11;->b()I

    .line 404
    .line 405
    .line 406
    move-result v1

    .line 407
    invoke-virtual {v7}, Le11;->a()Ljava/lang/String;

    .line 408
    .line 409
    .line 410
    move-result-object v3

    .line 411
    invoke-virtual {v4}, Lla1;->a()Ljava/lang/String;

    .line 412
    .line 413
    .line 414
    move-result-object v5

    .line 415
    const-string v6, "chat_session_id"

    .line 416
    .line 417
    const-string v9, "sse_transaction_uuid"

    .line 418
    .line 419
    invoke-static {v6, v8, v9, v0}, Lsqa;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 420
    .line 421
    .line 422
    move-result-object v0

    .line 423
    const-string v6, "sse_time_elapsed"

    .line 424
    .line 425
    invoke-virtual {v0, v6, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 426
    .line 427
    .line 428
    const-string v1, "stream_scenario"

    .line 429
    .line 430
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 431
    .line 432
    .line 433
    const-string v1, "chat_message_status"

    .line 434
    .line 435
    invoke-virtual {v0, v1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 436
    .line 437
    .line 438
    sget-object v1, Ldw;->a:Lnqa;

    .line 439
    .line 440
    const-string v3, "sse_msg_status_updated"

    .line 441
    .line 442
    invoke-virtual {v1, v3, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 443
    .line 444
    .line 445
    sget-object v0, Lka1;->a:Lka1;

    .line 446
    .line 447
    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 448
    .line 449
    .line 450
    move-result v0

    .line 451
    if-nez v0, :cond_16

    .line 452
    .line 453
    iget-object v0, v7, Le11;->c:Ljava/lang/Object;

    .line 454
    .line 455
    check-cast v0, Lwr;

    .line 456
    .line 457
    iget-object v1, v7, Le11;->d:Ljava/lang/Object;

    .line 458
    .line 459
    check-cast v1, Ljava/lang/String;

    .line 460
    .line 461
    iget-object v3, v0, Lwr;->q:Ljava/util/HashMap;

    .line 462
    .line 463
    invoke-virtual {v3, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v1

    .line 467
    check-cast v1, Lhv1;

    .line 468
    .line 469
    if-eqz v1, :cond_15

    .line 470
    .line 471
    sget-object v3, Lbv1;->c:Lbv1;

    .line 472
    .line 473
    iput-object v3, v1, Lhv1;->b:Ldv1;

    .line 474
    .line 475
    :cond_15
    invoke-virtual {v0}, Lwr;->D()V

    .line 476
    .line 477
    .line 478
    :cond_16
    iput-object v4, v2, Lk11;->x:Lla1;

    .line 479
    .line 480
    :cond_17
    :goto_a
    return-object v11

    .line 481
    :cond_18
    const-string v0, "lastChangeCommand"

    .line 482
    .line 483
    invoke-static {v0}, Lup4;->q(Ljava/lang/String;)V

    .line 484
    .line 485
    .line 486
    throw v4
.end method

.method public static final f(Lk11;Ls01;)V
    .locals 6

    .line 1
    sget-object v0, Lir;->b:Lir;

    .line 2
    .line 3
    iget-object v1, p0, Lk11;->b:Lwr;

    .line 4
    .line 5
    iget-object v2, p0, Lk11;->o:Lwr8;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    if-eqz v2, :cond_0

    .line 9
    .line 10
    invoke-virtual {v2, v3}, Lut4;->b(Ljava/util/concurrent/CancellationException;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    iput-object v3, p0, Lk11;->o:Lwr8;

    .line 14
    .line 15
    iget-object v2, p1, Ls01;->b:Ljava/lang/Integer;

    .line 16
    .line 17
    iget-object v3, p1, Ls01;->c:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v2, :cond_3

    .line 20
    .line 21
    iget-object v4, p0, Lk11;->i:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v5, v1, Lwr;->q:Ljava/util/HashMap;

    .line 24
    .line 25
    invoke-virtual {v5, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    check-cast v4, Lhv1;

    .line 30
    .line 31
    if-eqz v4, :cond_1

    .line 32
    .line 33
    iput-object v2, v4, Lhv1;->f:Ljava/lang/Integer;

    .line 34
    .line 35
    iget-object v5, v4, Lhv1;->e:Lo52;

    .line 36
    .line 37
    invoke-virtual {v5, v2}, Lut4;->g0(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    :cond_1
    if-eqz v4, :cond_3

    .line 41
    .line 42
    iget-object v4, v1, Lwr;->f:Ljava/util/LinkedHashMap;

    .line 43
    .line 44
    invoke-virtual {v4, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    check-cast v2, Lvq;

    .line 49
    .line 50
    if-eqz v2, :cond_2

    .line 51
    .line 52
    invoke-virtual {v2}, Lvq;->L()Lla1;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    sget-object v4, Lka1;->a:Lka1;

    .line 57
    .line 58
    invoke-virtual {v2, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-eqz v2, :cond_3

    .line 63
    .line 64
    invoke-virtual {v1, v0}, Lwr;->C(Lkr;)V

    .line 65
    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_2
    invoke-virtual {v1, v0}, Lwr;->C(Lkr;)V

    .line 69
    .line 70
    .line 71
    :cond_3
    :goto_0
    if-eqz v3, :cond_4

    .line 72
    .line 73
    invoke-virtual {v1, v3}, Lwr;->B(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    :cond_4
    iget-object v0, p0, Lk11;->k:Le11;

    .line 77
    .line 78
    new-instance v1, Ljr8;

    .line 79
    .line 80
    invoke-direct {v1, p1}, Ljr8;-><init>(Ls01;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0, v1}, Le11;->f(Llr8;)V

    .line 84
    .line 85
    .line 86
    iget-object p0, p0, Lk11;->c:Lru1;

    .line 87
    .line 88
    sget-object p1, Lkw8;->e:Lkw8;

    .line 89
    .line 90
    iput-object p1, p0, Lru1;->b:Lkw8;

    .line 91
    .line 92
    return-void
.end method

.method public static final g(Lk11;Lq11;)V
    .locals 9

    .line 1
    iget-object v0, p0, Lk11;->y:Ljava/util/LinkedHashSet;

    .line 2
    .line 3
    new-instance v1, Lfw8;

    .line 4
    .line 5
    const-string v2, "toast"

    .line 6
    .line 7
    invoke-direct {v1, v2}, Lfw8;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 11
    .line 12
    .line 13
    const-class v0, Ldo8;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-static {}, Ltga;->I()Lcj;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    iget-object v2, v2, Lcj;->a:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v2, Lqra;

    .line 23
    .line 24
    iget-object v2, v2, Lqra;->e:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v2, Li08;

    .line 27
    .line 28
    sget-object v3, Lan7;->a:Lbn7;

    .line 29
    .line 30
    invoke-virtual {v3, v0}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v2, v0, v1, v1}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Ldo8;

    .line 39
    .line 40
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    new-instance v2, Lgx;

    .line 44
    .line 45
    new-instance v3, Lk0;

    .line 46
    .line 47
    const/16 v4, 0x13

    .line 48
    .line 49
    invoke-direct {v3, v4, p1}, Lk0;-><init>(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object v4, p1, Lq11;->b:Ljava/lang/String;

    .line 53
    .line 54
    const-string v5, "error"

    .line 55
    .line 56
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v5

    .line 60
    const/4 v8, 0x3

    .line 61
    if-eqz v5, :cond_0

    .line 62
    .line 63
    const/4 v4, 0x2

    .line 64
    goto :goto_0

    .line 65
    :cond_0
    const-string v5, "success"

    .line 66
    .line 67
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-eqz v4, :cond_1

    .line 72
    .line 73
    const/4 v4, 0x1

    .line 74
    goto :goto_0

    .line 75
    :cond_1
    move v4, v8

    .line 76
    :goto_0
    const/4 v6, 0x0

    .line 77
    const/16 v7, 0x3a

    .line 78
    .line 79
    const/4 v5, 0x0

    .line 80
    invoke-direct/range {v2 .. v7}, Lgx;-><init>(Lsv3;IILjava/lang/String;I)V

    .line 81
    .line 82
    .line 83
    iget-object v3, v0, Ldo8;->a:Lig2;

    .line 84
    .line 85
    new-instance v4, Lle8;

    .line 86
    .line 87
    const/16 v5, 0x9

    .line 88
    .line 89
    invoke-direct {v4, v0, v2, v1, v5}, Lle8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 90
    .line 91
    .line 92
    const/4 v0, 0x0

    .line 93
    invoke-static {v3, v1, v0, v4, v8}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 94
    .line 95
    .line 96
    iget-object p0, p0, Lk11;->k:Le11;

    .line 97
    .line 98
    iget-object v0, p0, Le11;->h:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Ljava/lang/String;

    .line 101
    .line 102
    iget-object v1, p0, Le11;->e:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v1, Ljava/lang/String;

    .line 105
    .line 106
    invoke-virtual {p0}, Le11;->b()I

    .line 107
    .line 108
    .line 109
    move-result v2

    .line 110
    iget-object v3, p1, Lq11;->c:Ljava/lang/String;

    .line 111
    .line 112
    iget-object p1, p1, Lq11;->a:Ljava/lang/String;

    .line 113
    .line 114
    invoke-virtual {p0}, Le11;->a()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    iget-object p0, p0, Le11;->c:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast p0, Lwr;

    .line 121
    .line 122
    invoke-virtual {p0}, Lwr;->h()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    const-string v5, "chat_session_id"

    .line 127
    .line 128
    const-string v6, "sse_transaction_uuid"

    .line 129
    .line 130
    invoke-static {v5, v0, v6, v1}, Lsqa;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    const-string v1, "sse_time_elapsed"

    .line 135
    .line 136
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 137
    .line 138
    .line 139
    const-string v1, "stream_scenario"

    .line 140
    .line 141
    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 142
    .line 143
    .line 144
    const-string v1, "sse_error_reason"

    .line 145
    .line 146
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 147
    .line 148
    .line 149
    const-string v1, "sse_error_message"

    .line 150
    .line 151
    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 152
    .line 153
    .line 154
    const-string p1, "model_type"

    .line 155
    .line 156
    invoke-virtual {v0, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 157
    .line 158
    .line 159
    sget-object p0, Ldw;->a:Lnqa;

    .line 160
    .line 161
    const-string p1, "sse_toast"

    .line 162
    .line 163
    invoke-virtual {p0, p1, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 164
    .line 165
    .line 166
    return-void
.end method

.method public static final h(Lk11;Lhr;)V
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lk11;->q:Lnx;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    iget-object v2, v0, Lk11;->e:Lnx;

    .line 11
    .line 12
    :goto_0
    const/4 v11, 0x0

    .line 13
    if-eqz v2, :cond_3

    .line 14
    .line 15
    invoke-virtual {v2}, Lvq;->p()Lkt8;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    if-eqz v3, :cond_3

    .line 20
    .line 21
    iget-object v3, v3, Lkt8;->c:Lhp8;

    .line 22
    .line 23
    if-eqz v3, :cond_3

    .line 24
    .line 25
    invoke-virtual {v3}, Lhp8;->listIterator()Ljava/util/ListIterator;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    :cond_1
    move-object v4, v3

    .line 30
    check-cast v4, Lp74;

    .line 31
    .line 32
    invoke-virtual {v4}, Lp74;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_2

    .line 37
    .line 38
    invoke-virtual {v4}, Lp74;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    move-object v5, v4

    .line 43
    check-cast v5, Lhr;

    .line 44
    .line 45
    iget-object v5, v5, Lhr;->a:Ljava/lang/String;

    .line 46
    .line 47
    iget-object v6, v1, Lhr;->a:Ljava/lang/String;

    .line 48
    .line 49
    invoke-static {v5, v6}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    if-eqz v5, :cond_1

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_2
    move-object v4, v11

    .line 57
    :goto_1
    check-cast v4, Lhr;

    .line 58
    .line 59
    if-eqz v4, :cond_3

    .line 60
    .line 61
    iget-object v3, v4, Lhr;->r:Lof3;

    .line 62
    .line 63
    move-object v12, v3

    .line 64
    goto :goto_2

    .line 65
    :cond_3
    move-object v12, v11

    .line 66
    :goto_2
    const/4 v13, 0x0

    .line 67
    if-eqz v2, :cond_7

    .line 68
    .line 69
    invoke-virtual {v2}, Lvq;->p()Lkt8;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    if-eqz v2, :cond_7

    .line 74
    .line 75
    iget-object v14, v2, Lkt8;->c:Lhp8;

    .line 76
    .line 77
    invoke-virtual {v14}, Lhp8;->listIterator()Ljava/util/ListIterator;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    move v3, v13

    .line 82
    :goto_3
    move-object v4, v2

    .line 83
    check-cast v4, Lp74;

    .line 84
    .line 85
    invoke-virtual {v4}, Lp74;->hasNext()Z

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    if-eqz v5, :cond_5

    .line 90
    .line 91
    invoke-virtual {v4}, Lp74;->next()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    check-cast v4, Lhr;

    .line 96
    .line 97
    iget-object v4, v4, Lhr;->a:Ljava/lang/String;

    .line 98
    .line 99
    iget-object v5, v1, Lhr;->a:Ljava/lang/String;

    .line 100
    .line 101
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v4

    .line 105
    if-eqz v4, :cond_4

    .line 106
    .line 107
    :goto_4
    move v15, v3

    .line 108
    goto :goto_5

    .line 109
    :cond_4
    add-int/lit8 v3, v3, 0x1

    .line 110
    .line 111
    goto :goto_3

    .line 112
    :cond_5
    const/4 v3, -0x1

    .line 113
    goto :goto_4

    .line 114
    :goto_5
    if-gez v15, :cond_6

    .line 115
    .line 116
    goto :goto_6

    .line 117
    :cond_6
    invoke-virtual {v14, v15}, Lhp8;->get(I)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    check-cast v2, Lhr;

    .line 122
    .line 123
    iget-object v8, v2, Lhr;->q:Lc02;

    .line 124
    .line 125
    invoke-virtual {v14, v15}, Lhp8;->get(I)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v2

    .line 129
    check-cast v2, Lhr;

    .line 130
    .line 131
    iget-object v9, v2, Lhr;->r:Lof3;

    .line 132
    .line 133
    const v10, 0xffff

    .line 134
    .line 135
    .line 136
    const/4 v2, 0x0

    .line 137
    const/4 v3, 0x0

    .line 138
    const/4 v4, 0x0

    .line 139
    const/4 v5, 0x0

    .line 140
    const/4 v6, 0x0

    .line 141
    const/4 v7, 0x0

    .line 142
    invoke-static/range {v1 .. v10}, Lhr;->a(Lhr;Lm31;ZZLjava/lang/Integer;Ljava/lang/Integer;Lkf3;Lc02;Lof3;I)Lhr;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    invoke-virtual {v14, v15, v2}, Lhp8;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    :cond_7
    :goto_6
    iget-object v0, v0, Lk11;->k:Le11;

    .line 150
    .line 151
    if-nez v12, :cond_8

    .line 152
    .line 153
    goto :goto_7

    .line 154
    :cond_8
    iget-object v2, v1, Lhr;->b:Lm31;

    .line 155
    .line 156
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    sget-object v3, Lm31;->a:Ljava/util/Set;

    .line 160
    .line 161
    invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v3

    .line 165
    if-nez v3, :cond_9

    .line 166
    .line 167
    :goto_7
    return-void

    .line 168
    :cond_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 169
    .line 170
    .line 171
    move-result-wide v3

    .line 172
    iget-object v5, v12, Lof3;->a:Ljava/lang/Long;

    .line 173
    .line 174
    if-eqz v5, :cond_a

    .line 175
    .line 176
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 177
    .line 178
    .line 179
    move-result-wide v5

    .line 180
    goto :goto_8

    .line 181
    :cond_a
    move-wide v5, v3

    .line 182
    :goto_8
    sub-long/2addr v3, v5

    .line 183
    long-to-int v3, v3

    .line 184
    sget-object v4, Lm31;->d:Lm31;

    .line 185
    .line 186
    if-ne v2, v4, :cond_b

    .line 187
    .line 188
    const/4 v4, 0x1

    .line 189
    move/from16 v20, v4

    .line 190
    .line 191
    goto :goto_9

    .line 192
    :cond_b
    move/from16 v20, v13

    .line 193
    .line 194
    :goto_9
    iget-object v4, v0, Le11;->h:Ljava/lang/Object;

    .line 195
    .line 196
    move-object v14, v4

    .line 197
    check-cast v14, Ljava/lang/String;

    .line 198
    .line 199
    iget-object v15, v1, Lhr;->a:Ljava/lang/String;

    .line 200
    .line 201
    iget-object v4, v12, Lof3;->b:Ljava/lang/String;

    .line 202
    .line 203
    iget-object v5, v1, Lhr;->c:Ljava/lang/String;

    .line 204
    .line 205
    const/16 v6, 0x2e

    .line 206
    .line 207
    const-string v7, ""

    .line 208
    .line 209
    invoke-static {v6, v5, v7}, Llx8;->C0(CLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object v5

    .line 213
    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 214
    .line 215
    invoke-virtual {v5, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v17

    .line 219
    iget-wide v5, v1, Lhr;->d:J

    .line 220
    .line 221
    long-to-int v5, v5

    .line 222
    iget-object v6, v1, Lhr;->g:Ljava/lang/Integer;

    .line 223
    .line 224
    if-eqz v6, :cond_c

    .line 225
    .line 226
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 227
    .line 228
    .line 229
    move-result v13

    .line 230
    :cond_c
    move/from16 v19, v13

    .line 231
    .line 232
    iget-boolean v6, v1, Lhr;->k:Z

    .line 233
    .line 234
    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v23

    .line 238
    iget-object v2, v1, Lhr;->l:Ljava/lang/String;

    .line 239
    .line 240
    if-nez v2, :cond_d

    .line 241
    .line 242
    move-object/from16 v26, v11

    .line 243
    .line 244
    goto :goto_a

    .line 245
    :cond_d
    move-object/from16 v26, v2

    .line 246
    .line 247
    :goto_a
    iget-object v0, v0, Le11;->c:Ljava/lang/Object;

    .line 248
    .line 249
    check-cast v0, Lwr;

    .line 250
    .line 251
    invoke-virtual {v0}, Lwr;->h()Ljava/lang/String;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    if-nez v0, :cond_e

    .line 256
    .line 257
    move-object/from16 v27, v7

    .line 258
    .line 259
    goto :goto_b

    .line 260
    :cond_e
    move-object/from16 v27, v0

    .line 261
    .line 262
    :goto_b
    iget-object v0, v1, Lhr;->o:Ljava/lang/Boolean;

    .line 263
    .line 264
    if-eqz v20, :cond_f

    .line 265
    .line 266
    :goto_c
    move-object/from16 v28, v11

    .line 267
    .line 268
    goto :goto_d

    .line 269
    :cond_f
    const-string v11, "message_banner"

    .line 270
    .line 271
    goto :goto_c

    .line 272
    :goto_d
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 273
    .line 274
    .line 275
    move-result-object v22

    .line 276
    const/16 v24, 0x0

    .line 277
    .line 278
    const/16 v29, 0x1600

    .line 279
    .line 280
    move-object/from16 v25, v0

    .line 281
    .line 282
    move/from16 v21, v3

    .line 283
    .line 284
    move-object/from16 v16, v4

    .line 285
    .line 286
    move/from16 v18, v5

    .line 287
    .line 288
    invoke-static/range {v14 .. v29}, Lmva;->H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIZILjava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 289
    .line 290
    .line 291
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lk11;->b:Lwr;

    .line 2
    .line 3
    iget-object v0, v0, Lwr;->a:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, Lk11;->p:Lor8;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    iget-object v1, v1, Lor8;->a:Lpx;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    iget v1, v1, Lpx;->g:I

    .line 14
    .line 15
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    iget-object p0, p0, Lk11;->n:Ljava/lang/String;

    .line 22
    .line 23
    if-nez p1, :cond_1

    .line 24
    .line 25
    const-string p1, "delta"

    .line 26
    .line 27
    :cond_1
    const-string v2, "parse_error"

    .line 28
    .line 29
    invoke-static {v0, v1, p0, p1, v2}, Lmva;->E(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final j(Lif2;Lki3;Z)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    instance-of v2, v0, Lh11;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    move-object v2, v0

    .line 10
    check-cast v2, Lh11;

    .line 11
    .line 12
    iget v3, v2, Lh11;->g:I

    .line 13
    .line 14
    const/high16 v4, -0x80000000

    .line 15
    .line 16
    and-int v5, v3, v4

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Lh11;->g:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v2, Lh11;

    .line 25
    .line 26
    invoke-direct {v2, v1, v0}, Lh11;-><init>(Lk11;Lif2;)V

    .line 27
    .line 28
    .line 29
    :goto_0
    iget-object v0, v2, Lh11;->e:Ljava/lang/Object;

    .line 30
    .line 31
    iget v3, v2, Lh11;->g:I

    .line 32
    .line 33
    const/4 v4, 0x1

    .line 34
    iget-object v5, v1, Lk11;->k:Le11;

    .line 35
    .line 36
    const/4 v6, 0x0

    .line 37
    if-eqz v3, :cond_2

    .line 38
    .line 39
    if-ne v3, v4, :cond_1

    .line 40
    .line 41
    iget-wide v2, v2, Lh11;->d:J

    .line 42
    .line 43
    :try_start_0
    invoke-static {v0}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :catchall_0
    move-exception v0

    .line 48
    goto :goto_4

    .line 49
    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 50
    .line 51
    invoke-static {v0}, Lpm0;->e(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object v6

    .line 55
    :cond_2
    invoke-static {v0}, Lwe5;->F(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 59
    .line 60
    .line 61
    move-result-wide v7

    .line 62
    :try_start_1
    iput-wide v7, v2, Lh11;->d:J

    .line 63
    .line 64
    iput v4, v2, Lh11;->g:I

    .line 65
    .line 66
    move-object/from16 v0, p2

    .line 67
    .line 68
    move/from16 v3, p3

    .line 69
    .line 70
    invoke-virtual {v1, v2, v0, v3}, Lk11;->k(Lif2;Lki3;Z)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 74
    sget-object v2, Ljg2;->a:Ljg2;

    .line 75
    .line 76
    if-ne v0, v2, :cond_3

    .line 77
    .line 78
    return-object v2

    .line 79
    :cond_3
    move-wide v2, v7

    .line 80
    :goto_1
    :try_start_2
    move-object v8, v0

    .line 81
    check-cast v8, Llg6;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 82
    .line 83
    iget-object v0, v1, Lk11;->p:Lor8;

    .line 84
    .line 85
    if-eqz v0, :cond_4

    .line 86
    .line 87
    iget-object v0, v0, Lor8;->a:Lpx;

    .line 88
    .line 89
    goto :goto_2

    .line 90
    :cond_4
    move-object v0, v6

    .line 91
    :goto_2
    new-instance v4, Lgr8;

    .line 92
    .line 93
    if-eqz v0, :cond_5

    .line 94
    .line 95
    invoke-virtual {v0}, Lvq;->L()Lla1;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    goto :goto_3

    .line 100
    :cond_5
    move-object v0, v6

    .line 101
    :goto_3
    invoke-direct {v4, v0}, Lgr8;-><init>(Lla1;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v5, v4}, Le11;->f(Llr8;)V

    .line 105
    .line 106
    .line 107
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 108
    .line 109
    .line 110
    move-result-wide v9

    .line 111
    new-instance v14, Li11;

    .line 112
    .line 113
    const/4 v0, 0x0

    .line 114
    invoke-direct {v14, v1, v6, v0}, Li11;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 115
    .line 116
    .line 117
    new-instance v7, Lvu1;

    .line 118
    .line 119
    sub-long/2addr v9, v2

    .line 120
    iget-object v0, v1, Lk11;->p:Lor8;

    .line 121
    .line 122
    if-eqz v0, :cond_6

    .line 123
    .line 124
    iget-object v6, v0, Lor8;->a:Lpx;

    .line 125
    .line 126
    :cond_6
    move-object v12, v6

    .line 127
    iget-object v0, v1, Lk11;->y:Ljava/util/LinkedHashSet;

    .line 128
    .line 129
    invoke-static {v0}, Li32;->D1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 130
    .line 131
    .line 132
    move-result-object v13

    .line 133
    iget-object v0, v5, Le11;->j:Ljava/lang/Object;

    .line 134
    .line 135
    move-object v15, v0

    .line 136
    check-cast v15, Lfr8;

    .line 137
    .line 138
    iget-object v11, v1, Lk11;->i:Ljava/lang/String;

    .line 139
    .line 140
    invoke-direct/range {v7 .. v15}, Lvu1;-><init>(Llg6;JLjava/lang/String;Lpx;Ljava/util/Set;Lsv3;Lfr8;)V

    .line 141
    .line 142
    .line 143
    return-object v7

    .line 144
    :goto_4
    iget-object v1, v1, Lk11;->p:Lor8;

    .line 145
    .line 146
    if-eqz v1, :cond_7

    .line 147
    .line 148
    iget-object v1, v1, Lor8;->a:Lpx;

    .line 149
    .line 150
    goto :goto_5

    .line 151
    :cond_7
    move-object v1, v6

    .line 152
    :goto_5
    new-instance v2, Lgr8;

    .line 153
    .line 154
    if-eqz v1, :cond_8

    .line 155
    .line 156
    invoke-virtual {v1}, Lvq;->L()Lla1;

    .line 157
    .line 158
    .line 159
    move-result-object v6

    .line 160
    :cond_8
    invoke-direct {v2, v6}, Lgr8;-><init>(Lla1;)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v5, v2}, Le11;->f(Llr8;)V

    .line 164
    .line 165
    .line 166
    throw v0
.end method

.method public final k(Lif2;Lki3;Z)Ljava/lang/Object;
    .locals 9

    .line 1
    instance-of v0, p1, Lj11;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lj11;

    .line 7
    .line 8
    iget v1, v0, Lj11;->g:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lj11;->g:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lj11;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lj11;-><init>(Lk11;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lj11;->e:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lj11;->g:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    const/4 v3, 0x0

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    if-ne v1, v2, :cond_1

    .line 34
    .line 35
    iget-object p0, v0, Lj11;->d:Lk11;

    .line 36
    .line 37
    :try_start_0
    invoke-static {p1}, Lwe5;->F(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/CancellationException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Lm01; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lu88; {:try_start_0 .. :try_end_0} :catch_0
    .catch Le22; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lcg6; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    .line 39
    .line 40
    goto :goto_1

    .line 41
    :catch_0
    move-exception p0

    .line 42
    goto :goto_2

    .line 43
    :catch_1
    move-exception p1

    .line 44
    goto :goto_3

    .line 45
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 46
    .line 47
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-object v3

    .line 51
    :cond_2
    invoke-static {p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :try_start_1
    new-instance p1, Lix;

    .line 55
    .line 56
    invoke-direct {p1, p2, p0, p3, v3}, Lix;-><init>(Lki3;Lk11;ZLhf2;)V

    .line 57
    .line 58
    .line 59
    iput-object p0, v0, Lj11;->d:Lk11;

    .line 60
    .line 61
    iput v2, v0, Lj11;->g:I

    .line 62
    .line 63
    invoke-static {p1, v0}, Lv9a;->E(Lwv3;Lhf2;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p1
    :try_end_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Lm01; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lu88; {:try_start_1 .. :try_end_1} :catch_0
    .catch Le22; {:try_start_1 .. :try_end_1} :catch_3
    .catch Lcg6; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    sget-object p2, Ljg2;->a:Ljg2;

    .line 68
    .line 69
    if-ne p1, p2, :cond_3

    .line 70
    .line 71
    return-object p2

    .line 72
    :cond_3
    :goto_1
    :try_start_2
    new-instance p1, Leg6;

    .line 73
    .line 74
    sget-object p2, Ll01;->Companion:Lk01;

    .line 75
    .line 76
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    new-instance p2, Ll01;

    .line 80
    .line 81
    const/4 p3, 0x0

    .line 82
    invoke-direct {p2, p3}, Ll01;-><init>(I)V

    .line 83
    .line 84
    .line 85
    sget-object p3, Lxz0;->a:Lxz0;

    .line 86
    .line 87
    invoke-direct {p1, p2, p3}, Leg6;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Lm01; {:try_start_2 .. :try_end_2} :catch_1
    .catch Lu88; {:try_start_2 .. :try_end_2} :catch_0
    .catch Le22; {:try_start_2 .. :try_end_2} :catch_3
    .catch Lcg6; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 88
    .line 89
    .line 90
    return-object p1

    .line 91
    :catchall_0
    move-exception p0

    .line 92
    new-instance p1, Lhg6;

    .line 93
    .line 94
    invoke-direct {p1, p0}, Lhg6;-><init>(Ljava/lang/Throwable;)V

    .line 95
    .line 96
    .line 97
    goto/16 :goto_6

    .line 98
    .line 99
    :catch_2
    move-exception p0

    .line 100
    new-instance p1, Lgg6;

    .line 101
    .line 102
    invoke-direct {p1, p0}, Lgg6;-><init>(Lcg6;)V

    .line 103
    .line 104
    .line 105
    goto/16 :goto_6

    .line 106
    .line 107
    :catch_3
    move-exception p0

    .line 108
    new-instance p1, Lgg6;

    .line 109
    .line 110
    new-instance p2, Lvf6;

    .line 111
    .line 112
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p3

    .line 116
    invoke-direct {p2, p3, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 117
    .line 118
    .line 119
    invoke-direct {p1, p2}, Lgg6;-><init>(Lcg6;)V

    .line 120
    .line 121
    .line 122
    goto/16 :goto_6

    .line 123
    .line 124
    :goto_2
    new-instance p1, Ljg6;

    .line 125
    .line 126
    invoke-direct {p1, p0, v3, v3}, Ljg6;-><init>(Lu88;Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    goto/16 :goto_6

    .line 130
    .line 131
    :goto_3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    iget-object p0, p1, Lm01;->a:Lg98;

    .line 135
    .line 136
    iget-object p1, p1, Lm01;->b:La98;

    .line 137
    .line 138
    if-nez p0, :cond_4

    .line 139
    .line 140
    new-instance p0, Lkg6;

    .line 141
    .line 142
    iget-object p2, p1, La98;->c:Ljava/lang/String;

    .line 143
    .line 144
    iget-object p1, p1, La98;->d:Ljava/lang/String;

    .line 145
    .line 146
    invoke-direct {p0, p2, p1}, Lkg6;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    :goto_4
    move-object p1, p0

    .line 150
    goto/16 :goto_6

    .line 151
    .line 152
    :cond_4
    iget-object p2, p0, Lg98;->c:Lev4;

    .line 153
    .line 154
    iget-object p3, p0, Lg98;->a:Lh88;

    .line 155
    .line 156
    iget-object v0, p1, La98;->a:Ljava/lang/String;

    .line 157
    .line 158
    iget-object v1, p1, La98;->d:Ljava/lang/String;

    .line 159
    .line 160
    iget-object v2, p1, La98;->c:Ljava/lang/String;

    .line 161
    .line 162
    invoke-interface {p3}, Lh88;->getValue()I

    .line 163
    .line 164
    .line 165
    move-result v4

    .line 166
    iget-object v5, p1, La98;->e:Ljava/lang/String;

    .line 167
    .line 168
    iget-object v6, p1, La98;->b:Ljava/lang/String;

    .line 169
    .line 170
    const-string v7, "http_request_path"

    .line 171
    .line 172
    const-string v8, "http_biz_code"

    .line 173
    .line 174
    invoke-static {v7, v4, v0, v8}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    const-string v4, "http_trace_id"

    .line 179
    .line 180
    invoke-virtual {v0, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 181
    .line 182
    .line 183
    const-string v4, "cf_ray_id"

    .line 184
    .line 185
    invoke-virtual {v0, v4, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 186
    .line 187
    .line 188
    const-string v4, "hwc_ray"

    .line 189
    .line 190
    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 191
    .line 192
    .line 193
    const-string v4, "http_status_code"

    .line 194
    .line 195
    const/16 v5, 0xc8

    .line 196
    .line 197
    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 198
    .line 199
    .line 200
    const-string v4, "http_client_trace_id"

    .line 201
    .line 202
    invoke-virtual {v0, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 203
    .line 204
    .line 205
    sget-object v4, Ldw;->a:Lnqa;

    .line 206
    .line 207
    const-string v5, "http_request_biz_failure"

    .line 208
    .line 209
    invoke-virtual {v4, v5, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 210
    .line 211
    .line 212
    :try_start_3
    move-object v0, p3

    .line 213
    check-cast v0, Ll01;

    .line 214
    .line 215
    iget v0, v0, Ll01;->a:I

    .line 216
    .line 217
    sget-object v4, Ll01;->Companion:Lk01;

    .line 218
    .line 219
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 220
    .line 221
    .line 222
    const/16 v4, 0x16

    .line 223
    .line 224
    if-ne v0, v4, :cond_5

    .line 225
    .line 226
    sget-object p0, Low4;->a:Lew4;

    .line 227
    .line 228
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 229
    .line 230
    .line 231
    sget-object v0, Lnx;->Companion:Llx;

    .line 232
    .line 233
    invoke-virtual {v0}, Llx;->serializer()Lv35;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    check-cast v0, Lv35;

    .line 238
    .line 239
    invoke-virtual {p0, v0, p2}, Lfu4;->a(Lv35;Lev4;)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object p0

    .line 243
    check-cast p0, Lnx;

    .line 244
    .line 245
    new-instance p2, Leg6;

    .line 246
    .line 247
    new-instance v0, Lvz0;

    .line 248
    .line 249
    invoke-direct {v0, p0}, Lvz0;-><init>(Lnx;)V

    .line 250
    .line 251
    .line 252
    invoke-direct {p2, p3, v0}, Leg6;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    :goto_5
    move-object p1, p2

    .line 256
    goto :goto_6

    .line 257
    :cond_5
    const/4 v4, 0x5

    .line 258
    if-ne v0, v4, :cond_6

    .line 259
    .line 260
    sget-object p0, Low4;->a:Lew4;

    .line 261
    .line 262
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 263
    .line 264
    .line 265
    sget-object v0, Lx01;->Companion:Lw01;

    .line 266
    .line 267
    invoke-virtual {v0}, Lw01;->serializer()Lv35;

    .line 268
    .line 269
    .line 270
    move-result-object v0

    .line 271
    check-cast v0, Lv35;

    .line 272
    .line 273
    invoke-virtual {p0, v0, p2}, Lfu4;->a(Lv35;Lev4;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object p0

    .line 277
    check-cast p0, Lx01;

    .line 278
    .line 279
    new-instance p2, Leg6;

    .line 280
    .line 281
    new-instance v0, Lwz0;

    .line 282
    .line 283
    invoke-direct {v0, p0}, Lwz0;-><init>(Lx01;)V

    .line 284
    .line 285
    .line 286
    invoke-direct {p2, p3, v0}, Leg6;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 287
    .line 288
    .line 289
    goto :goto_5

    .line 290
    :cond_6
    new-instance p2, Lig6;

    .line 291
    .line 292
    iget-object p0, p0, Lg98;->b:Ljava/lang/String;

    .line 293
    .line 294
    invoke-direct {p2, p3, p0, v3}, Lig6;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_4

    .line 295
    .line 296
    .line 297
    goto :goto_5

    .line 298
    :catch_4
    const-string p0, ""

    .line 299
    .line 300
    invoke-static {p1, p0}, Lfh6;->S(La98;Ljava/lang/String;)V

    .line 301
    .line 302
    .line 303
    new-instance p0, Lkg6;

    .line 304
    .line 305
    invoke-direct {p0, v2, v1}, Lkg6;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    goto/16 :goto_4

    .line 309
    .line 310
    :catch_5
    move-exception p0

    .line 311
    new-instance p1, Lgg6;

    .line 312
    .line 313
    new-instance p2, Lvf6;

    .line 314
    .line 315
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object p3

    .line 319
    invoke-direct {p2, p3, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 320
    .line 321
    .line 322
    invoke-direct {p1, p2}, Lgg6;-><init>(Lcg6;)V

    .line 323
    .line 324
    .line 325
    :goto_6
    return-object p1
.end method

.method public final bridge y()Lcj;
    .locals 0

    .line 1
    invoke-static {}, Ltga;->I()Lcj;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
