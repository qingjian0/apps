.class public final Lap9;
.super Ljava/lang/Object;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"


# instance fields
.field public final a:Lo90;


# direct methods
.method public constructor <init>(Lo90;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lap9;->a:Lo90;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Lif2;)Ljava/lang/Object;
    .locals 6

    .line 1
    instance-of v0, p2, Lxo9;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lxo9;

    .line 7
    .line 8
    iget v1, v0, Lxo9;->f:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lxo9;->f:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lxo9;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lxo9;-><init>(Lap9;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lxo9;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lxo9;->f:I

    .line 28
    .line 29
    const/4 v2, 0x2

    .line 30
    const/4 v3, 0x1

    .line 31
    const/4 v4, 0x0

    .line 32
    sget-object v5, Ljg2;->a:Ljg2;

    .line 33
    .line 34
    if-eqz v1, :cond_3

    .line 35
    .line 36
    if-eq v1, v3, :cond_2

    .line 37
    .line 38
    if-ne v1, v2, :cond_1

    .line 39
    .line 40
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_3

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v4

    .line 50
    :cond_2
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    goto :goto_1

    .line 54
    :cond_3
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iput v3, v0, Lxo9;->f:I

    .line 58
    .line 59
    invoke-virtual {p0, p1, v0}, Lap9;->b(Ljava/lang/String;Lif2;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    if-ne p2, v5, :cond_4

    .line 64
    .line 65
    goto :goto_2

    .line 66
    :cond_4
    :goto_1
    check-cast p2, Ln88;

    .line 67
    .line 68
    if-nez p2, :cond_5

    .line 69
    .line 70
    return-object v4

    .line 71
    :cond_5
    iput v2, v0, Lxo9;->f:I

    .line 72
    .line 73
    invoke-virtual {p0, p2, v0}, Lap9;->c(Ln88;Lif2;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    if-ne p2, v5, :cond_6

    .line 78
    .line 79
    :goto_2
    return-object v5

    .line 80
    :cond_6
    :goto_3
    check-cast p2, Lbx4;

    .line 81
    .line 82
    sget-object p0, Low4;->a:Lew4;

    .line 83
    .line 84
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    sget-object p1, Lbx4;->Companion:Lax4;

    .line 88
    .line 89
    invoke-virtual {p1}, Lax4;->serializer()Lv35;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    check-cast p1, Lv35;

    .line 94
    .line 95
    invoke-virtual {p0, p1, p2}, Lfu4;->c(Lv35;Ljava/lang/Object;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    invoke-static {p0}, Lgf0;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object p0

    .line 103
    return-object p0
.end method

.method public final b(Ljava/lang/String;Lif2;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lyo9;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lyo9;

    .line 7
    .line 8
    iget v1, v0, Lyo9;->f:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lyo9;->f:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lyo9;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lyo9;-><init>(Lap9;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lyo9;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lyo9;->f:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    const/4 v3, 0x0

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    if-ne v1, v2, :cond_1

    .line 34
    .line 35
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 40
    .line 41
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v3

    .line 45
    :cond_2
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    iput v2, v0, Lyo9;->f:I

    .line 49
    .line 50
    iget-object p0, p0, Lap9;->a:Lo90;

    .line 51
    .line 52
    iget-object p0, p0, Lo90;->e:Lj90;

    .line 53
    .line 54
    iget-object p2, p0, Lj90;->a:Lcg2;

    .line 55
    .line 56
    new-instance v1, Li90;

    .line 57
    .line 58
    const/4 v2, 0x0

    .line 59
    invoke-direct {v1, p0, p1, v3, v2}, Li90;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 60
    .line 61
    .line 62
    invoke-static {p2, v1, v0}, Lv9a;->f0(Lag2;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p2

    .line 66
    sget-object p0, Ljg2;->a:Ljg2;

    .line 67
    .line 68
    if-ne p2, p0, :cond_3

    .line 69
    .line 70
    return-object p0

    .line 71
    :cond_3
    :goto_1
    check-cast p2, Llg6;

    .line 72
    .line 73
    instance-of p0, p2, Leg6;

    .line 74
    .line 75
    if-eqz p0, :cond_4

    .line 76
    .line 77
    check-cast p2, Leg6;

    .line 78
    .line 79
    iget-object p0, p2, Leg6;->b:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast p0, Ll34;

    .line 82
    .line 83
    iget-object p0, p0, Ll34;->a:Ln88;

    .line 84
    .line 85
    return-object p0

    .line 86
    :cond_4
    return-object v3
.end method

.method public final c(Ln88;Lif2;)Ljava/lang/Object;
    .locals 13

    .line 1
    instance-of v0, p2, Lzo9;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lzo9;

    .line 7
    .line 8
    iget v1, v0, Lzo9;->g:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lzo9;->g:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lzo9;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lzo9;-><init>(Lap9;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p0, v0, Lzo9;->e:Ljava/lang/Object;

    .line 26
    .line 27
    iget p2, v0, Lzo9;->g:I

    .line 28
    .line 29
    const/4 v1, 0x2

    .line 30
    const/4 v2, 0x0

    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz p2, :cond_2

    .line 33
    .line 34
    if-ne p2, v3, :cond_1

    .line 35
    .line 36
    iget-object p1, v0, Lzo9;->d:Ln88;

    .line 37
    .line 38
    invoke-static {p0}, Lwe5;->F(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 43
    .line 44
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-object v2

    .line 48
    :cond_2
    invoke-static {p0}, Lwe5;->F(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iget-object p0, p1, Ln88;->a:Ljava/lang/String;

    .line 52
    .line 53
    sget-object p2, Loz0;->Companion:Lnz0;

    .line 54
    .line 55
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    const-string p2, "DeepSeekHashV1"

    .line 59
    .line 60
    invoke-static {p0, p2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result p0

    .line 64
    if-eqz p0, :cond_3

    .line 65
    .line 66
    new-instance v4, Lec0;

    .line 67
    .line 68
    sget-object v6, Lcom/deepseek/crypto/PowCalculator;->a:Lcom/deepseek/crypto/PowCalculator;

    .line 69
    .line 70
    const/4 v11, 0x0

    .line 71
    const/4 v12, 0x4

    .line 72
    const/4 v5, 0x3

    .line 73
    const-class v7, Lcom/deepseek/crypto/PowCalculator;

    .line 74
    .line 75
    const-string v8, "calculateDeepSeekHashV1Pow"

    .line 76
    .line 77
    const-string v9, "calculateDeepSeekHashV1Pow(Ljava/lang/String;Ljava/lang/String;J)J"

    .line 78
    .line 79
    const/4 v10, 0x0

    .line 80
    invoke-direct/range {v4 .. v12}, Lec0;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_3
    new-instance v4, Lh72;

    .line 85
    .line 86
    const/4 p0, 0x3

    .line 87
    invoke-direct {v4, p0}, Lh72;-><init>(I)V

    .line 88
    .line 89
    .line 90
    :goto_1
    sget-object p0, Ldz2;->a:Lyr2;

    .line 91
    .line 92
    new-instance p2, Ldc0;

    .line 93
    .line 94
    invoke-direct {p2, v4, p1, v2, v1}, Ldc0;-><init>(Lxv3;Ln88;Lhf2;I)V

    .line 95
    .line 96
    .line 97
    iput-object p1, v0, Lzo9;->d:Ln88;

    .line 98
    .line 99
    iput v3, v0, Lzo9;->g:I

    .line 100
    .line 101
    invoke-static {p0, p2, v0}, Lv9a;->f0(Lag2;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    sget-object p2, Ljg2;->a:Ljg2;

    .line 106
    .line 107
    if-ne p0, p2, :cond_4

    .line 108
    .line 109
    return-object p2

    .line 110
    :cond_4
    :goto_2
    check-cast p0, Ljava/lang/Number;

    .line 111
    .line 112
    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    .line 113
    .line 114
    .line 115
    move-result-wide v4

    .line 116
    new-instance p0, Lbx4;

    .line 117
    .line 118
    iget-object p1, p1, Ln88;->c:Ljava/lang/String;

    .line 119
    .line 120
    sget-object p2, Lfv4;->a:Lnl4;

    .line 121
    .line 122
    if-nez p1, :cond_5

    .line 123
    .line 124
    sget-object p1, Lyw4;->INSTANCE:Lyw4;

    .line 125
    .line 126
    goto :goto_3

    .line 127
    :cond_5
    new-instance p2, Lpw4;

    .line 128
    .line 129
    invoke-direct {p2, p1, v3}, Lpw4;-><init>(Ljava/lang/Object;Z)V

    .line 130
    .line 131
    .line 132
    move-object p1, p2

    .line 133
    :goto_3
    new-instance p2, Lnu6;

    .line 134
    .line 135
    const-string v0, "salt"

    .line 136
    .line 137
    invoke-direct {p2, v0, p1}, Lnu6;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    new-instance p1, Ljava/lang/Long;

    .line 141
    .line 142
    invoke-direct {p1, v4, v5}, Ljava/lang/Long;-><init>(J)V

    .line 143
    .line 144
    .line 145
    new-instance v0, Lpw4;

    .line 146
    .line 147
    const/4 v2, 0x0

    .line 148
    invoke-direct {v0, p1, v2}, Lpw4;-><init>(Ljava/lang/Object;Z)V

    .line 149
    .line 150
    .line 151
    new-instance p1, Lnu6;

    .line 152
    .line 153
    const-string v4, "answer"

    .line 154
    .line 155
    invoke-direct {p1, v4, v0}, Lnu6;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    new-array v0, v1, [Lnu6;

    .line 159
    .line 160
    aput-object p2, v0, v2

    .line 161
    .line 162
    aput-object p1, v0, v3

    .line 163
    .line 164
    invoke-static {v0}, Llq5;->p1([Lnu6;)Ljava/util/Map;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    invoke-direct {p0, p1}, Lbx4;-><init>(Ljava/util/Map;)V

    .line 169
    .line 170
    .line 171
    return-object p0
.end method
