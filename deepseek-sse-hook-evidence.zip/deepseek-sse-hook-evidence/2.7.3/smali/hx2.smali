.class public final Lhx2;
.super Ljava/lang/Object;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lk55;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcd4;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lhx2;->a:I

    .line 62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lhx2;->d:Ljava/lang/Object;

    .line 63
    new-instance p1, Liz0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Liz0;-><init>(Lhx2;I)V

    const/4 v0, 0x1

    invoke-static {v0, p1}, Lyb5;->J(ILhv3;)Lta5;

    move-result-object p1

    .line 64
    iput-object p1, p0, Lhx2;->b:Ljava/lang/Object;

    .line 65
    new-instance p1, Liz0;

    invoke-direct {p1, p0, v0}, Liz0;-><init>(Lhx2;I)V

    invoke-static {v0, p1}, Lyb5;->J(ILhv3;)Lta5;

    move-result-object p1

    .line 66
    iput-object p1, p0, Lhx2;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lig2;)V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lhx2;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lgx2;

    .line 8
    .line 9
    invoke-direct {v1, p0, v0}, Lgx2;-><init>(Lhx2;I)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-static {v2, v1}, Lyb5;->J(ILhv3;)Lta5;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    iput-object v1, p0, Lhx2;->b:Ljava/lang/Object;

    .line 18
    .line 19
    new-instance v1, Lgx2;

    .line 20
    .line 21
    invoke-direct {v1, p0, v2}, Lgx2;-><init>(Lhx2;I)V

    .line 22
    .line 23
    .line 24
    invoke-static {v2, v1}, Lyb5;->J(ILhv3;)Lta5;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    iput-object v1, p0, Lhx2;->c:Ljava/lang/Object;

    .line 29
    .line 30
    new-instance v1, Lgx2;

    .line 31
    .line 32
    const/4 v3, 0x2

    .line 33
    invoke-direct {v1, p0, v3}, Lgx2;-><init>(Lhx2;I)V

    .line 34
    .line 35
    .line 36
    invoke-static {v2, v1}, Lyb5;->J(ILhv3;)Lta5;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    iput-object v1, p0, Lhx2;->d:Ljava/lang/Object;

    .line 41
    .line 42
    sget-object v1, Ldz2;->a:Lyr2;

    .line 43
    .line 44
    sget-object v1, Ler2;->c:Ler2;

    .line 45
    .line 46
    new-instance v2, Li3;

    .line 47
    .line 48
    const/16 v4, 0x14

    .line 49
    .line 50
    const/4 v5, 0x0

    .line 51
    invoke-direct {v2, p0, v5, v4}, Li3;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 52
    .line 53
    .line 54
    invoke-static {p1, v1, v0, v2, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public constructor <init>(Lig2;Lbj9;Lf21;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lhx2;->a:I

    .line 58
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    iput-object p1, p0, Lhx2;->b:Ljava/lang/Object;

    .line 60
    iput-object p2, p0, Lhx2;->c:Ljava/lang/Object;

    .line 61
    iput-object p3, p0, Lhx2;->d:Ljava/lang/Object;

    return-void
.end method

.method public static final a(Lhx2;Ljava/lang/String;Lhf2;)Ljava/lang/Object;
    .locals 8

    .line 1
    instance-of v0, p2, Lfx2;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lfx2;

    .line 7
    .line 8
    iget v1, v0, Lfx2;->f:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lfx2;->f:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lfx2;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lfx2;-><init>(Lhx2;Lhf2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lfx2;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lfx2;->f:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    const/4 v4, 0x0

    .line 32
    const-string v5, "DeviceInfoReportManager"

    .line 33
    .line 34
    sget-object v6, Llp9;->a:Llp9;

    .line 35
    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    if-ne v1, v3, :cond_1

    .line 39
    .line 40
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v4

    .line 50
    :cond_2
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    if-eqz p1, :cond_8

    .line 54
    .line 55
    invoke-static {p1}, Llx8;->i0(Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result p2

    .line 59
    if-eqz p2, :cond_3

    .line 60
    .line 61
    goto :goto_2

    .line 62
    :cond_3
    iget-object p2, p0, Lhx2;->d:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p2, Lta5;

    .line 65
    .line 66
    invoke-interface {p2}, Lta5;->getValue()Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    check-cast p2, Lex2;

    .line 71
    .line 72
    invoke-virtual {p2}, Lex2;->b()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object p2

    .line 76
    invoke-static {p2}, Llx8;->i0(Ljava/lang/CharSequence;)Z

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    if-eqz v1, :cond_4

    .line 81
    .line 82
    new-array p0, v3, [Ljava/lang/Object;

    .line 83
    .line 84
    const-string p1, "reportDeviceInfo: deviceId is empty, skip"

    .line 85
    .line 86
    aput-object p1, p0, v2

    .line 87
    .line 88
    invoke-static {}, Lv9a;->s()V

    .line 89
    .line 90
    .line 91
    sget-object p1, Lv9a;->a:Lbua;

    .line 92
    .line 93
    const/4 p2, 0x6

    .line 94
    invoke-virtual {p1, p2, v5, p0}, Lbua;->u1(ILjava/lang/String;[Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    return-object v6

    .line 98
    :cond_4
    iget-object p0, p0, Lhx2;->c:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast p0, Lta5;

    .line 101
    .line 102
    invoke-interface {p0}, Lta5;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    check-cast p0, Lo90;

    .line 107
    .line 108
    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 109
    .line 110
    iput v3, v0, Lfx2;->f:I

    .line 111
    .line 112
    iget-object p0, p0, Lo90;->f:Ln90;

    .line 113
    .line 114
    iget-object v1, p0, Ln90;->a:Lcg2;

    .line 115
    .line 116
    new-instance v7, Lm90;

    .line 117
    .line 118
    invoke-direct {v7, p0, p1, p2, v4}, Lm90;-><init>(Ln90;Ljava/lang/String;Ljava/lang/String;Lhf2;)V

    .line 119
    .line 120
    .line 121
    invoke-static {v1, v7, v0}, Lv9a;->f0(Lag2;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object p2

    .line 125
    sget-object p0, Ljg2;->a:Ljg2;

    .line 126
    .line 127
    if-ne p2, p0, :cond_5

    .line 128
    .line 129
    return-object p0

    .line 130
    :cond_5
    :goto_1
    check-cast p2, Llg6;

    .line 131
    .line 132
    instance-of p0, p2, Leg6;

    .line 133
    .line 134
    if-eqz p0, :cond_7

    .line 135
    .line 136
    check-cast p2, Leg6;

    .line 137
    .line 138
    iget-object p0, p2, Leg6;->b:Ljava/lang/Object;

    .line 139
    .line 140
    check-cast p0, Liw1;

    .line 141
    .line 142
    if-eqz p0, :cond_6

    .line 143
    .line 144
    iget-object v4, p0, Liw1;->a:Llw1;

    .line 145
    .line 146
    :cond_6
    if-eqz v4, :cond_8

    .line 147
    .line 148
    new-array p0, v3, [Ljava/lang/Object;

    .line 149
    .line 150
    const-string p1, "reportDeviceInfo: rotate returned, will replace token in phase 2"

    .line 151
    .line 152
    aput-object p1, p0, v2

    .line 153
    .line 154
    invoke-static {v5, p0}, Lv9a;->G(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    return-object v6

    .line 158
    :cond_7
    new-instance p0, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    const-string p1, "reportDeviceInfo failed: "

    .line 161
    .line 162
    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 169
    .line 170
    .line 171
    move-result-object p0

    .line 172
    new-array p1, v3, [Ljava/lang/Object;

    .line 173
    .line 174
    aput-object p0, p1, v2

    .line 175
    .line 176
    invoke-static {v5, p1}, Lv9a;->G(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_8
    :goto_2
    return-object v6
.end method


# virtual methods
.method public b()Lfd0;
    .locals 5

    .line 1
    new-instance v0, Lfd0;

    .line 2
    .line 3
    iget-object v1, p0, Lhx2;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lig2;

    .line 6
    .line 7
    iget-object v2, p0, Lhx2;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Lbj9;

    .line 10
    .line 11
    new-instance v3, Lj;

    .line 12
    .line 13
    const/16 v4, 0xc

    .line 14
    .line 15
    invoke-direct {v3, v4, p0}, Lj;-><init>(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object p0, p0, Lhx2;->d:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Lf21;

    .line 21
    .line 22
    invoke-direct {v0, v1, v2, v3, p0}, Lfd0;-><init>(Lig2;Lbj9;Lj;Lf21;)V

    .line 23
    .line 24
    .line 25
    return-object v0
.end method

.method public c(Lrz0;Lhf2;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object p0, p0, Lhx2;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lcd4;

    .line 4
    .line 5
    new-instance v0, Lhz0;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v0, p1, v2, v1}, Lhz0;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 10
    .line 11
    .line 12
    sget-object p1, Lan7;->a:Lbn7;

    .line 13
    .line 14
    const-class v1, Lk88;

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :try_start_0
    sget-object v3, Ld45;->c:Ld45;

    .line 21
    .line 22
    const-class v3, Lg98;

    .line 23
    .line 24
    const-class v4, Lx88;

    .line 25
    .line 26
    invoke-static {v4}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-static {v4}, Llx0;->N(Lw35;)Ld45;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-static {v3, v4}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3}, Llx0;->N(Lw35;)Ld45;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-static {v1, v3}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    :catchall_0
    new-instance v1, Lsl9;

    .line 47
    .line 48
    invoke-direct {v1, p1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v1, v0, p2}, Lcd4;->f(Lsl9;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public d(Lqra;Lhf2;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object p0, p0, Lhx2;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lcd4;

    .line 4
    .line 5
    new-instance v0, Lhz0;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v0, p1, v2, v1}, Lhz0;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 10
    .line 11
    .line 12
    sget-object p1, Lan7;->a:Lbn7;

    .line 13
    .line 14
    const-class v1, Lk88;

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :try_start_0
    sget-object v3, Ld45;->c:Ld45;

    .line 21
    .line 22
    const-class v3, Lg98;

    .line 23
    .line 24
    const-class v4, Lk74;

    .line 25
    .line 26
    invoke-static {v4}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-static {v4}, Llx0;->N(Lw35;)Ld45;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-static {v3, v4}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3}, Llx0;->N(Lw35;)Ld45;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-static {v1, v3}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    :catchall_0
    new-instance v1, Lsl9;

    .line 47
    .line 48
    invoke-direct {v1, p1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v1, v0, p2}, Lcd4;->f(Lsl9;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public e(Loy5;Lhf2;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object p0, p0, Lhx2;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lcd4;

    .line 4
    .line 5
    new-instance v0, Lhz0;

    .line 6
    .line 7
    const/4 v1, 0x2

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v0, p1, v2, v1}, Lhz0;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 10
    .line 11
    .line 12
    sget-object p1, Lan7;->a:Lbn7;

    .line 13
    .line 14
    const-class v1, Lk88;

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :try_start_0
    sget-object v3, Ld45;->c:Ld45;

    .line 21
    .line 22
    const-class v3, Lg98;

    .line 23
    .line 24
    const-class v4, Lly5;

    .line 25
    .line 26
    invoke-static {v4}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-static {v4}, Llx0;->N(Lw35;)Ld45;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-static {v3, v4}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3}, Llx0;->N(Lw35;)Ld45;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-static {v1, v3}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    :catchall_0
    new-instance v1, Lsl9;

    .line 47
    .line 48
    invoke-direct {v1, p1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v1, v0, p2}, Lcd4;->f(Lsl9;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public f(Lvt1;Lwt1;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object p0, p0, Lhx2;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lcd4;

    .line 4
    .line 5
    new-instance v0, Lhz0;

    .line 6
    .line 7
    const/4 v1, 0x3

    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v0, p1, v2, v1}, Lhz0;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 10
    .line 11
    .line 12
    sget-object p1, Lan7;->a:Lbn7;

    .line 13
    .line 14
    const-class v1, Lk88;

    .line 15
    .line 16
    invoke-virtual {p1, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :try_start_0
    sget-object v3, Ld45;->c:Ld45;

    .line 21
    .line 22
    const-class v3, Lg98;

    .line 23
    .line 24
    const-class v4, Lx88;

    .line 25
    .line 26
    invoke-static {v4}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-static {v4}, Llx0;->N(Lw35;)Ld45;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-static {v3, v4}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-static {v3}, Llx0;->N(Lw35;)Ld45;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-static {v1, v3}, Lan7;->d(Ljava/lang/Class;Ld45;)Lw35;

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    :catchall_0
    new-instance v1, Lsl9;

    .line 47
    .line 48
    invoke-direct {v1, p1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v1, v0, p2}, Lcd4;->f(Lsl9;Lwv3;Lhf2;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public g(Lu01;Ljava/lang/Long;)Lz40;
    .locals 9

    .line 1
    iget-object v0, p0, Lhx2;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lta5;

    .line 4
    .line 5
    instance-of v1, p1, Le41;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    if-eqz v1, :cond_3

    .line 9
    .line 10
    sget-object v1, Lan7;->a:Lbn7;

    .line 11
    .line 12
    const-class v2, Le41;

    .line 13
    .line 14
    invoke-virtual {v1, v2}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    :try_start_0
    invoke-static {v2}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 19
    .line 20
    .line 21
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    goto :goto_0

    .line 23
    :catchall_0
    move-object v2, v6

    .line 24
    :goto_0
    new-instance v3, Lsl9;

    .line 25
    .line 26
    invoke-direct {v3, v1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 27
    .line 28
    .line 29
    move-object v1, p1

    .line 30
    check-cast v1, Le41;

    .line 31
    .line 32
    iget-object v1, v1, Le41;->k:Ljava/lang/String;

    .line 33
    .line 34
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Lh02;

    .line 39
    .line 40
    iget-object v2, v0, Lh02;->o:Lj$/util/concurrent/ConcurrentHashMap;

    .line 41
    .line 42
    iget-object v4, v0, Lh02;->q:Lcom/tencent/mmkv/MMKV;

    .line 43
    .line 44
    const-string v5, "kv_settings_completion_request_timeout_ms"

    .line 45
    .line 46
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->contains(Ljava/lang/String;)Z

    .line 47
    .line 48
    .line 49
    move-result v7

    .line 50
    if-eqz v7, :cond_0

    .line 51
    .line 52
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;)I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    goto :goto_1

    .line 57
    :cond_0
    const-string v5, "completion_request_timeout_ms"

    .line 58
    .line 59
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    if-eqz v7, :cond_1

    .line 64
    .line 65
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Ljava/lang/Integer;

    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    goto :goto_1

    .line 76
    :cond_1
    sget v7, Lf02;->i:I

    .line 77
    .line 78
    const-string v8, "kv_remote_settings_completion_request_timeout_ms"

    .line 79
    .line 80
    invoke-virtual {v4, v7, v8}, Lcom/tencent/mmkv/MMKV;->f(ILjava/lang/String;)I

    .line 81
    .line 82
    .line 83
    move-result v7

    .line 84
    const-string v8, "kv_remote_settings_id_completion_request_timeout_ms"

    .line 85
    .line 86
    invoke-static {v7, v2, v5, v4, v8}, Lgm4;->x(ILj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;Ljava/lang/String;)Z

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eqz v2, :cond_2

    .line 91
    .line 92
    iget-object v0, v0, Lh02;->p:Lj$/util/concurrent/ConcurrentHashMap;

    .line 93
    .line 94
    invoke-static {v4, v8, v0, v5}, Lrj2;->F(Lcom/tencent/mmkv/MMKV;Ljava/lang/String;Lj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    :cond_2
    move v0, v7

    .line 98
    :goto_1
    const-string v2, "/api/v0/chat/completion"

    .line 99
    .line 100
    :goto_2
    move-object v5, v2

    .line 101
    goto/16 :goto_b

    .line 102
    .line 103
    :cond_3
    instance-of v1, p1, Lhj1;

    .line 104
    .line 105
    if-eqz v1, :cond_7

    .line 106
    .line 107
    sget-object v1, Lan7;->a:Lbn7;

    .line 108
    .line 109
    const-class v2, Lhj1;

    .line 110
    .line 111
    invoke-virtual {v1, v2}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    :try_start_1
    invoke-static {v2}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 116
    .line 117
    .line 118
    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 119
    goto :goto_3

    .line 120
    :catchall_1
    move-object v2, v6

    .line 121
    :goto_3
    new-instance v3, Lsl9;

    .line 122
    .line 123
    invoke-direct {v3, v1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 124
    .line 125
    .line 126
    move-object v1, p1

    .line 127
    check-cast v1, Lhj1;

    .line 128
    .line 129
    iget-object v1, v1, Lhj1;->f:Ljava/lang/String;

    .line 130
    .line 131
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Lh02;

    .line 136
    .line 137
    iget-object v2, v0, Lh02;->o:Lj$/util/concurrent/ConcurrentHashMap;

    .line 138
    .line 139
    iget-object v4, v0, Lh02;->q:Lcom/tencent/mmkv/MMKV;

    .line 140
    .line 141
    const-string v5, "kv_settings_regenerate_request_timeout_ms"

    .line 142
    .line 143
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->contains(Ljava/lang/String;)Z

    .line 144
    .line 145
    .line 146
    move-result v7

    .line 147
    if-eqz v7, :cond_4

    .line 148
    .line 149
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;)I

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    goto :goto_4

    .line 154
    :cond_4
    const-string v5, "regenerate_request_timeout_ms"

    .line 155
    .line 156
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v7

    .line 160
    if-eqz v7, :cond_5

    .line 161
    .line 162
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    check-cast v0, Ljava/lang/Integer;

    .line 167
    .line 168
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    goto :goto_4

    .line 173
    :cond_5
    sget v7, Lf02;->j:I

    .line 174
    .line 175
    const-string v8, "kv_remote_settings_regenerate_request_timeout_ms"

    .line 176
    .line 177
    invoke-virtual {v4, v7, v8}, Lcom/tencent/mmkv/MMKV;->f(ILjava/lang/String;)I

    .line 178
    .line 179
    .line 180
    move-result v7

    .line 181
    const-string v8, "kv_remote_settings_id_regenerate_request_timeout_ms"

    .line 182
    .line 183
    invoke-static {v7, v2, v5, v4, v8}, Lgm4;->x(ILj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;Ljava/lang/String;)Z

    .line 184
    .line 185
    .line 186
    move-result v2

    .line 187
    if-eqz v2, :cond_6

    .line 188
    .line 189
    iget-object v0, v0, Lh02;->p:Lj$/util/concurrent/ConcurrentHashMap;

    .line 190
    .line 191
    invoke-static {v4, v8, v0, v5}, Lrj2;->F(Lcom/tencent/mmkv/MMKV;Ljava/lang/String;Lj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    :cond_6
    move v0, v7

    .line 195
    :goto_4
    const-string v2, "/api/v0/chat/regenerate"

    .line 196
    .line 197
    goto :goto_2

    .line 198
    :cond_7
    instance-of v1, p1, Lb31;

    .line 199
    .line 200
    if-eqz v1, :cond_b

    .line 201
    .line 202
    sget-object v1, Lan7;->a:Lbn7;

    .line 203
    .line 204
    const-class v2, Lb31;

    .line 205
    .line 206
    invoke-virtual {v1, v2}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 207
    .line 208
    .line 209
    move-result-object v1

    .line 210
    :try_start_2
    invoke-static {v2}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 211
    .line 212
    .line 213
    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 214
    goto :goto_5

    .line 215
    :catchall_2
    move-object v2, v6

    .line 216
    :goto_5
    new-instance v3, Lsl9;

    .line 217
    .line 218
    invoke-direct {v3, v1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 219
    .line 220
    .line 221
    move-object v1, p1

    .line 222
    check-cast v1, Lb31;

    .line 223
    .line 224
    iget-object v1, v1, Lb31;->d:Ljava/lang/String;

    .line 225
    .line 226
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    check-cast v0, Lh02;

    .line 231
    .line 232
    iget-object v2, v0, Lh02;->o:Lj$/util/concurrent/ConcurrentHashMap;

    .line 233
    .line 234
    iget-object v4, v0, Lh02;->q:Lcom/tencent/mmkv/MMKV;

    .line 235
    .line 236
    const-string v5, "kv_settings_continue_request_timeout_ms"

    .line 237
    .line 238
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->contains(Ljava/lang/String;)Z

    .line 239
    .line 240
    .line 241
    move-result v7

    .line 242
    if-eqz v7, :cond_8

    .line 243
    .line 244
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;)I

    .line 245
    .line 246
    .line 247
    move-result v0

    .line 248
    goto :goto_6

    .line 249
    :cond_8
    const-string v5, "continue_request_timeout_ms"

    .line 250
    .line 251
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 252
    .line 253
    .line 254
    move-result v7

    .line 255
    if-eqz v7, :cond_9

    .line 256
    .line 257
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v0

    .line 261
    check-cast v0, Ljava/lang/Integer;

    .line 262
    .line 263
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 264
    .line 265
    .line 266
    move-result v0

    .line 267
    goto :goto_6

    .line 268
    :cond_9
    sget v7, Lf02;->l:I

    .line 269
    .line 270
    const-string v8, "kv_remote_settings_continue_request_timeout_ms"

    .line 271
    .line 272
    invoke-virtual {v4, v7, v8}, Lcom/tencent/mmkv/MMKV;->f(ILjava/lang/String;)I

    .line 273
    .line 274
    .line 275
    move-result v7

    .line 276
    const-string v8, "kv_remote_settings_id_continue_request_timeout_ms"

    .line 277
    .line 278
    invoke-static {v7, v2, v5, v4, v8}, Lgm4;->x(ILj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;Ljava/lang/String;)Z

    .line 279
    .line 280
    .line 281
    move-result v2

    .line 282
    if-eqz v2, :cond_a

    .line 283
    .line 284
    iget-object v0, v0, Lh02;->p:Lj$/util/concurrent/ConcurrentHashMap;

    .line 285
    .line 286
    invoke-static {v4, v8, v0, v5}, Lrj2;->F(Lcom/tencent/mmkv/MMKV;Ljava/lang/String;Lj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;)V

    .line 287
    .line 288
    .line 289
    :cond_a
    move v0, v7

    .line 290
    :goto_6
    const-string v2, "/api/v0/chat/continue"

    .line 291
    .line 292
    goto/16 :goto_2

    .line 293
    .line 294
    :cond_b
    instance-of v1, p1, Lmj1;

    .line 295
    .line 296
    if-eqz v1, :cond_f

    .line 297
    .line 298
    sget-object v1, Lan7;->a:Lbn7;

    .line 299
    .line 300
    const-class v2, Lmj1;

    .line 301
    .line 302
    invoke-virtual {v1, v2}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    :try_start_3
    invoke-static {v2}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 307
    .line 308
    .line 309
    move-result-object v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 310
    goto :goto_7

    .line 311
    :catchall_3
    move-object v2, v6

    .line 312
    :goto_7
    new-instance v3, Lsl9;

    .line 313
    .line 314
    invoke-direct {v3, v1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 315
    .line 316
    .line 317
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    check-cast v0, Lh02;

    .line 322
    .line 323
    iget-object v1, v0, Lh02;->o:Lj$/util/concurrent/ConcurrentHashMap;

    .line 324
    .line 325
    iget-object v2, v0, Lh02;->q:Lcom/tencent/mmkv/MMKV;

    .line 326
    .line 327
    const-string v4, "kv_settings_resume_request_timeout_ms"

    .line 328
    .line 329
    invoke-virtual {v2, v4}, Lcom/tencent/mmkv/MMKV;->contains(Ljava/lang/String;)Z

    .line 330
    .line 331
    .line 332
    move-result v5

    .line 333
    if-eqz v5, :cond_c

    .line 334
    .line 335
    invoke-virtual {v2, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;)I

    .line 336
    .line 337
    .line 338
    move-result v0

    .line 339
    goto :goto_8

    .line 340
    :cond_c
    const-string v4, "resume_request_timeout_ms"

    .line 341
    .line 342
    invoke-virtual {v1, v4}, Lj$/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 343
    .line 344
    .line 345
    move-result v5

    .line 346
    if-eqz v5, :cond_d

    .line 347
    .line 348
    invoke-virtual {v1, v4}, Lj$/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object v0

    .line 352
    check-cast v0, Ljava/lang/Integer;

    .line 353
    .line 354
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 355
    .line 356
    .line 357
    move-result v0

    .line 358
    goto :goto_8

    .line 359
    :cond_d
    sget v5, Lf02;->m:I

    .line 360
    .line 361
    const-string v7, "kv_remote_settings_resume_request_timeout_ms"

    .line 362
    .line 363
    invoke-virtual {v2, v5, v7}, Lcom/tencent/mmkv/MMKV;->f(ILjava/lang/String;)I

    .line 364
    .line 365
    .line 366
    move-result v5

    .line 367
    const-string v7, "kv_remote_settings_id_resume_request_timeout_ms"

    .line 368
    .line 369
    invoke-static {v5, v1, v4, v2, v7}, Lgm4;->x(ILj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;Ljava/lang/String;)Z

    .line 370
    .line 371
    .line 372
    move-result v1

    .line 373
    if-eqz v1, :cond_e

    .line 374
    .line 375
    iget-object v0, v0, Lh02;->p:Lj$/util/concurrent/ConcurrentHashMap;

    .line 376
    .line 377
    invoke-static {v2, v7, v0, v4}, Lrj2;->F(Lcom/tencent/mmkv/MMKV;Ljava/lang/String;Lj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    :cond_e
    move v0, v5

    .line 381
    :goto_8
    const-string v2, "/api/v0/chat/resume_stream"

    .line 382
    .line 383
    move-object v5, v2

    .line 384
    move-object v1, v6

    .line 385
    goto :goto_b

    .line 386
    :cond_f
    instance-of v1, p1, Lf31;

    .line 387
    .line 388
    if-eqz v1, :cond_16

    .line 389
    .line 390
    sget-object v1, Lan7;->a:Lbn7;

    .line 391
    .line 392
    const-class v2, Lf31;

    .line 393
    .line 394
    invoke-virtual {v1, v2}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 395
    .line 396
    .line 397
    move-result-object v1

    .line 398
    :try_start_4
    invoke-static {v2}, Lan7;->c(Ljava/lang/Class;)Lw35;

    .line 399
    .line 400
    .line 401
    move-result-object v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .line 402
    goto :goto_9

    .line 403
    :catchall_4
    move-object v2, v6

    .line 404
    :goto_9
    new-instance v3, Lsl9;

    .line 405
    .line 406
    invoke-direct {v3, v1, v2}, Lsl9;-><init>(Lf15;Lw35;)V

    .line 407
    .line 408
    .line 409
    move-object v1, p1

    .line 410
    check-cast v1, Lf31;

    .line 411
    .line 412
    iget-object v1, v1, Lf31;->i:Ljava/lang/String;

    .line 413
    .line 414
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    check-cast v0, Lh02;

    .line 419
    .line 420
    iget-object v2, v0, Lh02;->o:Lj$/util/concurrent/ConcurrentHashMap;

    .line 421
    .line 422
    iget-object v4, v0, Lh02;->q:Lcom/tencent/mmkv/MMKV;

    .line 423
    .line 424
    const-string v5, "kv_settings_edit_request_timeout_ms"

    .line 425
    .line 426
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->contains(Ljava/lang/String;)Z

    .line 427
    .line 428
    .line 429
    move-result v7

    .line 430
    if-eqz v7, :cond_10

    .line 431
    .line 432
    invoke-virtual {v4, v5}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;)I

    .line 433
    .line 434
    .line 435
    move-result v0

    .line 436
    goto :goto_a

    .line 437
    :cond_10
    const-string v5, "edit_request_timeout_ms"

    .line 438
    .line 439
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    .line 440
    .line 441
    .line 442
    move-result v7

    .line 443
    if-eqz v7, :cond_11

    .line 444
    .line 445
    invoke-virtual {v2, v5}, Lj$/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 446
    .line 447
    .line 448
    move-result-object v0

    .line 449
    check-cast v0, Ljava/lang/Integer;

    .line 450
    .line 451
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 452
    .line 453
    .line 454
    move-result v0

    .line 455
    goto :goto_a

    .line 456
    :cond_11
    sget v7, Lf02;->k:I

    .line 457
    .line 458
    const-string v8, "kv_remote_settings_edit_request_timeout_ms"

    .line 459
    .line 460
    invoke-virtual {v4, v7, v8}, Lcom/tencent/mmkv/MMKV;->f(ILjava/lang/String;)I

    .line 461
    .line 462
    .line 463
    move-result v7

    .line 464
    const-string v8, "kv_remote_settings_id_edit_request_timeout_ms"

    .line 465
    .line 466
    invoke-static {v7, v2, v5, v4, v8}, Lgm4;->x(ILj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;Lcom/tencent/mmkv/MMKV;Ljava/lang/String;)Z

    .line 467
    .line 468
    .line 469
    move-result v2

    .line 470
    if-eqz v2, :cond_12

    .line 471
    .line 472
    iget-object v0, v0, Lh02;->p:Lj$/util/concurrent/ConcurrentHashMap;

    .line 473
    .line 474
    invoke-static {v4, v8, v0, v5}, Lrj2;->F(Lcom/tencent/mmkv/MMKV;Ljava/lang/String;Lj$/util/concurrent/ConcurrentHashMap;Ljava/lang/String;)V

    .line 475
    .line 476
    .line 477
    :cond_12
    move v0, v7

    .line 478
    :goto_a
    const-string v2, "/api/v0/chat/edit_message"

    .line 479
    .line 480
    goto/16 :goto_2

    .line 481
    .line 482
    :goto_b
    new-instance v4, Lyb4;

    .line 483
    .line 484
    invoke-direct {v4}, Lyb4;-><init>()V

    .line 485
    .line 486
    .line 487
    sget-object v2, Ljb4;->c:Ljb4;

    .line 488
    .line 489
    iput-object v2, v4, Lyb4;->b:Ljb4;

    .line 490
    .line 491
    sget v2, Lbc4;->a:I

    .line 492
    .line 493
    iget-object v2, v4, Lyb4;->a:Loo9;

    .line 494
    .line 495
    invoke-static {v2, v5}, Lpo9;->b(Loo9;Ljava/lang/String;)Loo9;

    .line 496
    .line 497
    .line 498
    sget-object v2, Lxp7;->a:Lj70;

    .line 499
    .line 500
    iput-object p1, v4, Lyb4;->d:Ljava/lang/Object;

    .line 501
    .line 502
    invoke-virtual {v4, v3}, Lyb4;->c(Lsl9;)V

    .line 503
    .line 504
    .line 505
    sget-object v2, Lce2;->a:Lge2;

    .line 506
    .line 507
    invoke-static {v4, v2}, Loy4;->D(Lyb4;Lge2;)V

    .line 508
    .line 509
    .line 510
    if-eqz v1, :cond_13

    .line 511
    .line 512
    const-string v2, "X-DS-PoW-Response"

    .line 513
    .line 514
    invoke-static {v4, v2, v1}, Lpd5;->r(Lib4;Ljava/lang/String;Ljava/lang/Object;)V

    .line 515
    .line 516
    .line 517
    :cond_13
    instance-of p1, p1, Lmj1;

    .line 518
    .line 519
    if-nez p1, :cond_14

    .line 520
    .line 521
    iget-object p1, p0, Lhx2;->b:Ljava/lang/Object;

    .line 522
    .line 523
    check-cast p1, Lta5;

    .line 524
    .line 525
    invoke-interface {p1}, Lta5;->getValue()Ljava/lang/Object;

    .line 526
    .line 527
    .line 528
    move-result-object p1

    .line 529
    check-cast p1, Ltu;

    .line 530
    .line 531
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 532
    .line 533
    .line 534
    :cond_14
    new-instance p1, Lvc4;

    .line 535
    .line 536
    invoke-direct {p1}, Lvc4;-><init>()V

    .line 537
    .line 538
    .line 539
    const-wide v1, 0x7fffffffffffffffL

    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 545
    .line 546
    .line 547
    move-result-object v1

    .line 548
    invoke-virtual {p1, v1}, Lvc4;->c(Ljava/lang/Long;)V

    .line 549
    .line 550
    .line 551
    if-nez p2, :cond_15

    .line 552
    .line 553
    int-to-long v0, v0

    .line 554
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 555
    .line 556
    .line 557
    move-result-object p2

    .line 558
    :cond_15
    invoke-virtual {p1, p2}, Lvc4;->b(Ljava/lang/Long;)V

    .line 559
    .line 560
    .line 561
    sget-object p2, Luc4;->a:Luc4;

    .line 562
    .line 563
    invoke-virtual {v4, p2, p1}, Lyb4;->d(Lva4;Ljava/lang/Object;)V

    .line 564
    .line 565
    .line 566
    new-instance v2, Lz4;

    .line 567
    .line 568
    const/4 v7, 0x7

    .line 569
    move-object v3, p0

    .line 570
    invoke-direct/range {v2 .. v7}, Lz4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 571
    .line 572
    .line 573
    new-instance p0, Lz40;

    .line 574
    .line 575
    const/4 p1, 0x5

    .line 576
    invoke-direct {p0, p1, v2}, Lz40;-><init>(ILjava/lang/Object;)V

    .line 577
    .line 578
    .line 579
    return-object p0

    .line 580
    :cond_16
    invoke-static {}, Ld42;->d()V

    .line 581
    .line 582
    .line 583
    const/4 p0, 0x0

    .line 584
    return-object p0
.end method

.method public final bridge y()Lcj;
    .locals 0

    .line 1
    iget p0, p0, Lhx2;->a:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ltga;->I()Lcj;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_0
    invoke-static {}, Ltga;->I()Lcj;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :pswitch_1
    invoke-static {}, Ltga;->I()Lcj;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
